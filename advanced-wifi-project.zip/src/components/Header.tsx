import React from 'react';
import { Menu, Moon, Router, Sun } from 'lucide-react';
import { PageId, useApp } from '../context/AppContext';
import { LanguageCode, useI18n } from '../i18n';

interface HeaderProps {
  onOpenMobileMenu: () => void;
}

const PAGE_TITLES: Record<PageId, string> = {
  dashboard: 'nav.dashboard',
  'floor-plan': 'nav.floorPlan',
  'wifi-settings': 'nav.wifiSettings',
  'speed-test': 'nav.speedTest',
  diagnostics: 'nav.diagnostics',
  devices: 'nav.devices',
  'activity-log': 'nav.activityLog',
  'router-connection': 'nav.routerConnection',
  'local-connector': 'nav.localConnector',
  account: 'nav.account',
  login: 'nav.login'
};

export const Header: React.FC<HeaderProps> = ({ onOpenMobileMenu }) => {
  const { page, setPage, theme, toggleTheme, changeLanguage, routerSession } = useApp();
  const { language, t } = useI18n();

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-[#112033]/95 backdrop-blur-sm border-b border-[#DCE5F0] dark:border-[#1F354F]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 sm:gap-8">
        {/* Zone 1: Menu button (mobile) + Page title */}
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={onOpenMobileMenu}
            aria-label={t('nav.menu')}
            className="lg:hidden p-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44]"
          >
            <Menu className="w-5 h-5" />
          </button>
          <span className="text-base sm:text-lg font-semibold text-[#102B49] dark:text-[#EAF1F8] truncate whitespace-nowrap">
            {t(PAGE_TITLES[page])}
          </span>
        </div>

        {/* Zone 2: Language & Theme controls */}
        <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
          <div className="flex items-center p-0.5 sm:p-1 rounded-xl bg-[#F4F7FB] dark:bg-[#0B1522] border border-[#DCE5F0] dark:border-[#1F354F]" role="group" aria-label={t('app.language')}>
            {(['ar', 'en', 'fr'] as LanguageCode[]).map((code) => (
              <button
                key={code}
                type="button"
                onClick={() => changeLanguage(code)}
                aria-pressed={language === code}
                className={`px-2 sm:px-2.5 py-1 rounded-lg text-xs font-semibold uppercase transition-colors whitespace-nowrap shrink-0 ${
                  language === code
                    ? 'bg-[#174C78] text-white'
                    : 'text-[#526A84] dark:text-[#93ACC6] hover:text-[#102B49] dark:hover:text-white'
                }`}
              >
                {code}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={toggleTheme}
            aria-label={theme === 'dark' ? t('app.lightMode') : t('app.darkMode')}
            className="p-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] transition-colors shrink-0"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Zone 3: Single primary action */}
          <button
            type="button"
            onClick={() => setPage('router-connection')}
            className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0"
          >
            <Router className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{routerSession ? routerSession.routerInfo.gatewayIp : t('nav.routerConnection')}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
