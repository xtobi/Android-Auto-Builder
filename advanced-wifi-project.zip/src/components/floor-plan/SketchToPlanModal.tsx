import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Check,
  Eraser,
  Loader2,
  Minus,
  PenLine,
  Router,
  Sparkles,
  Square,
  Trash2,
  Type as TypeIcon,
  Undo2,
  Upload,
  X
} from 'lucide-react';
import { useI18n } from '../../i18n';
import {
  FloorPlan,
  organizeCustomSketchLayout,
  SketchConversionInput,
  SketchOrganizedPlanResult
} from '../../utils/floorPlanEngine';

type SketchTool = 'pen' | 'rect' | 'line' | 'label' | 'router' | 'eraser';

type SketchStroke =
  | { kind: 'pen' | 'eraser'; points: Array<{ x: number; y: number }> }
  | { kind: 'rect'; x: number; y: number; w: number; h: number }
  | { kind: 'line'; x1: number; y1: number; x2: number; y2: number }
  | { kind: 'label'; x: number; y: number; text: string }
  | { kind: 'router'; x: number; y: number };

interface SketchToPlanModalProps {
  open: boolean;
  activeFloor: FloorPlan;
  onClose: () => void;
  onApplyPlan: (result: SketchOrganizedPlanResult) => void;
}

const CANVAS_W = 840;
const CANVAS_H = 440;

export const SketchToPlanModal: React.FC<SketchToPlanModalProps> = ({
  open,
  activeFloor,
  onClose,
  onApplyPlan
}) => {
  const { t, language } = useI18n();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [tool, setTool] = useState<SketchTool>('rect');
  const [strokes, setStrokes] = useState<SketchStroke[]>([]);
  const [uploadedBgImage, setUploadedBgImage] = useState<HTMLImageElement | null>(null);
  const [draftStroke, setDraftStroke] = useState<SketchStroke | null>(null);

  const [pendingLabelPos, setPendingLabelPos] = useState<{ x: number; y: number } | null>(null);
  const [labelText, setLabelText] = useState('');

  const [userNote, setUserNote] = useState('');
  const [targetWidthM, setTargetWidthM] = useState('');
  const [targetHeightM, setTargetHeightM] = useState('');

  const [isConverting, setIsConverting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [previewResult, setPreviewResult] = useState<SketchOrganizedPlanResult | null>(null);

  const pointerActiveRef = useRef(false);

  const drawAllToCanvas = useCallback(
    (
      includeGrid: boolean,
      list: SketchStroke[],
      draft: SketchStroke | null,
      bgImg: HTMLImageElement | null,
      targetCtx?: CanvasRenderingContext2D
    ) => {
      const ctx = targetCtx ?? canvasRef.current?.getContext('2d');
      if (!ctx) return;

      // Always crisp white architectural paper background
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

      if (bgImg) {
        const scale = Math.min((CANVAS_W - 32) / bgImg.width, (CANVAS_H - 32) / bgImg.height);
        const dw = bgImg.width * scale;
        const dh = bgImg.height * scale;
        const dx = (CANVAS_W - dw) / 2;
        const dy = (CANVAS_H - dh) / 2;
        ctx.drawImage(bgImg, dx, dy, dw, dh);
      }

      if (includeGrid) {
        ctx.save();
        ctx.strokeStyle = '#e4e4e7';
        ctx.lineWidth = 1;
        const step = 30;
        for (let x = step; x < CANVAS_W; x += step) {
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, CANVAS_H);
          ctx.stroke();
        }
        for (let y = step; y < CANVAS_H; y += step) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(CANVAS_W, y);
          ctx.stroke();
        }
        ctx.restore();
      }

      const renderItem = (item: SketchStroke) => {
        ctx.save();
        if (item.kind === 'pen') {
          if (item.points.length === 0) {
            ctx.restore();
            return;
          }
          ctx.strokeStyle = '#09090b';
          ctx.lineWidth = 3.5;
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          ctx.beginPath();
          ctx.moveTo(item.points[0].x, item.points[0].y);
          for (let i = 1; i < item.points.length; i++) {
            ctx.lineTo(item.points[i].x, item.points[i].y);
          }
          ctx.stroke();
        } else if (item.kind === 'eraser') {
          if (item.points.length === 0) {
            ctx.restore();
            return;
          }
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 22;
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          ctx.beginPath();
          ctx.moveTo(item.points[0].x, item.points[0].y);
          for (let i = 1; i < item.points.length; i++) {
            ctx.lineTo(item.points[i].x, item.points[i].y);
          }
          ctx.stroke();
        } else if (item.kind === 'rect') {
          const rx = item.w >= 0 ? item.x : item.x + item.w;
          const ry = item.h >= 0 ? item.y : item.y + item.h;
          const rw = Math.abs(item.w);
          const rh = Math.abs(item.h);
          ctx.fillStyle = 'rgba(24, 24, 27, 0.04)';
          ctx.strokeStyle = '#09090b';
          ctx.lineWidth = 3.5;
          ctx.fillRect(rx, ry, rw, rh);
          ctx.strokeRect(rx, ry, rw, rh);
        } else if (item.kind === 'line') {
          ctx.strokeStyle = '#09090b';
          ctx.lineWidth = 4;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(item.x1, item.y1);
          ctx.lineTo(item.x2, item.y2);
          ctx.stroke();
        } else if (item.kind === 'label') {
          ctx.font = 'bold 17px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          const metrics = ctx.measureText(item.text);
          const padX = 8;
          ctx.fillStyle = 'rgba(255,255,255,0.92)';
          ctx.fillRect(item.x - metrics.width / 2 - padX, item.y - 13, metrics.width + padX * 2, 26);
          ctx.fillStyle = '#09090b';
          ctx.fillText(item.text, item.x, item.y);
        } else if (item.kind === 'router') {
          ctx.strokeStyle = '#09090b';
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.arc(item.x, item.y, 16, 0, Math.PI * 2);
          ctx.fillStyle = '#ffffff';
          ctx.fill();
          ctx.stroke();
          ctx.beginPath();
          ctx.arc(item.x, item.y, 24, -Math.PI * 0.75, -Math.PI * 0.25);
          ctx.stroke();
          ctx.font = 'bold 14px monospace';
          ctx.fillStyle = '#09090b';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('R', item.x, item.y + 1);
        }
        ctx.restore();
      };

      for (const s of list) renderItem(s);
      if (draft) renderItem(draft);
    },
    []
  );

  useEffect(() => {
    if (!open || previewResult) return;
    drawAllToCanvas(true, strokes, draftStroke, uploadedBgImage);
  }, [open, previewResult, strokes, draftStroke, uploadedBgImage, drawAllToCanvas]);

  const toCanvasCoords = (e: React.PointerEvent<HTMLCanvasElement>): { x: number; y: number } => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const x = Math.max(0, Math.min(CANVAS_W, ((e.clientX - rect.left) / rect.width) * CANVAS_W));
    const y = Math.max(0, Math.min(CANVAS_H, ((e.clientY - rect.top) / rect.height) * CANVAS_H));
    return { x, y };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (e.button > 0) return;
    setErrorMsg(null);
    const pt = toCanvasCoords(e);

    if (tool === 'label') {
      setPendingLabelPos(pt);
      setLabelText('');
      return;
    }

    if (tool === 'router') {
      setStrokes((prev) => [...prev.filter((s) => s.kind !== 'router'), { kind: 'router', x: pt.x, y: pt.y }]);
      return;
    }

    e.currentTarget.setPointerCapture(e.pointerId);
    pointerActiveRef.current = true;

    if (tool === 'pen' || tool === 'eraser') {
      setDraftStroke({ kind: tool, points: [pt] });
    } else if (tool === 'rect') {
      setDraftStroke({ kind: 'rect', x: pt.x, y: pt.y, w: 0, h: 0 });
    } else if (tool === 'line') {
      setDraftStroke({ kind: 'line', x1: pt.x, y1: pt.y, x2: pt.x, y2: pt.y });
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!pointerActiveRef.current || !draftStroke) return;
    const pt = toCanvasCoords(e);

    if (draftStroke.kind === 'pen' || draftStroke.kind === 'eraser') {
      setDraftStroke({
        ...draftStroke,
        points: [...draftStroke.points, pt]
      });
    } else if (draftStroke.kind === 'rect') {
      setDraftStroke({
        ...draftStroke,
        w: pt.x - draftStroke.x,
        h: pt.y - draftStroke.y
      });
    } else if (draftStroke.kind === 'line') {
      setDraftStroke({
        ...draftStroke,
        x2: pt.x,
        y2: pt.y
      });
    }
  };

  const finishStroke = () => {
    if (!pointerActiveRef.current || !draftStroke) return;
    pointerActiveRef.current = false;

    let valid = true;
    if (draftStroke.kind === 'rect') {
      valid = Math.abs(draftStroke.w) >= 18 && Math.abs(draftStroke.h) >= 18;
    } else if (draftStroke.kind === 'line') {
      valid = Math.hypot(draftStroke.x2 - draftStroke.x1, draftStroke.y2 - draftStroke.y1) >= 12;
    } else if (draftStroke.kind === 'pen' || draftStroke.kind === 'eraser') {
      valid = draftStroke.points.length >= 2;
    }

    if (valid) {
      setStrokes((prev) => [...prev, draftStroke]);
    }
    setDraftStroke(null);
  };

  const handleConfirmLabel = (textOverride?: string) => {
    const clean = (textOverride ?? labelText).trim().slice(0, 32);
    if (pendingLabelPos && clean) {
      setStrokes((prev) => [...prev, { kind: 'label', x: pendingLabelPos.x, y: pendingLabelPos.y, text: clean }]);
    }
    setPendingLabelPos(null);
    setLabelText('');
  };

  const handleUploadSketch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        setUploadedBgImage(img);
        setErrorMsg(null);
      };
      if (typeof reader.result === 'string') {
        img.src = reader.result;
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleClear = () => {
    setStrokes([]);
    setDraftStroke(null);
    setUploadedBgImage(null);
    setPendingLabelPos(null);
    setErrorMsg(null);
    setPreviewResult(null);
    setAiSummary(null);
  };

  const exportCleanPng = (): string => {
    const offscreen = document.createElement('canvas');
    offscreen.width = CANVAS_W;
    offscreen.height = CANVAS_H;
    const ctx = offscreen.getContext('2d');
    if (!ctx) return '';

    drawAllToCanvas(false, strokes, null, uploadedBgImage, ctx);
    return offscreen.toDataURL('image/png');
  };

  const handleConvertSketch = async () => {
    if (strokes.length === 0 && !uploadedBgImage && !userNote.trim()) {
      setErrorMsg(t('survey.sketch.emptyError'));
      return;
    }

    setErrorMsg(null);
    setIsConverting(true);

    try {
      const imageDataUrl = exportCleanPng();
      const res = await fetch('/api/floor-plan/convert-sketch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageDataUrl,
          userNote: userNote.trim(),
          language,
          targetWidthMeters: targetWidthM ? Number(targetWidthM) : undefined,
          targetHeightMeters: targetHeightM ? Number(targetHeightM) : undefined
        })
      });

      const payload = (await res.json()) as Partial<SketchConversionInput> & {
        error?: string;
        message?: string;
        summary?: string;
      };

      if (!res.ok) {
        if (payload.error === 'GEMINI_API_KEY_MISSING') {
          setErrorMsg(t('survey.sketch.apiKeyMissingError'));
        } else if (payload.error === 'GEMINI_SERVICE_UNAVAILABLE' || payload.error === 'GEMINI_NETWORK_UNREACHABLE') {
          setErrorMsg(t('survey.sketch.serviceBusyError'));
        } else if (payload.error === 'GEMINI_RATE_LIMITED') {
          setErrorMsg(t('survey.sketch.rateLimitError'));
        } else if (payload.error === 'NO_ROOMS_DETECTED' || payload.error === 'EMPTY_AI_RESPONSE') {
          setErrorMsg(t('survey.sketch.noRoomsError'));
        } else {
          setErrorMsg(payload.message || t('survey.sketch.convertFailed'));
        }
        return;
      }

      if (!Array.isArray(payload.rooms) || payload.rooms.length === 0) {
        setErrorMsg(t('survey.sketch.noRoomsError'));
        return;
      }

      const organized = organizeCustomSketchLayout(
        {
          rooms: payload.rooms,
          suggestedSpanMeters: payload.suggestedSpanMeters,
          routerPct: payload.routerPct ?? null
        },
        activeFloor
      );

      setAiSummary(payload.summary || null);
      setPreviewResult(organized);
    } catch {
      setErrorMsg(t('survey.sketch.networkError'));
    } finally {
      setIsConverting(false);
    }
  };

  if (!open) return null;

  const toolButtons: Array<{ id: SketchTool; icon: React.ReactNode; label: string }> = [
    { id: 'rect', icon: <Square className="w-3.5 h-3.5" aria-hidden="true" />, label: t('survey.sketch.toolBox') },
    { id: 'pen', icon: <PenLine className="w-3.5 h-3.5" aria-hidden="true" />, label: t('survey.sketch.toolPen') },
    { id: 'line', icon: <Minus className="w-3.5 h-3.5" aria-hidden="true" />, label: t('survey.sketch.toolWall') },
    { id: 'label', icon: <TypeIcon className="w-3.5 h-3.5" aria-hidden="true" />, label: t('survey.sketch.toolLabel') },
    { id: 'router', icon: <Router className="w-3.5 h-3.5" aria-hidden="true" />, label: t('survey.sketch.toolRouter') },
    { id: 'eraser', icon: <Eraser className="w-3.5 h-3.5" aria-hidden="true" />, label: t('survey.sketch.toolEraser') }
  ];

  const quickLabelPresets = [
    t('survey.roomTypes.living'),
    t('survey.roomTypes.bedroom'),
    t('survey.roomTypes.kitchen'),
    t('survey.roomTypes.bathroom'),
    t('survey.roomTypes.office'),
    t('survey.roomTypes.corridor')
  ];

  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-3 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="sketch-modal-title"
      data-testid="sketch-to-plan-modal"
    >
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl w-full max-w-3xl max-h-[92vh] overflow-y-auto p-4 sm:p-5 space-y-3 shadow-2xl">
        {/* Header */}
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-700 dark:text-zinc-300">
              <Sparkles className="w-4 h-4" aria-hidden="true" />
              <span>{activeFloor.name}</span>
            </div>
            <h2 id="sketch-modal-title" className="text-base sm:text-lg font-bold text-zinc-950 dark:text-zinc-50 mt-0.5">
              {t('survey.sketch.modalTitle')}
            </h2>
            <p className="text-xs text-zinc-600 dark:text-zinc-400 mt-0.5">
              {t('survey.sketch.modalSubtitle')}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={t('app.close')}
            data-testid="close-sketch-modal-btn"
            className="p-2 rounded-xl border border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-300 hover:border-zinc-400 shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {!previewResult ? (
          <>
            {/* Drawing Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-zinc-200 dark:border-zinc-800">
              <div className="flex flex-wrap items-center gap-1.5">
                {toolButtons.map((btn) => {
                  const active = tool === btn.id;
                  return (
                    <button
                      key={btn.id}
                      type="button"
                      data-testid={`sketch-tool-${btn.id}`}
                      onClick={() => {
                        setTool(btn.id);
                        setPendingLabelPos(null);
                      }}
                      className={`inline-flex items-center gap-1.5 px-2.5 min-h-[34px] rounded-xl text-xs font-medium border transition-colors ${
                        active
                          ? 'bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 border-zinc-900 dark:border-zinc-100'
                          : 'bg-zinc-50 dark:bg-zinc-950 text-zinc-800 dark:text-zinc-200 border-zinc-200 dark:border-zinc-800 hover:border-zinc-400'
                      }`}
                    >
                      {btn.icon}
                      <span>{btn.label}</span>
                    </button>
                  );
                })}
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleUploadSketch}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  data-testid="sketch-upload-btn"
                  className="inline-flex items-center gap-1.5 px-2.5 min-h-[34px] rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-800 dark:text-zinc-200 hover:border-zinc-400"
                >
                  <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{t('survey.sketch.uploadBtn')}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setStrokes((prev) => prev.slice(0, -1))}
                  disabled={strokes.length === 0}
                  data-testid="sketch-undo-btn"
                  className="inline-flex items-center gap-1.5 px-2.5 min-h-[34px] rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-800 dark:text-zinc-200 hover:border-zinc-400 disabled:opacity-40"
                >
                  <Undo2 className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{t('survey.undoBtn')}</span>
                </button>
                <button
                  type="button"
                  onClick={handleClear}
                  data-testid="sketch-clear-btn"
                  className="inline-flex items-center gap-1.5 px-2.5 min-h-[34px] rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-red-600 dark:text-red-400 hover:border-red-400"
                >
                  <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{t('survey.sketch.clearBtn')}</span>
                </button>
              </div>
            </div>

            {/* Canvas Container */}
            <div className="relative w-full max-w-[720px] mx-auto rounded-xl border border-zinc-300 dark:border-zinc-700 overflow-hidden bg-white">
              <canvas
                ref={canvasRef}
                width={CANVAS_W}
                height={CANVAS_H}
                data-testid="sketch-drawing-canvas"
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={finishStroke}
                onPointerCancel={finishStroke}
                className="w-full h-auto block touch-none cursor-crosshair select-none"
              />

              {pendingLabelPos && (
                <div className="absolute inset-x-3 bottom-3 bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 rounded-xl p-3 shadow-lg space-y-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={labelText}
                      onChange={(e) => setLabelText(e.target.value)}
                      placeholder={t('survey.sketch.labelPlaceholder')}
                      data-testid="sketch-label-input"
                      autoFocus
                      className="flex-1 px-3 min-h-[36px] rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-950 text-xs text-zinc-950 dark:text-zinc-50"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleConfirmLabel();
                        }
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => handleConfirmLabel()}
                      data-testid="sketch-label-confirm-btn"
                      className="px-3 min-h-[36px] rounded-lg bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 text-xs font-semibold"
                    >
                      {t('app.confirm')}
                    </button>
                    <button
                      type="button"
                      onClick={() => setPendingLabelPos(null)}
                      className="px-2.5 min-h-[36px] rounded-lg border border-zinc-300 dark:border-zinc-700 text-xs"
                    >
                      {t('app.cancel')}
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {quickLabelPresets.map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => handleConfirmLabel(preset)}
                        className="px-2.5 py-1 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-[11px] font-medium text-zinc-800 dark:text-zinc-200 hover:bg-zinc-200 dark:hover:bg-zinc-700"
                      >
                        {preset}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Optional Note + Outer Dimensions */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              <div className="sm:col-span-6">
                <label htmlFor="sketch-user-note" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
                  {t('survey.sketch.notesLabel')}
                </label>
                <input
                  id="sketch-user-note"
                  type="text"
                  value={userNote}
                  onChange={(e) => setUserNote(e.target.value)}
                  placeholder={t('survey.sketch.notesPlaceholder')}
                  maxLength={300}
                  data-testid="sketch-note-input"
                  className="w-full px-3 min-h-[38px] rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-xs text-zinc-950 dark:text-zinc-50"
                />
              </div>
              <div className="sm:col-span-3">
                <label htmlFor="sketch-span-w" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
                  {t('survey.sketch.approxWidthLabel')}
                </label>
                <input
                  id="sketch-span-w"
                  type="number"
                  min={5}
                  max={26}
                  step={0.5}
                  value={targetWidthM}
                  onChange={(e) => setTargetWidthM(e.target.value)}
                  placeholder={t('survey.sketch.autoPlaceholder')}
                  className="w-full px-3 min-h-[38px] rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-xs font-mono-tabular text-zinc-950 dark:text-zinc-50"
                />
              </div>
              <div className="sm:col-span-3">
                <label htmlFor="sketch-span-h" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
                  {t('survey.sketch.approxLengthLabel')}
                </label>
                <input
                  id="sketch-span-h"
                  type="number"
                  min={5}
                  max={26}
                  step={0.5}
                  value={targetHeightM}
                  onChange={(e) => setTargetHeightM(e.target.value)}
                  placeholder={t('survey.sketch.autoPlaceholder')}
                  className="w-full px-3 min-h-[38px] rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-xs font-mono-tabular text-zinc-950 dark:text-zinc-50"
                />
              </div>
            </div>

            {errorMsg && (
              <div
                role="alert"
                data-testid="sketch-error-banner"
                className="p-3 rounded-xl border border-red-300 dark:border-red-900 bg-red-50 dark:bg-red-950/30 text-xs text-red-700 dark:text-red-300"
              >
                {errorMsg}
              </div>
            )}

            {/* Footer Controls */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-zinc-200 dark:border-zinc-800">
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                {t('survey.sketch.tipText')}
              </p>
              <div className="flex items-center gap-2 ms-auto">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 min-h-[40px] rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-800 dark:text-zinc-200"
                >
                  {t('app.cancel')}
                </button>
                <button
                  type="button"
                  onClick={() => void handleConvertSketch()}
                  disabled={isConverting}
                  data-testid="convert-sketch-btn"
                  className="inline-flex items-center gap-2 px-5 min-h-[40px] rounded-xl bg-zinc-900 dark:bg-zinc-100 hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-zinc-900 text-xs font-semibold disabled:opacity-50"
                >
                  {isConverting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
                      <span>{t('survey.sketch.converting')}</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" aria-hidden="true" />
                      <span>{t('survey.sketch.convertBtn')}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </>
        ) : (
          /* Organized Preview State */
          <div className="space-y-4" data-testid="sketch-preview-panel">
            <div className="p-3 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-xs text-zinc-700 dark:text-zinc-300 flex flex-wrap items-center justify-between gap-2">
              <span>
                {aiSummary || t('survey.sketch.previewReady')}
              </span>
              <span className="font-mono-tabular font-semibold">
                {previewResult.floor.rooms.length} {t('survey.roomsUnit')} · {previewResult.floor.widthMeters.toFixed(1)}×{previewResult.floor.heightMeters.toFixed(1)}{t('survey.metersUnit')}
              </span>
            </div>

            <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 p-3 flex items-center justify-center">
              <svg
                viewBox={`0 0 ${previewResult.floor.canvasWidth} ${previewResult.floor.canvasHeight}`}
                className="w-full max-h-[360px]"
                aria-label={t('survey.sketch.previewAriaLabel')}
              >
                {previewResult.floor.rooms.map((rm) => {
                  const cx = rm.x + rm.width / 2;
                  const cy = rm.y + rm.height / 2;
                  const rmRouter = previewResult.routerMeters;
                  const routerNearCenter =
                    rmRouter !== undefined &&
                    Math.abs(rmRouter.x - cx) < 1.1 &&
                    Math.abs(rmRouter.y - cy) < 0.9;
                  const textCy = routerNearCenter
                    ? rmRouter.y >= cy
                      ? Math.max(rm.y + 0.65, cy - 0.72)
                      : Math.min(rm.y + rm.height - 0.65, cy + 0.65)
                    : cy;

                  return (
                    <g key={rm.id}>
                      <rect
                        x={rm.x}
                        y={rm.y}
                        width={rm.width}
                        height={rm.height}
                        rx={0.12}
                        fill="#ffffff"
                        stroke="#18181b"
                        strokeWidth={0.07}
                      />
                      <text
                        x={cx}
                        y={textCy - 0.12}
                        textAnchor="middle"
                        fontSize={Math.max(0.32, Math.min(0.46, rm.width * 0.11))}
                        fontWeight={700}
                        fill="#09090b"
                      >
                        {rm.name}
                      </text>
                      <text
                        x={cx}
                        y={textCy + 0.34}
                        textAnchor="middle"
                        fontSize={0.28}
                        fill="#52525b"
                      >
                        {rm.width.toFixed(1)}×{rm.height.toFixed(1)}{t('survey.metersUnit')}
                      </text>
                    </g>
                  );
                })}
                {previewResult.floor.segments.map((seg) => (
                  <line
                    key={seg.id}
                    x1={seg.x1}
                    y1={seg.y1}
                    x2={seg.x2}
                    y2={seg.y2}
                    stroke={seg.kind === 'door' ? '#71717a' : '#09090b'}
                    strokeWidth={seg.kind === 'door' ? 0.08 : 0.12}
                    strokeDasharray={seg.kind === 'door' ? '0.18 0.12' : undefined}
                  />
                ))}
                {previewResult.routerMeters && (
                  <g>
                    <circle
                      cx={previewResult.routerMeters.x}
                      cy={previewResult.routerMeters.y}
                      r={0.3}
                      fill="#09090b"
                      stroke="#ffffff"
                      strokeWidth={0.06}
                    />
                    <text
                      x={previewResult.routerMeters.x}
                      y={previewResult.routerMeters.y + 0.1}
                      textAnchor="middle"
                      fontSize={0.28}
                      fontWeight={700}
                      fill="#ffffff"
                    >
                      R
                    </text>
                  </g>
                )}
              </svg>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-zinc-200 dark:border-zinc-800">
              <button
                type="button"
                onClick={() => setPreviewResult(null)}
                data-testid="back-to-sketch-btn"
                className="px-4 min-h-[40px] rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-800 dark:text-zinc-200"
              >
                {t('survey.sketch.backToEditBtn')}
              </button>
              <button
                type="button"
                onClick={() => {
                  onApplyPlan(previewResult);
                  setPreviewResult(null);
                  setAiSummary(null);
                  setErrorMsg(null);
                  onClose();
                }}
                data-testid="apply-sketch-plan-btn"
                className="inline-flex items-center gap-2 px-5 min-h-[40px] rounded-xl bg-zinc-900 dark:bg-zinc-100 hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-zinc-900 text-xs font-semibold"
              >
                <Check className="w-4 h-4" aria-hidden="true" />
                <span>{t('survey.sketch.applyPlanBtn')}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
