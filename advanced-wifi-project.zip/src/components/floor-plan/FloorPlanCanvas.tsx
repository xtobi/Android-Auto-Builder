import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  DoorOpen,
  Hand,
  Minus,
  MousePointer,
  Pencil,
  Plus,
  RotateCcw,
  Router,
  Trash2,
  Waypoints,
  X
} from 'lucide-react';
import { useI18n } from '../../i18n';
import {
  clampCoord,
  classifyRoomHeatmapMetric,
  estimateApproxCoverageRadiusMeters,
  FloorPlan,
  FloorRoom,
  FloorSegment,
  getLatestRoomMeasurement,
  HeatmapMetric,
  HeatmapTier,
  RoomCategory,
  RoomMeasurementRecord,
  RoomResizeResult,
  RouterPlacement,
  RouterScenarioId,
  round1,
  snapCoord
} from '../../utils/floorPlanEngine';
import { WallMaterial } from '../../utils/homeSignalMap';

export type EditorTool = 'select' | 'draw-wall' | 'draw-door' | 'place-router' | 'pan';

interface FloorPlanCanvasProps {
  floor: FloorPlan;
  allFloors: FloorPlan[];
  activeScenarioId: RouterScenarioId;
  routerPlacement: RouterPlacement;
  measurements: RoomMeasurementRecord[];
  heatmapMetric: HeatmapMetric;
  selectedRoomId: string | null;
  selectedSegmentId: string | null;
  isDark: boolean;
  resizeNotice: RoomResizeResult | null;
  externalRenameRoomId: string | null;
  onClearExternalRename: () => void;
  onSelectRoom: (roomId: string | null) => void;
  onSelectSegment: (segmentId: string | null) => void;
  onUpdateFloorWithHistory: (updater: (floor: FloorPlan) => FloorPlan) => void;
  onUpdateFloorLive: (updater: (floor: FloorPlan) => FloorPlan) => void;
  onCommitFloorHistorySnapshot: (beforeDragFloor: FloorPlan) => void;
  onResizeRoomLive: (roomId: string, widthM: number, heightM: number) => void;
  onRenameRoom: (roomId: string, nextName: string, nextCategory?: RoomCategory) => void;
  onMoveRouter: (next: Partial<RouterPlacement>) => void;
}

const HEATMAP_STYLES: Record<
  HeatmapTier,
  { fillLight: string; fillDark: string; strokeLight: string; strokeDark: string; textLight: string; textDark: string }
> = {
  strong: {
    fillLight: '#DCFCE7',
    fillDark: '#064E3B',
    strokeLight: '#16A34A',
    strokeDark: '#22C55E',
    textLight: '#166534',
    textDark: '#86EFAC'
  },
  moderate: {
    fillLight: '#FEF9C3',
    fillDark: '#422006',
    strokeLight: '#CA8A04',
    strokeDark: '#EAB308',
    textLight: '#854D0E',
    textDark: '#FDE047'
  },
  weak: {
    fillLight: '#FEE2E2',
    fillDark: '#450A0A',
    strokeLight: '#DC2626',
    strokeDark: '#EF4444',
    textLight: '#991B1B',
    textDark: '#FCA5A5'
  },
  unmeasured: {
    fillLight: '#FFFFFF',
    fillDark: '#18181B',
    strokeLight: '#D4D4D8',
    strokeDark: '#3F3F46',
    textLight: '#52525B',
    textDark: '#A1A1AA'
  }
};

const QUICK_PRESET_CATEGORIES: RoomCategory[] = [
  'living',
  'bedroom',
  'kitchen',
  'bathroom',
  'corridor',
  'office',
  'custom'
];

type ResizeHandleDirection = 'top' | 'right' | 'bottom' | 'left' | 'tl' | 'tr' | 'br' | 'bl';

type DragState =
  | {
      kind: 'resize-room';
      roomId: string;
      axis: ResizeHandleDirection;
      startClientX: number;
      startClientY: number;
      pxPerMeterX: number;
      pxPerMeterY: number;
      origWidth: number;
      origHeight: number;
      beforeFloor: FloorPlan;
      moved: boolean;
    }
  | {
      kind: 'move-router';
    }
  | {
      kind: 'draw-segment';
      segKind: 'wall' | 'door';
      x1: number;
      y1: number;
      x2: number;
      y2: number;
    }
  | {
      kind: 'move-segment-end';
      segmentId: string;
      end: 'p1' | 'p2';
      beforeFloor: FloorPlan;
    }
  | {
      kind: 'pan';
      startClientX: number;
      startClientY: number;
      origPanX: number;
      origPanY: number;
    };

export const FloorPlanCanvas: React.FC<FloorPlanCanvasProps> = ({
  floor,
  activeScenarioId,
  routerPlacement,
  measurements,
  heatmapMetric,
  selectedRoomId,
  selectedSegmentId,
  isDark,
  resizeNotice,
  externalRenameRoomId,
  onClearExternalRename,
  onSelectRoom,
  onSelectSegment,
  onUpdateFloorWithHistory,
  onUpdateFloorLive,
  onCommitFloorHistorySnapshot,
  onResizeRoomLive,
  onRenameRoom,
  onMoveRouter
}) => {
  const { t } = useI18n();
  const svgRef = useRef<SVGSVGElement | null>(null);
  const suppressNextRoomClickRef = useRef(false);
  const moveFnRef = useRef<(clientX: number, clientY: number) => void>(() => {});
  const upFnRef = useRef<() => void>(() => {});

  const [tool, setTool] = useState<EditorTool>('select');
  const [wallMaterial, setWallMaterial] = useState<WallMaterial>('brick');
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [drag, setDrag] = useState<DragState | null>(null);

  // Click-to-rename modal state (never moves room!)
  const [renameModalRoomId, setRenameModalRoomId] = useState<string | null>(null);
  const [renameDraft, setRenameDraft] = useState<string>('');
  const [categoryDraft, setCategoryDraft] = useState<RoomCategory>('living');

  const renameTargetRoom = useMemo(
    () => floor.rooms.find((r) => r.id === renameModalRoomId) ?? null,
    [floor.rooms, renameModalRoomId]
  );

  useEffect(() => {
    if (!externalRenameRoomId) return;
    const rm = floor.rooms.find((r) => r.id === externalRenameRoomId);
    if (rm) {
      setRenameModalRoomId(rm.id);
      setRenameDraft(rm.name);
      setCategoryDraft(rm.category);
    }
    onClearExternalRename();
  }, [externalRenameRoomId, floor.rooms, onClearExternalRename]);

  const openRenameForRoom = (room: FloorRoom) => {
    setRenameModalRoomId(room.id);
    setRenameDraft(room.name);
    setCategoryDraft(room.category);
  };

  const closeRenameModal = () => {
    setRenameModalRoomId(null);
  };

  const handleSaveRename = (e: React.FormEvent) => {
    e.preventDefault();
    if (!renameTargetRoom) return;
    onRenameRoom(renameTargetRoom.id, renameDraft, categoryDraft);
    setRenameModalRoomId(null);
  };

  const routerOnThisFloor = routerPlacement.floorId === floor.id;
  const approxRadiusMeters = useMemo(() => estimateApproxCoverageRadiusMeters(floor), [floor]);

  const viewBox = useMemo(() => {
    const baseW = floor.canvasWidth;
    const baseH = floor.canvasHeight;
    const vbW = baseW / zoom;
    const vbH = baseH / zoom;
    const maxPanX = Math.max(0, baseW - vbW);
    const maxPanY = Math.max(0, baseH - vbH);
    const vx = Math.max(-2, Math.min(maxPanX + 2, (baseW - vbW) / 2 - pan.x));
    const vy = Math.max(-2, Math.min(maxPanY + 2, (baseH - vbH) / 2 - pan.y));
    return { x: vx, y: vy, w: vbW, h: vbH };
  }, [floor.canvasWidth, floor.canvasHeight, zoom, pan]);

  const clientToMetricCoords = (clientX: number, clientY: number): { x: number; y: number } => {
    const svg = svgRef.current;
    if (!svg) return { x: round1(floor.canvasWidth / 2), y: round1(floor.canvasHeight / 2) };
    const rect = svg.getBoundingClientRect();
    if (!rect.width || !rect.height) {
      return { x: round1(floor.canvasWidth / 2), y: round1(floor.canvasHeight / 2) };
    }
    const rawX = viewBox.x + ((clientX - rect.left) / rect.width) * viewBox.w;
    const rawY = viewBox.y + ((clientY - rect.top) / rect.height) * viewBox.h;
    return {
      x: clampCoord(snapCoord(rawX, 0.2), 0.4, floor.canvasWidth + 2),
      y: clampCoord(snapCoord(rawY, 0.2), 0.4, floor.canvasHeight + 2)
    };
  };

  const handleSvgPointerDown = (e: React.PointerEvent<SVGSVGElement>) => {
    const pt = clientToMetricCoords(e.clientX, e.clientY);

    if (tool === 'pan') {
      e.currentTarget.setPointerCapture(e.pointerId);
      setDrag({
        kind: 'pan',
        startClientX: e.clientX,
        startClientY: e.clientY,
        origPanX: pan.x,
        origPanY: pan.y
      });
      return;
    }

    if (tool === 'place-router') {
      onMoveRouter({
        floorId: floor.id,
        x: clampCoord(pt.x, 1.0, floor.canvasWidth - 1.0),
        y: clampCoord(pt.y, 1.0, floor.canvasHeight - 1.0)
      });
      setTool('select');
      return;
    }

    if (tool === 'draw-wall' || tool === 'draw-door') {
      e.currentTarget.setPointerCapture(e.pointerId);
      setDrag({
        kind: 'draw-segment',
        segKind: tool === 'draw-door' ? 'door' : 'wall',
        x1: pt.x,
        y1: pt.y,
        x2: pt.x,
        y2: pt.y
      });
      return;
    }

    // Deselect on empty canvas click in select mode
    if (e.target === svgRef.current || (e.target as HTMLElement).dataset?.bg === 'true') {
      onSelectRoom(null);
      onSelectSegment(null);
    }
  };

  const processPointerMove = (clientX: number, clientY: number) => {
    if (!drag) return;

    if (drag.kind === 'pan') {
      const svg = svgRef.current;
      if (!svg) return;
      const rect = svg.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const dx = ((clientX - drag.startClientX) / rect.width) * viewBox.w;
      const dy = ((clientY - drag.startClientY) / rect.height) * viewBox.h;
      setPan({ x: drag.origPanX + dx, y: drag.origPanY + dy });
      return;
    }

    const pt = clientToMetricCoords(clientX, clientY);

    if (drag.kind === 'move-router') {
      onMoveRouter({
        floorId: floor.id,
        x: clampCoord(pt.x, 0.8, floor.canvasWidth - 0.8),
        y: clampCoord(pt.y, 0.8, floor.canvasHeight - 0.8)
      });
      return;
    }

    if (drag.kind === 'draw-segment') {
      setDrag({ ...drag, x2: pt.x, y2: pt.y });
      return;
    }

    if (drag.kind === 'resize-room') {
      const dx = (clientX - drag.startClientX) / drag.pxPerMeterX;
      const dy = (clientY - drag.startClientY) / drag.pxPerMeterY;
      const affectsWidth = drag.axis !== 'top' && drag.axis !== 'bottom';
      const affectsHeight = drag.axis !== 'left' && drag.axis !== 'right';
      const widthSign = drag.axis === 'left' || drag.axis === 'tl' || drag.axis === 'bl' ? -1 : 1;
      const heightSign = drag.axis === 'top' || drag.axis === 'tl' || drag.axis === 'tr' ? -1 : 1;

      const reqW = affectsWidth ? snapCoord(drag.origWidth + widthSign * dx, 0.2) : drag.origWidth;
      const reqH = affectsHeight ? snapCoord(drag.origHeight + heightSign * dy, 0.2) : drag.origHeight;
      if (Math.abs(dx) > 0.05 || Math.abs(dy) > 0.05) {
        suppressNextRoomClickRef.current = true;
        if (!drag.moved) setDrag({ ...drag, moved: true });
      }
      onResizeRoomLive(drag.roomId, reqW, reqH);
      return;
    }

    if (drag.kind === 'move-segment-end') {
      onUpdateFloorLive((f) => ({
        ...f,
        segments: f.segments.map((s) =>
          s.id === drag.segmentId
            ? drag.end === 'p1'
              ? { ...s, x1: pt.x, y1: pt.y }
              : { ...s, x2: pt.x, y2: pt.y }
            : s
        )
      }));
    }
  };

  const handlePointerUp = () => {
    if (!drag) return;

    if (drag.kind === 'resize-room') {
      if (drag.moved) {
        onCommitFloorHistorySnapshot(drag.beforeFloor);
        suppressNextRoomClickRef.current = true;
        setTimeout(() => {
          suppressNextRoomClickRef.current = false;
        }, 80);
      }
    } else if (drag.kind === 'move-segment-end') {
      onCommitFloorHistorySnapshot(drag.beforeFloor);
    } else if (drag.kind === 'draw-segment') {
      const dist = Math.hypot(drag.x2 - drag.x1, drag.y2 - drag.y1);
      if (dist >= 0.4) {
        const newSeg: FloorSegment = {
          id: `custom_seg_${drag.segKind}_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
          kind: drag.segKind,
          x1: drag.x1,
          y1: drag.y1,
          x2: drag.x2,
          y2: drag.y2,
          material: drag.segKind === 'door' ? 'drywall' : wallMaterial,
          userDrawn: true
        };
        onUpdateFloorWithHistory((f) => ({
          ...f,
          segments: [...f.segments, newSeg]
        }));
        onSelectSegment(newSeg.id);
        onSelectRoom(null);
      }
      setTool('select');
    }

    setDrag(null);
  };

  moveFnRef.current = processPointerMove;
  upFnRef.current = handlePointerUp;

  useEffect(() => {
    if (!drag) return;
    const onWinMove = (ev: PointerEvent) => moveFnRef.current(ev.clientX, ev.clientY);
    const onWinUp = () => upFnRef.current();
    window.addEventListener('pointermove', onWinMove);
    window.addEventListener('pointerup', onWinUp);
    window.addEventListener('pointercancel', onWinUp);
    return () => {
      window.removeEventListener('pointermove', onWinMove);
      window.removeEventListener('pointerup', onWinUp);
      window.removeEventListener('pointercancel', onWinUp);
    };
  }, [Boolean(drag)]);

  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    processPointerMove(e.clientX, e.clientY);
  };

  const selectedSegment = floor.segments.find((s) => s.id === selectedSegmentId) ?? null;

  const toolButtons: Array<{ id: EditorTool; label: string; icon: React.ComponentType<{ className?: string }> }> = [
    { id: 'select', label: t('survey.toolSelect'), icon: MousePointer },
    { id: 'draw-wall', label: t('survey.toolDrawWall'), icon: Waypoints },
    { id: 'draw-door', label: t('survey.toolDrawDoor'), icon: DoorOpen },
    { id: 'place-router', label: t('survey.toolPlaceRouter'), icon: Router },
    { id: 'pan', label: t('survey.toolPan'), icon: Hand }
  ];

  // Dynamic stroke/font scaling proportional to canvas metric scale
  const unitScale = Math.max(0.75, Math.min(1.35, Math.max(floor.canvasWidth, floor.canvasHeight) / 14));

  const formatResizeReason = (notice: RoomResizeResult): string | null => {
    if (notice.reason === 'none') return null;
    if (notice.reason === 'blocked_by_neighbor') {
      return t('survey.resizeBlockedNeighbor').replace('{room}', notice.blockingRoomName ?? '');
    }
    if (notice.reason === 'floor_limit') return t('survey.resizeBlockedFloor');
    if (notice.reason === 'min_limit') return t('survey.resizeMinLimit');
    if (notice.reason === 'max_limit') return t('survey.resizeMaxLimit');
    return null;
  };

  const resizeWarningText = resizeNotice ? formatResizeReason(resizeNotice) : null;

  return (
    <div className="space-y-3 min-w-0 relative">
      {/* Monochrome Minimal Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl p-2">
        <div className="flex flex-wrap items-center gap-1.5" role="toolbar" aria-label={t('survey.editorToolbar')}>
          {toolButtons.map((btn) => {
            const Icon = btn.icon;
            const active = tool === btn.id;
            return (
              <button
                key={btn.id}
                type="button"
                onClick={() => setTool(btn.id)}
                aria-pressed={active}
                data-testid={`tool-${btn.id}`}
                className={`inline-flex items-center gap-1.5 px-2.5 min-h-[38px] rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900'
                    : 'bg-white dark:bg-zinc-900 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-800 hover:border-zinc-400 dark:hover:border-zinc-600'
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>{btn.label}</span>
              </button>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {tool === 'draw-wall' && (
            <select
              aria-label={t('survey.wallMaterial')}
              value={wallMaterial}
              onChange={(e) => setWallMaterial(e.target.value as WallMaterial)}
              className="px-2.5 min-h-[38px] rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-xs font-medium text-zinc-900 dark:text-zinc-100"
            >
              <option value="drywall">{t('homeMap.wallDrywall')}</option>
              <option value="brick">{t('homeMap.wallBrick')}</option>
              <option value="concrete">{t('homeMap.wallConcrete')}</option>
            </select>
          )}

          {selectedSegment && (
            <button
              type="button"
              onClick={() => {
                onUpdateFloorWithHistory((f) => ({
                  ...f,
                  segments: f.segments.filter((s) => s.id !== selectedSegment.id)
                }));
                onSelectSegment(null);
              }}
              className="inline-flex items-center gap-1 px-2.5 min-h-[38px] rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-medium whitespace-nowrap"
            >
              <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t('survey.deleteSegment')}</span>
            </button>
          )}

          <div className="inline-flex items-center rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900">
            <button
              type="button"
              onClick={() => setZoom((z) => Math.max(0.7, Number((z - 0.15).toFixed(2))))}
              aria-label={t('survey.zoomOut')}
              className="p-2 text-zinc-600 dark:text-zinc-400 hover:text-zinc-950 dark:hover:text-white"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <span className="px-2 text-xs font-mono-tabular text-zinc-900 dark:text-zinc-100">
              {Math.round(zoom * 100)}%
            </span>
            <button
              type="button"
              onClick={() => setZoom((z) => Math.min(2.4, Number((z + 0.15).toFixed(2))))}
              aria-label={t('survey.zoomIn')}
              className="p-2 text-zinc-600 dark:text-zinc-400 hover:text-zinc-950 dark:hover:text-white"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => {
                setZoom(1);
                setPan({ x: 0, y: 0 });
              }}
              aria-label={t('survey.resetView')}
              title={t('survey.resetView')}
              className="p-2 border-s border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:text-zinc-950 dark:hover:text-white"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Hint & Adaptive Dimensions Bar */}
      <div className="text-xs text-zinc-600 dark:text-zinc-400 flex flex-wrap items-center justify-between gap-2">
        <span>
          {tool === 'select' && t('survey.hintSelect')}
          {tool === 'draw-wall' && t('survey.hintDrawWall')}
          {tool === 'draw-door' && t('survey.hintDrawDoor')}
          {tool === 'place-router' && t('survey.hintPlaceRouter')}
          {tool === 'pan' && t('survey.hintPan')}
        </span>
        <div className="flex items-center gap-3 shrink-0">
          <span
            data-testid="floor-canvas-dimensions"
            className="font-mono-tabular text-[11px] font-semibold text-zinc-900 dark:text-zinc-100"
          >
            {t('survey.floorDimensionsLabel')}: {floor.canvasWidth.toFixed(1)} × {floor.canvasHeight.toFixed(1)}{' '}
            {t('survey.metersUnit')}
          </span>
          {!routerOnThisFloor && (
            <button
              type="button"
              onClick={() =>
                onMoveRouter({
                  floorId: floor.id,
                  x: round1(floor.canvasWidth / 2),
                  y: round1(floor.canvasHeight / 2)
                })
              }
              className="text-xs font-semibold text-zinc-900 dark:text-zinc-100 underline underline-offset-2"
            >
              {t('survey.moveRouterHere')}
            </button>
          )}
        </div>
      </div>

      {/* Explicit Resize Boundary / Overlap Guard Notice */}
      {resizeWarningText && (
        <div
          data-testid="canvas-resize-warning"
          role="status"
          className="rounded-xl border border-zinc-300 dark:border-zinc-700 bg-zinc-100 dark:bg-zinc-900 px-3 py-2 flex items-center gap-2 text-xs font-medium text-zinc-900 dark:text-zinc-100"
        >
          <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-amber-600 dark:text-amber-400" aria-hidden="true" />
          <span>{resizeWarningText}</span>
        </div>
      )}

      {/* Adaptive Metric Interactive SVG Floor Plan */}
      <div
        className="relative rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 overflow-hidden w-full"
        style={{
          aspectRatio: `${floor.canvasWidth} / ${floor.canvasHeight}`,
          minHeight: '240px',
          maxHeight: '560px'
        }}
      >
        <svg
          ref={svgRef}
          viewBox={`${viewBox.x} ${viewBox.y} ${viewBox.w} ${viewBox.h}`}
          preserveAspectRatio="xMidYMid meet"
          data-testid="floorplan-canvas-svg"
          data-canvas-width={floor.canvasWidth}
          data-canvas-height={floor.canvasHeight}
          onPointerDown={handleSvgPointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          style={{ touchAction: 'none' }}
          className={`w-full h-full block select-none ${
            tool === 'pan' ? 'cursor-grab' : tool === 'select' ? 'cursor-default' : 'cursor-crosshair'
          }`}
        >
          <defs>
            <pattern id="fp-metric-grid" width="1" height="1" patternUnits="userSpaceOnUse">
              <path
                d="M 1 0 L 0 0 0 1"
                fill="none"
                stroke={isDark ? '#27272A' : '#E4E4E7'}
                strokeWidth={0.04 * unitScale}
              />
            </pattern>
            <radialGradient id="approx-router-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor={isDark ? '#E4E4E7' : '#18181B'} stopOpacity="0.14" />
              <stop offset="70%" stopColor={isDark ? '#E4E4E7' : '#18181B'} stopOpacity="0.04" />
              <stop offset="100%" stopColor={isDark ? '#E4E4E7' : '#18181B'} stopOpacity="0" />
            </radialGradient>
          </defs>

          <rect
            x="0"
            y="0"
            width={floor.canvasWidth}
            height={floor.canvasHeight}
            fill="url(#fp-metric-grid)"
            data-bg="true"
          />

          {/* Rooms Layer (NO DRAGGING — Click/Tap selects & opens Rename/Options; Edge handles resize safely) */}
          {floor.rooms.map((room) => {
            const latest = getLatestRoomMeasurement(measurements, room.id, activeScenarioId);
            const metricClassification = classifyRoomHeatmapMetric(latest, heatmapMetric);
            const tierStyle = HEATMAP_STYLES[metricClassification.tier];
            const isSelected = selectedRoomId === room.id;

            const minDim = Math.min(room.width, room.height);
            const nameFontSize = Math.max(0.28, Math.min(0.46, minDim * 0.135));
            const metricFontSize = Math.max(0.24, Math.min(0.38, minDim * 0.115));
            const dimsFontSize = Math.max(0.21, Math.min(0.32, minDim * 0.095));

            const centerX = room.x + room.width / 2;
            const hasEnoughHeightForThirdLine = room.height >= 2.7;

            return (
              <g
                key={room.id}
                data-testid={`room-node-${room.id}`}
                data-room-x={room.x}
                data-room-y={room.y}
                data-room-width={room.width}
                data-room-height={room.height}
                onClick={(e) => {
                  if (tool !== 'select') return;
                  if (suppressNextRoomClickRef.current) {
                    suppressNextRoomClickRef.current = false;
                    return;
                  }
                  e.stopPropagation();
                  onSelectRoom(room.id);
                  onSelectSegment(null);
                  openRenameForRoom(room);
                }}
                className={tool === 'select' ? 'group cursor-pointer' : undefined}
              >
                <rect
                  x={room.x}
                  y={room.y}
                  width={room.width}
                  height={room.height}
                  rx="0.16"
                  fill={isDark ? tierStyle.fillDark : tierStyle.fillLight}
                  fillOpacity={metricClassification.tier === 'unmeasured' ? 0.94 : isDark ? 0.55 : 0.85}
                  stroke={
                    isSelected
                      ? isDark
                        ? '#FAFAFA'
                        : '#09090B'
                      : isDark
                      ? tierStyle.strokeDark
                      : tierStyle.strokeLight
                  }
                  strokeWidth={isSelected ? 0.14 * unitScale : 0.08 * unitScale}
                />

                {/* Room Name */}
                <text
                  x={centerX}
                  y={room.y + room.height * (hasEnoughHeightForThirdLine ? 0.34 : 0.42)}
                  textAnchor="middle"
                  fontSize={nameFontSize}
                  fontWeight="700"
                  fill={isDark ? '#FAFAFA' : '#09090B'}
                  pointerEvents="none"
                >
                  {room.name.length > 15 ? `${room.name.slice(0, 14)}…` : room.name}
                </text>

                {/* Measured Wi-Fi Performance OR Honest Unmeasured Status */}
                <text
                  x={centerX}
                  y={room.y + room.height * (hasEnoughHeightForThirdLine ? 0.58 : 0.72)}
                  textAnchor="middle"
                  fontSize={metricFontSize}
                  fontWeight="600"
                  fill={isDark ? tierStyle.textDark : tierStyle.textLight}
                  pointerEvents="none"
                >
                  {metricClassification.valueText ?? t('survey.unmeasuredShort')}
                </text>

                {/* Room Metric Dimensions (W × H m) */}
                {hasEnoughHeightForThirdLine && (
                  <text
                    x={centerX}
                    y={room.y + room.height * 0.81}
                    textAnchor="middle"
                    fontSize={dimsFontSize}
                    fontWeight="500"
                    fill={isDark ? '#A1A1AA' : '#52525B'}
                    pointerEvents="none"
                  >
                    {`${room.width.toFixed(1)} × ${room.height.toFixed(1)} ${t('survey.metersUnit')}`}
                  </text>
                )}
              </g>
            );
          })}

          {/* Approximate Coverage Area (Explicitly Estimated, NEVER measured) */}
          {routerOnThisFloor && routerPlacement.showApproxCoverage && (
            <g pointerEvents="none">
              <circle
                cx={routerPlacement.x}
                cy={routerPlacement.y}
                r={approxRadiusMeters}
                fill="url(#approx-router-glow)"
              />
              <circle
                cx={routerPlacement.x}
                cy={routerPlacement.y}
                r={approxRadiusMeters}
                fill="none"
                stroke={isDark ? '#A1A1AA' : '#52525B'}
                strokeOpacity="0.45"
                strokeWidth={0.07 * unitScale}
                strokeDasharray="0.28 0.24"
              />
            </g>
          )}

          {/* Walls & Doors Layer */}
          {floor.segments.map((seg) => {
            const isSel = seg.id === selectedSegmentId;
            const strokeColor =
              seg.kind === 'door'
                ? isDark
                  ? '#FBBF24'
                  : '#B45309'
                : seg.material === 'concrete'
                ? isDark
                  ? '#D4D4D8'
                  : '#09090B'
                : seg.material === 'brick'
                ? isDark
                  ? '#71717A'
                  : '#3F3F46'
                : isDark
                ? '#52525B'
                : '#71717A';

            return (
              <g key={seg.id}>
                <line
                  x1={seg.x1}
                  y1={seg.y1}
                  x2={seg.x2}
                  y2={seg.y2}
                  stroke="transparent"
                  strokeWidth="0.34"
                  pointerEvents={drag ? 'none' : 'auto'}
                  className={tool === 'select' ? 'cursor-pointer' : undefined}
                  onPointerDown={(e) => {
                    if (tool !== 'select') return;
                    e.stopPropagation();
                    onSelectSegment(seg.id);
                    onSelectRoom(null);
                  }}
                />
                <line
                  x1={seg.x1}
                  y1={seg.y1}
                  x2={seg.x2}
                  y2={seg.y2}
                  stroke={isSel ? (isDark ? '#FAFAFA' : '#09090B') : strokeColor}
                  strokeWidth={
                    seg.kind === 'door'
                      ? 0.14 * unitScale
                      : seg.material === 'concrete'
                      ? 0.18 * unitScale
                      : 0.11 * unitScale
                  }
                  strokeDasharray={seg.kind === 'door' ? '0.24 0.16' : undefined}
                  strokeLinecap="round"
                  pointerEvents="none"
                />

                {isSel && tool === 'select' && (
                  <>
                    <circle
                      cx={seg.x1}
                      cy={seg.y1}
                      r="0.24"
                      fill={isDark ? '#FAFAFA' : '#09090B'}
                      stroke={isDark ? '#09090B' : '#FFFFFF'}
                      strokeWidth="0.06"
                      className="cursor-move"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        svgRef.current?.setPointerCapture(e.pointerId);
                        setDrag({
                          kind: 'move-segment-end',
                          segmentId: seg.id,
                          end: 'p1',
                          beforeFloor: floor
                        });
                      }}
                    />
                    <circle
                      cx={seg.x2}
                      cy={seg.y2}
                      r="0.24"
                      fill={isDark ? '#FAFAFA' : '#09090B'}
                      stroke={isDark ? '#09090B' : '#FFFFFF'}
                      strokeWidth="0.06"
                      className="cursor-move"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        svgRef.current?.setPointerCapture(e.pointerId);
                        setDrag({
                          kind: 'move-segment-end',
                          segmentId: seg.id,
                          end: 'p2',
                          beforeFloor: floor
                        });
                      }}
                    />
                  </>
                )}
              </g>
            );
          })}

          {/* In-progress Draw Preview */}
          {drag?.kind === 'draw-segment' && (
            <line
              x1={drag.x1}
              y1={drag.y1}
              x2={drag.x2}
              y2={drag.y2}
              stroke={drag.segKind === 'door' ? '#B45309' : isDark ? '#FAFAFA' : '#09090B'}
              strokeWidth="0.16"
              strokeDasharray={drag.segKind === 'door' ? '0.22 0.16' : undefined}
              pointerEvents="none"
            />
          )}

          {/* Subtle Architectural Corridor Strip when corridor mode or template is enabled */}
          {(floor.includeCorridor || floor.layoutTemplate === 'corridor') && floor.rooms.length >= 2 && (
            <g pointerEvents="none">
              {(() => {
                const ys = [...new Set(floor.rooms.map((r) => round1(r.y)))].sort((a, b) => a - b);
                if (ys.length < 2) return null;
                const upperRooms = floor.rooms.filter((r) => round1(r.y) === ys[0]);
                const maxUpperBottom = Math.max(...upperRooms.map((r) => r.y + r.height));
                const nextRowY = ys.find((y) => y > maxUpperBottom + 0.5);
                if (!nextRowY) return null;
                const minX = Math.min(...floor.rooms.map((r) => r.x));
                const maxX = Math.max(...floor.rooms.map((r) => r.x + r.width));
                const stripY = round1(maxUpperBottom + 0.15);
                const stripH = round1(nextRowY - maxUpperBottom - 0.3);
                if (stripH < 0.7) return null;
                return (
                  <g>
                    <rect
                      x={minX}
                      y={stripY}
                      width={round1(maxX - minX)}
                      height={stripH}
                      rx="0.12"
                      fill={isDark ? '#18181B' : '#F4F4F5'}
                      stroke={isDark ? '#3F3F46' : '#D4D4D8'}
                      strokeWidth={0.05 * unitScale}
                      strokeDasharray="0.2 0.16"
                    />
                    <text
                      x={minX + (maxX - minX) / 2}
                      y={stripY + stripH / 2 + 0.12}
                      textAnchor="middle"
                      fontSize={Math.min(0.32, stripH * 0.35)}
                      fontWeight="600"
                      fill={isDark ? '#71717A' : '#71717A'}
                    >
                      {t('survey.roomTypes.corridor')}
                    </text>
                  </g>
                );
              })()}
            </g>
          )}

          {/* Interactive Room Resize Handles Overlay Layer (ALL 4 Edges & ALL 4 Corners of EVERY Room, inset so neighboring handles NEVER overlap across 0.2m walls) */}
          {tool === 'select' &&
            [...floor.rooms]
              .sort((a, b) => (a.id === selectedRoomId ? 1 : b.id === selectedRoomId ? -1 : 0))
              .map((room) => {
                const isSelected = selectedRoomId === room.id;
                const cornerHit = 0.52;
                const overhang = 0.08;
                const edgeThick = 0.44;
                const handleOpacity = isSelected ? 'opacity-100' : 'opacity-45 hover:opacity-100 transition-opacity';

                const startHandleResize = (
                  e: React.PointerEvent<SVGElement>,
                  axis: ResizeHandleDirection
                ) => {
                  e.stopPropagation();
                  onSelectRoom(room.id);
                  onSelectSegment(null);
                  const svg = svgRef.current;
                  const rect = svg?.getBoundingClientRect();
                  const pxPerMeterX = rect && rect.width > 0 ? rect.width / viewBox.w : 40;
                  const pxPerMeterY = rect && rect.height > 0 ? rect.height / viewBox.h : 40;
                  try {
                    svg?.setPointerCapture(e.pointerId);
                  } catch {
                    // Window pointer listeners handle capture fallback cleanly
                  }
                  setDrag({
                    kind: 'resize-room',
                    roomId: room.id,
                    axis,
                    startClientX: e.clientX,
                    startClientY: e.clientY,
                    pxPerMeterX,
                    pxPerMeterY,
                    origWidth: room.width,
                    origHeight: room.height,
                    beforeFloor: floor,
                    moved: false
                  });
                };

                const gripFill = isDark ? '#FAFAFA' : '#09090B';
                const gripStroke = isDark ? '#09090B' : '#FFFFFF';

                return (
                  <g key={`handles_${room.id}`} className={handleOpacity}>
                    {/* Top Edge Handle */}
                    <rect
                      x={room.x + cornerHit}
                      y={room.y - overhang}
                      width={Math.max(0.4, room.width - cornerHit * 2)}
                      height={edgeThick}
                      fill="transparent"
                      className="cursor-ns-resize"
                      data-testid={`room-handle-${room.id}-top`}
                      onClick={(e) => e.stopPropagation()}
                      onPointerDown={(e) => startHandleResize(e, 'top')}
                    />
                    <rect
                      x={room.x + room.width / 2 - 0.3}
                      y={room.y + 0.02}
                      width="0.6"
                      height="0.14"
                      rx="0.05"
                      fill={gripFill}
                      stroke={gripStroke}
                      strokeWidth="0.04"
                      pointerEvents="none"
                    />

                    {/* Right Edge Handle */}
                    <rect
                      x={room.x + room.width + overhang - edgeThick}
                      y={room.y + cornerHit}
                      width={edgeThick}
                      height={Math.max(0.4, room.height - cornerHit * 2)}
                      fill="transparent"
                      className="cursor-ew-resize"
                      data-testid={`room-handle-${room.id}-right`}
                      onClick={(e) => e.stopPropagation()}
                      onPointerDown={(e) => startHandleResize(e, 'right')}
                    />
                    <rect
                      x={room.x + room.width - 0.16}
                      y={room.y + room.height / 2 - 0.3}
                      width="0.14"
                      height="0.6"
                      rx="0.05"
                      fill={gripFill}
                      stroke={gripStroke}
                      strokeWidth="0.04"
                      pointerEvents="none"
                    />

                    {/* Bottom Edge Handle */}
                    <rect
                      x={room.x + cornerHit}
                      y={room.y + room.height + overhang - edgeThick}
                      width={Math.max(0.4, room.width - cornerHit * 2)}
                      height={edgeThick}
                      fill="transparent"
                      className="cursor-ns-resize"
                      data-testid={`room-handle-${room.id}-bottom`}
                      onClick={(e) => e.stopPropagation()}
                      onPointerDown={(e) => startHandleResize(e, 'bottom')}
                    />
                    <rect
                      x={room.x + room.width / 2 - 0.3}
                      y={room.y + room.height - 0.16}
                      width="0.6"
                      height="0.14"
                      rx="0.05"
                      fill={gripFill}
                      stroke={gripStroke}
                      strokeWidth="0.04"
                      pointerEvents="none"
                    />

                    {/* Left Edge Handle */}
                    <rect
                      x={room.x - overhang}
                      y={room.y + cornerHit}
                      width={edgeThick}
                      height={Math.max(0.4, room.height - cornerHit * 2)}
                      fill="transparent"
                      className="cursor-ew-resize"
                      data-testid={`room-handle-${room.id}-left`}
                      onClick={(e) => e.stopPropagation()}
                      onPointerDown={(e) => startHandleResize(e, 'left')}
                    />
                    <rect
                      x={room.x + 0.02}
                      y={room.y + room.height / 2 - 0.3}
                      width="0.14"
                      height="0.6"
                      rx="0.05"
                      fill={gripFill}
                      stroke={gripStroke}
                      strokeWidth="0.04"
                      pointerEvents="none"
                    />

                    {/* Top-Left Corner Handle */}
                    <rect
                      x={room.x - overhang}
                      y={room.y - overhang}
                      width={cornerHit}
                      height={cornerHit}
                      fill="transparent"
                      className="cursor-nwse-resize"
                      data-testid={`room-handle-${room.id}-tl`}
                      onClick={(e) => e.stopPropagation()}
                      onPointerDown={(e) => startHandleResize(e, 'tl')}
                    />
                    <rect
                      x={room.x + 0.02}
                      y={room.y + 0.02}
                      width="0.26"
                      height="0.26"
                      rx="0.05"
                      fill={gripFill}
                      stroke={gripStroke}
                      strokeWidth="0.04"
                      pointerEvents="none"
                    />

                    {/* Top-Right Corner Handle */}
                    <rect
                      x={room.x + room.width + overhang - cornerHit}
                      y={room.y - overhang}
                      width={cornerHit}
                      height={cornerHit}
                      fill="transparent"
                      className="cursor-nesw-resize"
                      data-testid={`room-handle-${room.id}-tr`}
                      onClick={(e) => e.stopPropagation()}
                      onPointerDown={(e) => startHandleResize(e, 'tr')}
                    />
                    <rect
                      x={room.x + room.width - 0.28}
                      y={room.y + 0.02}
                      width="0.26"
                      height="0.26"
                      rx="0.05"
                      fill={gripFill}
                      stroke={gripStroke}
                      strokeWidth="0.04"
                      pointerEvents="none"
                    />

                    {/* Bottom-Right Corner Handle */}
                    <rect
                      x={room.x + room.width + overhang - cornerHit}
                      y={room.y + room.height + overhang - cornerHit}
                      width={cornerHit}
                      height={cornerHit}
                      fill="transparent"
                      className="cursor-nwse-resize"
                      data-testid={`room-handle-${room.id}-br`}
                      onClick={(e) => e.stopPropagation()}
                      onPointerDown={(e) => startHandleResize(e, 'br')}
                    />
                    <rect
                      x={room.x + room.width - 0.28}
                      y={room.y + room.height - 0.28}
                      width="0.26"
                      height="0.26"
                      rx="0.05"
                      fill={gripFill}
                      stroke={gripStroke}
                      strokeWidth="0.04"
                      pointerEvents="none"
                    />

                    {/* Bottom-Left Corner Handle */}
                    <rect
                      x={room.x - overhang}
                      y={room.y + room.height + overhang - cornerHit}
                      width={cornerHit}
                      height={cornerHit}
                      fill="transparent"
                      className="cursor-nesw-resize"
                      data-testid={`room-handle-${room.id}-bl`}
                      onClick={(e) => e.stopPropagation()}
                      onPointerDown={(e) => startHandleResize(e, 'bl')}
                    />
                    <rect
                      x={room.x + 0.02}
                      y={room.y + room.height - 0.28}
                      width="0.26"
                      height="0.26"
                      rx="0.05"
                      fill={gripFill}
                      stroke={gripStroke}
                      strokeWidth="0.04"
                      pointerEvents="none"
                    />
                  </g>
                );
              })}

          {/* Router Icon / Drag Target */}
          {routerOnThisFloor && (
            <g
              data-testid="router-marker"
              onClick={(e) => e.stopPropagation()}
              onPointerDown={(e) => {
                if (tool !== 'select' && tool !== 'place-router') return;
                e.stopPropagation();
                svgRef.current?.setPointerCapture(e.pointerId);
                setDrag({ kind: 'move-router' });
              }}
              className="cursor-grab"
            >
              <circle
                cx={routerPlacement.x}
                cy={routerPlacement.y}
                r={0.32 * unitScale}
                fill={isDark ? '#FAFAFA' : '#09090B'}
                stroke={isDark ? '#09090B' : '#FFFFFF'}
                strokeWidth={0.08 * unitScale}
              />
              <circle
                cx={routerPlacement.x}
                cy={routerPlacement.y}
                r={0.1 * unitScale}
                fill={isDark ? '#09090B' : '#FFFFFF'}
              />
              <rect
                x={routerPlacement.x - 0.85 * unitScale}
                y={routerPlacement.y + 0.38 * unitScale}
                width={1.7 * unitScale}
                height={0.42 * unitScale}
                rx="0.1"
                fill={isDark ? '#09090B' : '#FFFFFF'}
                fillOpacity="0.95"
                stroke={isDark ? '#3F3F46' : '#D4D4D8'}
                strokeWidth="0.04"
              />
              <text
                x={routerPlacement.x}
                y={routerPlacement.y + 0.67 * unitScale}
                textAnchor="middle"
                fontSize={0.26 * unitScale}
                fontWeight="700"
                fill={isDark ? '#FAFAFA' : '#09090B'}
                pointerEvents="none"
              >
                {t('homeMap.routerPin')}
              </text>
            </g>
          )}
        </svg>
      </div>

      {/* Heatmap Legend + Explicit Estimated Coverage Notice */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-zinc-600 dark:text-zinc-400">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#16A34A] inline-block" aria-hidden="true" />
            {t('survey.legendStrong')}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#EAB308] inline-block" aria-hidden="true" />
            {t('survey.legendModerate')}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#DC2626] inline-block" aria-hidden="true" />
            {t('survey.legendWeak')}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm border border-zinc-400 bg-white dark:bg-zinc-900 inline-block" aria-hidden="true" />
            {t('survey.legendUnmeasured')}
          </span>
        </div>
        {routerOnThisFloor && routerPlacement.showApproxCoverage && (
          <span className="text-[11px] font-medium text-zinc-700 dark:text-zinc-300">
            {t('survey.approxCoverageLabel')}
          </span>
        )}
      </div>

      {/* Click-on-Room Quick Rename Modal / Popover (Never moves the room) */}
      {renameTargetRoom && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/50 backdrop-blur-[2px] p-4"
          onClick={closeRenameModal}
          role="dialog"
          aria-modal="true"
          aria-labelledby="rename-room-modal-title"
          data-testid="rename-room-modal"
        >
          <form
            onSubmit={handleSaveRename}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl p-5 space-y-4"
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Pencil className="w-4 h-4 text-zinc-900 dark:text-zinc-100" aria-hidden="true" />
                <h3
                  id="rename-room-modal-title"
                  className="text-sm font-bold text-zinc-950 dark:text-zinc-50"
                >
                  {t('survey.renameModalTitle')}
                </h3>
              </div>
              <button
                type="button"
                onClick={closeRenameModal}
                aria-label={t('app.cancel')}
                className="p-1.5 rounded-lg text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 px-3 py-2 flex items-center justify-between text-xs">
              <span className="text-zinc-500 dark:text-zinc-400">{t('survey.currentRoomName')}:</span>
              <span className="font-semibold text-zinc-900 dark:text-zinc-100">{renameTargetRoom.name}</span>
            </div>

            <div>
              <label
                htmlFor="rename-modal-input"
                className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5"
              >
                {t('survey.newRoomNameLabel')}
              </label>
              <input
                id="rename-modal-input"
                data-testid="rename-modal-input"
                type="text"
                autoFocus
                maxLength={48}
                value={renameDraft}
                onChange={(e) => setRenameDraft(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-950 text-sm text-zinc-950 dark:text-zinc-50 focus:outline-none focus:ring-2 focus:ring-zinc-900 dark:focus:ring-zinc-100"
              />
            </div>

            <div>
              <div className="text-xs font-medium text-zinc-700 dark:text-zinc-300 mb-1.5">
                {t('survey.quickPresetsLabel')}
              </div>
              <div className="flex flex-wrap gap-1.5">
                {QUICK_PRESET_CATEGORIES.map((cat) => {
                  const activeCat = categoryDraft === cat;
                  const presetLabel = t(`survey.roomTypes.${cat}`);
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => {
                        setCategoryDraft(cat);
                        if (!renameDraft.trim() || QUICK_PRESET_CATEGORIES.some((c) => t(`survey.roomTypes.${c}`) === renameDraft)) {
                          setRenameDraft(presetLabel);
                        }
                      }}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                        activeCat
                          ? 'bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 border-zinc-900 dark:border-zinc-100'
                          : 'bg-zinc-50 dark:bg-zinc-950 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-800 hover:border-zinc-400'
                      }`}
                    >
                      {presetLabel}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-200 dark:border-zinc-800">
              <button
                type="button"
                data-testid="rename-cancel-btn"
                onClick={closeRenameModal}
                className="px-4 min-h-[40px] rounded-xl border border-zinc-300 dark:border-zinc-700 text-xs font-semibold text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800"
              >
                {t('app.cancel')}
              </button>
              <button
                type="submit"
                data-testid="rename-save-btn"
                className="px-4 min-h-[40px] rounded-xl bg-zinc-900 dark:bg-zinc-100 hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-zinc-900 text-xs font-semibold"
              >
                {t('app.save')}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
