import React, { useRef, useState } from 'react';
import {
  Activity,
  AlertCircle,
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  Footprints,
  History,
  Lock,
  Minus,
  Pencil,
  Play,
  Plus,
  Square,
  Trash2,
  Wifi
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useI18n } from '../../i18n';
import {
  DeviceSignalSnapshot,
  formatConnectionSummary,
  WifiBandTag
} from '../../services/networkSignalInfo';
import { runLiveSpeedTest, SpeedTestMeasurement, SpeedTestProgress } from '../../services/speedTest';
import {
  computeMeasurementDelta,
  FloorPlan,
  FloorRoom,
  getLatestRoomMeasurement,
  getRoomMeasurementHistory,
  MAX_ROOM_M,
  MIN_ROOM_M,
  RoomCategory,
  RoomMeasurementRecord,
  RoomResizeResult,
  RouterScenarioId,
  round1
} from '../../utils/floorPlanEngine';

interface RoomInspectorAndMeasureProps {
  floor: FloorPlan;
  room: FloorRoom | null;
  scenarioId: RouterScenarioId;
  measurements: RoomMeasurementRecord[];
  signalSnapshot: DeviceSignalSnapshot;
  resizeNotice: RoomResizeResult | null;
  onRenameRoom: (roomId: string, nextName: string, nextCategory?: RoomCategory) => void;
  onRequestRenameModal: (roomId: string) => void;
  onResizeRoom: (roomId: string, nextWidthM: number, nextHeightM: number) => void;
  onDeleteRoom: (roomId: string) => void;
  onSaveMeasurement: (record: RoomMeasurementRecord) => void;
  onDeleteRoomMeasurements: (roomId: string) => void;
}

const ROOM_CATEGORIES: RoomCategory[] = [
  'living',
  'bedroom',
  'kitchen',
  'bathroom',
  'corridor',
  'office',
  'custom'
];

export const RoomInspectorAndMeasure: React.FC<RoomInspectorAndMeasureProps> = ({
  floor,
  room,
  scenarioId,
  measurements,
  signalSnapshot,
  resizeNotice,
  onRenameRoom,
  onRequestRenameModal,
  onResizeRoom,
  onDeleteRoom,
  onSaveMeasurement,
  onDeleteRoomMeasurements
}) => {
  const { recordSpeedTest, routerSession } = useApp();
  const { t, language } = useI18n();

  const [bandTag, setBandTag] = useState<WifiBandTag>('unknown');
  const [testing, setTesting] = useState(false);
  const [progress, setProgress] = useState<SpeedTestProgress | null>(null);
  const [testError, setTestError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const locale = language === 'ar' ? 'ar-EG' : language === 'fr' ? 'fr-FR' : 'en-US';

  if (!room) {
    return (
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-6 flex flex-col justify-center items-center text-center min-h-[240px] space-y-2.5">
        <Footprints className="w-7 h-7 text-zinc-900 dark:text-zinc-100" aria-hidden="true" />
        <h3 className="text-sm font-semibold text-zinc-950 dark:text-zinc-50">
          {t('survey.selectRoomPromptTitle')}
        </h3>
        <p className="text-xs text-zinc-600 dark:text-zinc-400 max-w-sm leading-relaxed">
          {t('survey.selectRoomPromptBody')}
        </p>
      </div>
    );
  }

  const latest = getLatestRoomMeasurement(measurements, room.id, scenarioId);
  const history = getRoomMeasurementHistory(measurements, room.id, scenarioId);
  const previous = history[1];
  const delta = latest ? computeMeasurementDelta(latest, previous) : null;

  const formatResizeWarning = (notice: RoomResizeResult): string | null => {
    if (notice.reason === 'none') return null;
    if (notice.reason === 'blocked_by_neighbor') {
      return t('survey.resizeBlockedNeighbor').replace('{room}', notice.blockingRoomName ?? '');
    }
    if (notice.reason === 'floor_limit') return t('survey.resizeBlockedFloor');
    if (notice.reason === 'min_limit') return t('survey.resizeMinLimit');
    if (notice.reason === 'max_limit') return t('survey.resizeMaxLimit');
    return null;
  };

  const resizeWarningText =
    resizeNotice && resizeNotice.room.id === room.id ? formatResizeWarning(resizeNotice) : null;

  const handleStartMeasure = async () => {
    if (testing) return;
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setTesting(true);
    setTestError(null);
    setProgress(null);

    try {
      const result: SpeedTestMeasurement = await runLiveSpeedTest((p) => {
        setProgress(p);
      }, ctrl.signal);

      const routerRssi =
        typeof routerSession?.routerInfo.signalStrengthDbm === 'number'
          ? routerSession.routerInfo.signalStrengthDbm
          : null;

      const record: RoomMeasurementRecord = {
        id: result.id,
        scenarioId,
        floorId: floor.id,
        floorName: floor.name,
        roomId: room.id,
        roomName: room.name,
        measuredAtIso: result.measuredAtIso,
        serverName: result.serverName,
        downloadMbps: result.downloadMbps,
        uploadMbps: result.uploadMbps,
        pingMs: result.pingMs,
        jitterMs: result.jitterMs,
        packetLossPct: result.packetLossPct,
        bandUsed: bandTag,
        signalStrengthDbm: routerRssi,
        connectionSummary: formatConnectionSummary(signalSnapshot),
        totalBytesTransferred: result.totalBytesTransferred,
        durationSec: Number(
          ((result.downloadDurationSec ?? 0) + (result.uploadDurationSec ?? 0)).toFixed(1)
        )
      };

      onSaveMeasurement(record);
      await recordSpeedTest(result);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'SERVER_UNREACHABLE';
      if (msg !== 'ABORTED') {
        const errKey =
          msg === 'INTERNET_OFFLINE'
            ? 'speed.errorOffline'
            : msg === 'CONNECTION_DROPPED'
            ? 'speed.errorDropped'
            : 'speed.errorServer';
        setTestError(t(errKey));
      }
    } finally {
      abortRef.current = null;
      setTesting(false);
    }
  };

  const handleCancel = () => {
    abortRef.current?.abort();
  };

  const phaseText = progress
    ? progress.phase === 'idle'
      ? t('speed.phaseIdle')
      : progress.phase === 'cancelled'
      ? t('speed.phaseCancelled')
      : progress.phase === 'error'
      ? t('speed.phaseError')
      : t(`speed.steps.${progress.phase}`)
    : t('speed.phaseIdle');

  return (
    <div className="space-y-4 min-w-0">
      {/* Room Details & Independent Safe Dimensions Card */}
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 space-y-3.5">
        <div className="flex items-center justify-between gap-2">
          <h3 className="text-sm font-semibold text-zinc-950 dark:text-zinc-50">
            {t('survey.roomProperties')}
          </h3>
          <div className="flex items-center gap-3">
            <button
              type="button"
              disabled={testing}
              data-testid="inspector-rename-btn"
              onClick={() => onRequestRenameModal(room.id)}
              className="inline-flex items-center gap-1 text-xs font-medium text-zinc-700 dark:text-zinc-300 hover:text-zinc-950 dark:hover:text-white disabled:opacity-50"
            >
              <Pencil className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t('survey.openRenameBtn')}</span>
            </button>
            {floor.rooms.length > 1 && (
              <button
                type="button"
                disabled={testing}
                data-testid="delete-room-btn"
                onClick={() => onDeleteRoom(room.id)}
                className="inline-flex items-center gap-1 text-xs font-medium text-red-600 dark:text-red-400 hover:underline disabled:opacity-50"
              >
                <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{t('survey.deleteRoom')}</span>
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label htmlFor="room-name-input" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
              {t('survey.roomNameLabel')}
            </label>
            <input
              id="room-name-input"
              type="text"
              value={room.name}
              disabled={testing}
              maxLength={48}
              onChange={(e) => onRenameRoom(room.id, e.target.value, room.category)}
              className="w-full px-3 min-h-[40px] rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm text-zinc-950 dark:text-zinc-50"
            />
          </div>

          <div>
            <label htmlFor="room-cat-select" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
              {t('survey.roomTypeLabel')}
            </label>
            <select
              id="room-cat-select"
              value={room.category}
              disabled={testing}
              onChange={(e) => onRenameRoom(room.id, room.name, e.target.value as RoomCategory)}
              className="w-full px-3 min-h-[40px] rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-sm text-zinc-950 dark:text-zinc-50"
            >
              {ROOM_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {t(`survey.roomTypes.${cat}`)}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Fixed Origin Readout */}
        <div
          data-testid="room-fixed-origin"
          className="rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 px-3 py-2 flex items-center justify-between gap-2 text-xs"
        >
          <span className="inline-flex items-center gap-1.5 text-zinc-600 dark:text-zinc-400">
            <Lock className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{t('survey.fixedOriginLabel')}</span>
          </span>
          <span className="font-mono-tabular font-semibold text-zinc-900 dark:text-zinc-100">
            ({room.x.toFixed(1)}, {room.y.toFixed(1)}) {t('survey.metersUnit')}
          </span>
        </div>

        {/* Independent Width (m) & Length (m) Steppers */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label htmlFor="room-width-input" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
              {t('survey.roomWidthLabel')}
            </label>
            <div className="flex items-center gap-1">
              <button
                type="button"
                disabled={testing}
                data-testid="room-width-dec"
                aria-label={`${t('survey.roomWidthLabel')} -0.5`}
                onClick={() => onResizeRoom(room.id, round1(room.width - 0.5), room.height)}
                className="min-w-[40px] min-h-[40px] rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 hover:bg-zinc-100 dark:hover:bg-zinc-800 flex items-center justify-center text-zinc-900 dark:text-zinc-100 disabled:opacity-40"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <input
                id="room-width-input"
                data-testid="room-width-input"
                type="number"
                step="0.2"
                min={MIN_ROOM_M}
                max={MAX_ROOM_M}
                value={room.width}
                disabled={testing}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  if (!Number.isNaN(val)) onResizeRoom(room.id, val, room.height);
                }}
                className="w-full px-2.5 min-h-[40px] text-center rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-xs font-mono-tabular font-semibold text-zinc-950 dark:text-zinc-50"
              />
              <button
                type="button"
                disabled={testing}
                data-testid="room-width-inc"
                aria-label={`${t('survey.roomWidthLabel')} +0.5`}
                onClick={() => onResizeRoom(room.id, round1(room.width + 0.5), room.height)}
                className="min-w-[40px] min-h-[40px] rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 hover:bg-zinc-100 dark:hover:bg-zinc-800 flex items-center justify-center text-zinc-900 dark:text-zinc-100 disabled:opacity-40"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div>
            <label htmlFor="room-height-input" className="block text-xs font-medium text-zinc-600 dark:text-zinc-400 mb-1">
              {t('survey.roomHeightLabel')}
            </label>
            <div className="flex items-center gap-1">
              <button
                type="button"
                disabled={testing}
                data-testid="room-height-dec"
                aria-label={`${t('survey.roomHeightLabel')} -0.5`}
                onClick={() => onResizeRoom(room.id, room.width, round1(room.height - 0.5))}
                className="min-w-[40px] min-h-[40px] rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 hover:bg-zinc-100 dark:hover:bg-zinc-800 flex items-center justify-center text-zinc-900 dark:text-zinc-100 disabled:opacity-40"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <input
                id="room-height-input"
                data-testid="room-height-input"
                type="number"
                step="0.2"
                min={MIN_ROOM_M}
                max={MAX_ROOM_M}
                value={room.height}
                disabled={testing}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  if (!Number.isNaN(val)) onResizeRoom(room.id, room.width, val);
                }}
                className="w-full px-2.5 min-h-[40px] text-center rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 text-xs font-mono-tabular font-semibold text-zinc-950 dark:text-zinc-50"
              />
              <button
                type="button"
                disabled={testing}
                data-testid="room-height-inc"
                aria-label={`${t('survey.roomHeightLabel')} +0.5`}
                onClick={() => onResizeRoom(room.id, room.width, round1(room.height + 0.5))}
                className="min-w-[40px] min-h-[40px] rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 hover:bg-zinc-100 dark:hover:bg-zinc-800 flex items-center justify-center text-zinc-900 dark:text-zinc-100 disabled:opacity-40"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {resizeWarningText && (
          <div
            data-testid="resize-feedback-banner"
            role="status"
            className="rounded-xl border border-zinc-300 dark:border-zinc-700 bg-zinc-100 dark:bg-zinc-950 px-3 py-2 flex items-start gap-2 text-xs text-zinc-900 dark:text-zinc-100"
          >
            <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" aria-hidden="true" />
            <span>{resizeWarningText}</span>
          </div>
        )}
      </div>

      {/* Physical Walk-In & Real Measurement Workflow */}
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-4 space-y-4">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 flex items-center justify-center shrink-0">
            <Footprints className="w-4 h-4" aria-hidden="true" />
          </div>
          <div className="min-w-0">
            <h3 className="text-sm font-semibold text-zinc-950 dark:text-zinc-50">
              {t('survey.measureTitle')} · {room.name}
            </h3>
            <p className="text-xs text-zinc-600 dark:text-zinc-400 mt-1 leading-relaxed">
              {t('survey.physicalInstruction')
                .replace('{room}', room.name)
                .replace('{floor}', floor.name)}
            </p>
          </div>
        </div>

        {/* Strict Separation: Wi-Fi Signal vs Internet Speed */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 p-3 space-y-1">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-zinc-950 dark:text-zinc-50">
              <Wifi className="w-3.5 h-3.5 text-zinc-700 dark:text-zinc-300" aria-hidden="true" />
              <span>{t('survey.wifiSignalCardTitle')}</span>
            </div>
            <div className="text-xs text-zinc-600 dark:text-zinc-400">
              {signalSnapshot.routerReportedRssiDbm !== null ? (
                <span className="font-mono-tabular font-semibold text-zinc-950 dark:text-zinc-50">
                  {signalSnapshot.routerReportedRssiDbm} dBm ({t('survey.routerReportedTag')})
                </span>
              ) : (
                <span>{t('survey.unavailableOnDevice')}</span>
              )}
            </div>
          </div>

          <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 p-3 space-y-1">
            <label htmlFor="measure-band-select" className="block text-xs font-semibold text-zinc-950 dark:text-zinc-50">
              {t('survey.bandTagLabel')}
            </label>
            <select
              id="measure-band-select"
              value={bandTag}
              disabled={testing}
              onChange={(e) => setBandTag(e.target.value as WifiBandTag)}
              className="w-full px-2 py-1 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-xs text-zinc-950 dark:text-zinc-50"
            >
              <option value="unknown">{t('survey.bandTagUnknown')}</option>
              <option value="2.4GHz">2.4 GHz</option>
              <option value="5GHz">5 GHz</option>
            </select>
          </div>
        </div>

        {/* Manual Trigger */}
        <div className="flex flex-wrap items-center gap-2.5">
          {!testing ? (
            <button
              type="button"
              data-testid="start-room-measure-btn"
              onClick={handleStartMeasure}
              className="inline-flex items-center gap-2 px-4 min-h-[42px] rounded-xl bg-zinc-900 dark:bg-zinc-100 hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-zinc-900 text-xs sm:text-sm font-semibold transition-colors"
            >
              <Play className="w-4 h-4" aria-hidden="true" />
              <span>{latest ? t('survey.repeatMeasureBtn') : t('survey.startMeasureBtn')}</span>
            </button>
          ) : (
            <button
              type="button"
              data-testid="cancel-room-measure-btn"
              onClick={handleCancel}
              className="inline-flex items-center gap-2 px-4 min-h-[42px] rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs sm:text-sm font-semibold transition-colors"
            >
              <Square className="w-4 h-4" aria-hidden="true" />
              <span>{t('speed.cancelTest')}</span>
            </button>
          )}

          {history.length > 0 && !testing && (
            <button
              type="button"
              onClick={() => onDeleteRoomMeasurements(room.id)}
              className="inline-flex items-center gap-1.5 px-3 min-h-[40px] rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-600 dark:text-zinc-400 hover:text-red-600"
            >
              <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t('survey.clearRoomHistory')}</span>
            </button>
          )}
        </div>

        {testing && progress && (
          <div data-testid="room-measure-progress" className="rounded-xl border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-950 p-3.5 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-zinc-950 dark:text-zinc-50 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5" aria-hidden="true" />
                {phaseText}
              </span>
              <span className="font-mono-tabular text-zinc-600 dark:text-zinc-400">
                {progress.progressPct}% · {progress.elapsedSec}s
              </span>
            </div>
            <div className="h-2 rounded-full bg-zinc-200 dark:bg-zinc-800 overflow-hidden">
              <div
                className="h-full bg-zinc-900 dark:bg-zinc-100"
                style={{ width: `${Math.min(100, Math.max(2, progress.progressPct))}%` }}
              />
            </div>
            <div className="grid grid-cols-3 gap-2 text-xs font-mono-tabular text-zinc-950 dark:text-zinc-50">
              <div>
                <span className="text-zinc-500 dark:text-zinc-400 block text-[11px]">{t('speed.download')}</span>
                {(progress.liveDownloadMbps ?? 0).toFixed(1)} {t('speed.mbps')}
              </div>
              <div>
                <span className="text-zinc-500 dark:text-zinc-400 block text-[11px]">{t('speed.upload')}</span>
                {(progress.liveUploadMbps ?? 0).toFixed(1)} {t('speed.mbps')}
              </div>
              <div>
                <span className="text-zinc-500 dark:text-zinc-400 block text-[11px]">{t('speed.ping')}</span>
                {progress.pingMs !== null ? `${progress.pingMs} ${t('speed.ms')}` : '—'}
              </div>
            </div>
          </div>
        )}

        {testError && (
          <div className="rounded-xl border border-red-300 dark:border-red-900 bg-red-50 dark:bg-red-950/40 p-3 flex items-start gap-2 text-xs text-red-700 dark:text-red-300">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
            <span>{testError}</span>
          </div>
        )}

        {latest && (
          <div data-testid="room-latest-result" className="rounded-xl border border-zinc-200 dark:border-zinc-800 p-3.5 space-y-3">
            <div className="flex items-center justify-between gap-2 text-xs">
              <span className="font-semibold text-zinc-950 dark:text-zinc-50">
                {t('survey.internetSpeedCardTitle')}
              </span>
              <span className="font-mono-tabular text-zinc-600 dark:text-zinc-400">
                {new Date(latest.measuredAtIso).toLocaleString(locale, {
                  month: 'short',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div className="rounded-lg bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 p-2.5">
                <div className="text-[11px] text-zinc-500 dark:text-zinc-400">{t('speed.download')}</div>
                <div className="text-sm font-bold font-mono-tabular text-zinc-950 dark:text-zinc-50 mt-0.5">
                  {latest.downloadMbps.toFixed(1)} <span className="text-[11px] font-normal">{t('speed.mbps')}</span>
                </div>
                {delta && (
                  <div className={`text-[11px] font-mono-tabular inline-flex items-center gap-0.5 mt-0.5 ${delta.downloadDeltaMbps >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
                    {delta.downloadDeltaMbps >= 0 ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />}
                    {delta.downloadDeltaMbps >= 0 ? `+${delta.downloadDeltaMbps}` : delta.downloadDeltaMbps}
                  </div>
                )}
              </div>

              <div className="rounded-lg bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 p-2.5">
                <div className="text-[11px] text-zinc-500 dark:text-zinc-400">{t('speed.upload')}</div>
                <div className="text-sm font-bold font-mono-tabular text-zinc-950 dark:text-zinc-50 mt-0.5">
                  {latest.uploadMbps.toFixed(1)} <span className="text-[11px] font-normal">{t('speed.mbps')}</span>
                </div>
                {delta && (
                  <div className={`text-[11px] font-mono-tabular inline-flex items-center gap-0.5 mt-0.5 ${delta.uploadDeltaMbps >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
                    {delta.uploadDeltaMbps >= 0 ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />}
                    {delta.uploadDeltaMbps >= 0 ? `+${delta.uploadDeltaMbps}` : delta.uploadDeltaMbps}
                  </div>
                )}
              </div>

              <div className="rounded-lg bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 p-2.5">
                <div className="text-[11px] text-zinc-500 dark:text-zinc-400">{t('speed.ping')}</div>
                <div className="text-sm font-bold font-mono-tabular text-zinc-950 dark:text-zinc-50 mt-0.5">
                  {latest.pingMs.toFixed(1)} <span className="text-[11px] font-normal">{t('speed.ms')}</span>
                </div>
                {delta && (
                  <div className={`text-[11px] font-mono-tabular inline-flex items-center gap-0.5 mt-0.5 ${delta.pingDeltaMs <= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
                    {delta.pingDeltaMs > 0 ? `+${delta.pingDeltaMs}` : delta.pingDeltaMs} {t('speed.ms')}
                  </div>
                )}
              </div>

              <div className="rounded-lg bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 p-2.5">
                <div className="text-[11px] text-zinc-500 dark:text-zinc-400">{t('speed.jitter')}</div>
                <div className="text-sm font-bold font-mono-tabular text-zinc-950 dark:text-zinc-50 mt-0.5">
                  {latest.jitterMs.toFixed(1)} <span className="text-[11px] font-normal">{t('speed.ms')}</span>
                </div>
                {delta && (
                  <div className={`text-[11px] font-mono-tabular inline-flex items-center gap-0.5 mt-0.5 ${delta.jitterDeltaMs <= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
                    {delta.jitterDeltaMs > 0 ? `+${delta.jitterDeltaMs}` : delta.jitterDeltaMs} {t('speed.ms')}
                  </div>
                )}
              </div>
            </div>

            <div className="text-[11px] text-zinc-600 dark:text-zinc-400 flex flex-wrap items-center justify-between gap-2">
              <span>{t('survey.serverLabel')}: {latest.serverName}</span>
              <span>
                {t('survey.bandTagLabel')}: {latest.bandUsed === 'unknown' ? t('survey.unavailableOnDevice') : latest.bandUsed}
              </span>
            </div>
          </div>
        )}

        {history.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-zinc-950 dark:text-zinc-50">
              <History className="w-3.5 h-3.5 text-zinc-700 dark:text-zinc-300" aria-hidden="true" />
              <span>{t('survey.roomHistoryTitle')} ({history.length})</span>
            </div>
            <div className="max-h-40 overflow-y-auto divide-y divide-zinc-200 dark:divide-zinc-800 rounded-xl border border-zinc-200 dark:border-zinc-800">
              {history.map((item) => (
                <div key={item.id} className="px-3 py-2 text-xs flex items-center justify-between gap-2">
                  <span className="font-mono-tabular text-zinc-600 dark:text-zinc-400">
                    {new Date(item.measuredAtIso).toLocaleTimeString(locale, {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                    {item.bandUsed !== 'unknown' ? ` · ${item.bandUsed}` : ''}
                  </span>
                  <span className="font-mono-tabular font-medium text-zinc-950 dark:text-zinc-50">
                    ↓{item.downloadMbps.toFixed(1)} ↑{item.uploadMbps.toFixed(1)} Mbps · {item.pingMs.toFixed(0)}ms
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
