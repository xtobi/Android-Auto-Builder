import React, { useState } from 'react';
import {
  CheckCircle2,
  ClipboardCheck,
  Copy,
  Download,
  Info,
  Layers,
  Lightbulb,
  Router,
  Trash2,
  Wifi
} from 'lucide-react';
import { useI18n } from '../../i18n';
import { DeviceSignalSnapshot } from '../../services/networkSignalInfo';
import {
  HomeSurveyAnalysisReport,
  HomeSurveyProject,
  RouterScenarioId
} from '../../utils/floorPlanEngine';

interface FloorPlanAnalysisReportProps {
  project: HomeSurveyProject;
  report: HomeSurveyAnalysisReport;
  signalSnapshot: DeviceSignalSnapshot;
  onSelectScenario: (scenarioId: RouterScenarioId) => void;
  onClearAllMeasurements: () => void;
}

export const FloorPlanAnalysisReport: React.FC<FloorPlanAnalysisReportProps> = ({
  project,
  report,
  signalSnapshot,
  onSelectScenario,
  onClearAllMeasurements
}) => {
  const { t, language } = useI18n();
  const [confirmClear, setConfirmClear] = useState(false);
  const [copiedSummary, setCopiedSummary] = useState(false);

  const locale = language === 'ar' ? 'ar-EG' : language === 'fr' ? 'fr-FR' : 'en-US';

  const scenarioLabel = (id: RouterScenarioId): string => {
    if (id === 'original') return t('survey.scenarioOriginal');
    if (id === 'alt-a') return t('survey.scenarioAltA');
    return t('survey.scenarioAltB');
  };

  const handleExportJson = () => {
    const payload = {
      exportedAtIso: new Date().toISOString(),
      activeScenarioId: project.activeScenarioId,
      reportSummary: {
        totalRooms: report.totalRooms,
        measuredRoomsCount: report.measuredRoomsCount,
        strongestRoom: report.strongestRoom,
        weakestRoom: report.weakestRoom,
        bestTestedScenario: report.bestTestedScenario
      },
      floors: project.floors,
      scenarios: project.scenarios,
      measurements: project.measurements
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `advanced-wifi-home-survey-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopySummary = async () => {
    const lines: string[] = [
      `Advanced Wi-Fi — ${t('survey.reportTitle')}`,
      `${t('survey.measuredCoverage')}: ${report.measuredRoomsCount} / ${report.totalRooms}`,
      `${t('survey.scenarioLabel')}: ${scenarioLabel(project.activeScenarioId)}`
    ];
    if (report.strongestRoom) {
      lines.push(
        `${t('survey.strongestRoom')}: ${report.strongestRoom.roomName} (${report.strongestRoom.downloadMbps.toFixed(1)} Mbps / ${report.strongestRoom.pingMs.toFixed(1)} ms)`
      );
    }
    if (report.weakestRoom) {
      lines.push(
        `${t('survey.weakestRoom')}: ${report.weakestRoom.roomName} (${report.weakestRoom.downloadMbps.toFixed(1)} Mbps / ${report.weakestRoom.pingMs.toFixed(1)} ms)`
      );
    }
    try {
      await navigator.clipboard.writeText(lines.join('\n'));
      setCopiedSummary(true);
      setTimeout(() => setCopiedSummary(false), 2000);
    } catch {
      // Clipboard blocked in some contexts
    }
  };

  return (
    <div className="space-y-6 min-w-0">
      {/* 1. Browser / Device Wi-Fi Signal Information */}
      <section className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div className="flex items-center gap-2">
            <Wifi className="w-4 h-4 text-zinc-900 dark:text-zinc-100" aria-hidden="true" />
            <h2 className="text-base font-semibold text-zinc-950 dark:text-zinc-50">
              {t('survey.signalSectionTitle')}
            </h2>
          </div>
          <span className="text-xs font-mono-tabular text-zinc-600 dark:text-zinc-400">
            {signalSnapshot.online ? t('dashboard.internetOnline') : t('dashboard.internetOffline')}
            {signalSnapshot.lastChangeIso
              ? ` · ${new Date(signalSnapshot.lastChangeIso).toLocaleTimeString(locale)}`
              : ''}
          </span>
        </div>

        <p className="text-xs text-zinc-600 dark:text-zinc-400">
          {t('survey.signalSeparationNote')}
        </p>

        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
          <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 p-3">
            <div className="text-[11px] text-zinc-500 dark:text-zinc-400">{t('survey.deviceRssiLabel')}</div>
            <div className="text-xs font-semibold text-zinc-950 dark:text-zinc-50 mt-1 font-mono-tabular">
              {signalSnapshot.routerReportedRssiDbm !== null
                ? `${signalSnapshot.routerReportedRssiDbm} dBm`
                : t('survey.unavailableOnDevice')}
            </div>
          </div>

          <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 p-3">
            <div className="text-[11px] text-zinc-500 dark:text-zinc-400">{t('survey.deviceBandLabel')}</div>
            <div className="text-xs font-semibold text-zinc-950 dark:text-zinc-50 mt-1">
              {t('survey.unavailableOnDevice')}
            </div>
          </div>

          <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 p-3">
            <div className="text-[11px] text-zinc-500 dark:text-zinc-400">{t('survey.connTypeLabel')}</div>
            <div className="text-xs font-semibold text-zinc-950 dark:text-zinc-50 mt-1 font-mono-tabular">
              {signalSnapshot.networkType ?? signalSnapshot.effectiveType ?? t('survey.unavailableOnDevice')}
            </div>
          </div>

          <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 p-3">
            <div className="text-[11px] text-zinc-500 dark:text-zinc-400">{t('survey.browserDownlinkHint')}</div>
            <div className="text-xs font-semibold text-zinc-950 dark:text-zinc-50 mt-1 font-mono-tabular">
              {signalSnapshot.downlinkHintMbps !== null
                ? `~${signalSnapshot.downlinkHintMbps} Mbps`
                : t('survey.unavailableOnDevice')}
            </div>
          </div>

          <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 p-3">
            <div className="text-[11px] text-zinc-500 dark:text-zinc-400">{t('survey.browserRttHint')}</div>
            <div className="text-xs font-semibold text-zinc-950 dark:text-zinc-50 mt-1 font-mono-tabular">
              {signalSnapshot.rttHintMs !== null ? `~${signalSnapshot.rttHintMs} ms` : t('survey.unavailableOnDevice')}
            </div>
          </div>
        </div>
      </section>

      {/* 2. Intelligent Home Network Analysis */}
      <section className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-base font-semibold text-zinc-950 dark:text-zinc-50">
            {t('survey.analysisTitle')}
          </h2>
          <span className="text-xs font-mono-tabular text-zinc-600 dark:text-zinc-400">
            {t('survey.measuredCoverage')}: {report.measuredRoomsCount} / {report.totalRooms}
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 p-4 space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 dark:text-emerald-300">
              <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
              <span>{t('survey.confirmedFactsTitle')}</span>
            </div>

            {report.confirmedFindings.length === 0 ? (
              <p className="text-xs text-zinc-600 dark:text-zinc-400">{t('survey.noConfirmedMeasurementsYet')}</p>
            ) : (
              <ul className="space-y-2.5">
                {report.confirmedFindings.map((item) => (
                  <li key={item.id} className="rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-3 text-xs space-y-1">
                    <div className="font-semibold text-zinc-950 dark:text-zinc-50">{t(item.titleKey)}</div>
                    <div className="font-mono-tabular text-zinc-600 dark:text-zinc-400">{item.evidence}</div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 p-4 space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-zinc-900 dark:text-zinc-100">
              <Lightbulb className="w-4 h-4" aria-hidden="true" />
              <span>{t('survey.estimatedRecsTitle')}</span>
            </div>

            <ul className="space-y-2.5">
              {report.recommendations.map((rec) => (
                <li key={rec.id} className="rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-3 text-xs space-y-1">
                  <div className="font-semibold text-zinc-950 dark:text-zinc-50">{t(rec.titleKey)}</div>
                  <div className="text-zinc-600 dark:text-zinc-400">{rec.evidence}</div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* 3. Router Position Comparison */}
      <section className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h2 className="text-base font-semibold text-zinc-950 dark:text-zinc-50 flex items-center gap-2">
              <Router className="w-4 h-4 text-zinc-900 dark:text-zinc-100" aria-hidden="true" />
              <span>{t('survey.scenarioComparisonTitle')}</span>
            </h2>
            <p className="text-xs text-zinc-600 dark:text-zinc-400 mt-0.5">
              {t('survey.scenarioComparisonBody')}
            </p>
          </div>
          <div className="text-xs font-medium text-zinc-900 dark:text-zinc-100">
            {report.bestTestedScenario
              ? `${t('survey.bestTestedLabel')}: ${scenarioLabel(report.bestTestedScenario)}`
              : t('survey.insufficientScenarioData')}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-start border-collapse whitespace-nowrap">
            <thead>
              <tr className="border-b border-zinc-200 dark:border-zinc-800 text-zinc-500 dark:text-zinc-400">
                <th className="py-2.5 px-3 text-start font-medium">{t('survey.scenarioLabel')}</th>
                <th className="py-2.5 px-3 text-start font-medium">{t('survey.routerLocationCol')}</th>
                <th className="py-2.5 px-3 text-start font-medium">{t('survey.roomsMeasuredCol')}</th>
                <th className="py-2.5 px-3 text-start font-medium">{t('survey.avgDownloadCol')}</th>
                <th className="py-2.5 px-3 text-start font-medium">{t('survey.minDownloadCol')}</th>
                <th className="py-2.5 px-3 text-start font-medium">{t('survey.avgPingCol')}</th>
                <th className="py-2.5 px-3 text-end font-medium">{t('survey.actionCol')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
              {report.scenarioComparisons.map((sc) => {
                const isActive = sc.scenarioId === project.activeScenarioId;
                const isBest = report.bestTestedScenario === sc.scenarioId;
                return (
                  <tr
                    key={sc.scenarioId}
                    className={isActive ? 'bg-zinc-50 dark:bg-zinc-950' : undefined}
                  >
                    <td className="py-3 px-3 font-semibold text-zinc-950 dark:text-zinc-50">
                      {scenarioLabel(sc.scenarioId)}
                      {isBest && (
                        <span className="ms-2 text-[11px] font-medium text-emerald-700 dark:text-emerald-300">
                          · {t('survey.bestTag')}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3 font-mono-tabular text-zinc-600 dark:text-zinc-400">
                      {sc.routerFloorName} ({sc.routerCoords.x.toFixed(1)}, {sc.routerCoords.y.toFixed(1)} {t('survey.metersUnit')})
                    </td>
                    <td className="py-3 px-3 font-mono-tabular text-zinc-950 dark:text-zinc-50">
                      {sc.measuredRoomsCount} / {sc.totalRoomsCount}
                    </td>
                    <td className="py-3 px-3 font-mono-tabular text-zinc-950 dark:text-zinc-50">
                      {sc.avgDownloadMbps !== null ? `${sc.avgDownloadMbps} Mbps` : '—'}
                    </td>
                    <td className="py-3 px-3 font-mono-tabular text-zinc-950 dark:text-zinc-50">
                      {sc.minDownloadMbps !== null ? `${sc.minDownloadMbps} Mbps` : '—'}
                    </td>
                    <td className="py-3 px-3 font-mono-tabular text-zinc-950 dark:text-zinc-50">
                      {sc.avgPingMs !== null ? `${sc.avgPingMs} ms` : '—'}
                    </td>
                    <td className="py-3 px-3 text-end">
                      <button
                        type="button"
                        onClick={() => onSelectScenario(sc.scenarioId)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-medium ${
                          isActive
                            ? 'bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900'
                            : 'border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-zinc-100 hover:border-zinc-400'
                        }`}
                      >
                        {isActive ? t('survey.activeTag') : t('survey.switchScenarioBtn')}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* 4. Floor Comparison & Export Report */}
      <section className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-zinc-900 dark:text-zinc-100" aria-hidden="true" />
            <h2 className="text-base font-semibold text-zinc-950 dark:text-zinc-50">
              {t('survey.reportTitle')}
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleCopySummary}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-900 dark:text-zinc-100 hover:border-zinc-400"
            >
              {copiedSummary ? <ClipboardCheck className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSummary ? t('app.copied') : t('survey.copySummaryBtn')}</span>
            </button>

            <button
              type="button"
              onClick={handleExportJson}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 dark:bg-zinc-100 hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-zinc-900 text-xs font-medium"
            >
              <Download className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t('survey.exportJsonBtn')}</span>
            </button>

            {project.measurements.length > 0 && !confirmClear && (
              <button
                type="button"
                onClick={() => setConfirmClear(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-red-300 dark:border-red-900 text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30"
              >
                <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{t('survey.clearAllMeasurementsBtn')}</span>
              </button>
            )}

            {confirmClear && (
              <div className="inline-flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    onClearAllMeasurements();
                    setConfirmClear(false);
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-red-600 text-white text-xs font-medium"
                >
                  {t('app.confirm')}
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmClear(false)}
                  className="px-2.5 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 text-xs font-medium"
                >
                  {t('app.cancel')}
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-start border-collapse">
            <thead>
              <tr className="border-b border-zinc-200 dark:border-zinc-800 text-zinc-500 dark:text-zinc-400">
                <th className="py-2 px-3 text-start font-medium">{t('survey.floorCol')}</th>
                <th className="py-2 px-3 text-start font-medium">{t('survey.roomsMeasuredCol')}</th>
                <th className="py-2 px-3 text-start font-medium">{t('survey.avgDownloadCol')}</th>
                <th className="py-2 px-3 text-start font-medium">{t('survey.avgUploadCol')}</th>
                <th className="py-2 px-3 text-start font-medium">{t('survey.avgPingCol')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
              {report.floorSummaries.map((fl) => (
                <tr key={fl.floorId}>
                  <td className="py-2.5 px-3 font-semibold text-zinc-950 dark:text-zinc-50">{fl.floorName}</td>
                  <td className="py-2.5 px-3 font-mono-tabular text-zinc-600 dark:text-zinc-400">
                    {fl.measuredRooms} / {fl.totalRooms}
                  </td>
                  <td className="py-2.5 px-3 font-mono-tabular text-zinc-950 dark:text-zinc-50">
                    {fl.avgDownloadMbps !== null ? `${fl.avgDownloadMbps} Mbps` : '—'}
                  </td>
                  <td className="py-2.5 px-3 font-mono-tabular text-zinc-950 dark:text-zinc-50">
                    {fl.avgUploadMbps !== null ? `${fl.avgUploadMbps} Mbps` : '—'}
                  </td>
                  <td className="py-2.5 px-3 font-mono-tabular text-zinc-950 dark:text-zinc-50">
                    {fl.avgPingMs !== null ? `${fl.avgPingMs} ms` : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 p-3 flex items-start gap-2 text-xs text-zinc-600 dark:text-zinc-400">
          <Info className="w-4 h-4 text-zinc-900 dark:text-zinc-100 shrink-0 mt-0.5" aria-hidden="true" />
          <span>{t('survey.honestLimitationBanner')}</span>
        </div>
      </section>
    </div>
  );
};
