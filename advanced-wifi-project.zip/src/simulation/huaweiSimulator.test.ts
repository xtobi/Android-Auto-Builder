import test from 'node:test';
import assert from 'node:assert/strict';
import { huaweiHg8145x6Adapter } from '../router-adapters/huawei-hg8145x6-10';
import { huaweiAdapter } from '../router-adapters/huawei';
import { RouterConnectionContext, RouterError } from '../router-adapters/types';
import { createSimulatedHuaweiTransport, SimulationScenario } from './huaweiSimulator';

function makeSimContext(scenario: SimulationScenario, adapterId: 'huawei' | 'huawei-hg8145x6-10' = 'huawei-hg8145x6-10'): RouterConnectionContext {
  return {
    baseUrl: 'http://192.168.100.1',
    adapterId,
    transport: createSimulatedHuaweiTransport(scenario),
    sessionState: {}
  };
}

test('Virtual Huawei OptiXstar HG8145X6-10 works end-to-end with dedicated huaweiHg8145x6Adapter', async () => {
  const ctx = makeSimContext('normal', 'huawei-hg8145x6-10');

  await huaweiHg8145x6Adapter.connect(ctx);
  await huaweiHg8145x6Adapter.authenticate(ctx, { username: 'admin', password: 'admin' });

  const info = await huaweiHg8145x6Adapter.getRouterInfo(ctx);
  assert.equal(info.vendor, 'Huawei (DZTELCOM)');
  assert.ok(info.model?.includes('HG8145X6-10'));
  assert.equal(info.firmwareVersion, 'V5R023C00S174');
  assert.equal(info.hardwareVersion, '2C6D.A');
  assert.equal(info.deviceType, 'GPON ONT');
  assert.equal(info.uptimeSeconds, 43200);

  const initialWifi = await huaweiHg8145x6Adapter.getWifiSettings(ctx);
  assert.equal(initialWifi.band24?.ssid, 'Huawei-OptiXstar-2.4G');
  assert.equal(initialWifi.band5?.ssid, 'Huawei-OptiXstar-5G');

  await huaweiHg8145x6Adapter.updateWifiSettings(ctx, {
    band: '2.4GHz',
    enabled: true,
    ssid: 'HomeMesh_2G',
    encryption: 'WPA2-PSK',
    channel: '6'
  });

  const afterWifi = await huaweiHg8145x6Adapter.getWifiSettings(ctx);
  assert.equal(afterWifi.band24?.ssid, 'HomeMesh_2G');

  const deviceState = await huaweiHg8145x6Adapter.getConnectedDevices(ctx);
  assert.ok(deviceState.connected.length >= 4);

  const targetMac = deviceState.connected[0].macAddress;
  await huaweiHg8145x6Adapter.blockDevice(ctx, targetMac);
  let refreshedDevices = await huaweiHg8145x6Adapter.getConnectedDevices(ctx);
  assert.ok(refreshedDevices.blockedMacs.includes(targetMac.toUpperCase()));

  await huaweiHg8145x6Adapter.unblockDevice(ctx, targetMac);
  refreshedDevices = await huaweiHg8145x6Adapter.getConnectedDevices(ctx);
  assert.equal(refreshedDevices.blockedMacs.includes(targetMac.toUpperCase()), false);

  await huaweiHg8145x6Adapter.setGuestWifiEnabled?.(ctx, false);
  const guestAfterOff = await huaweiHg8145x6Adapter.getGuestWifiEnabled?.(ctx);
  assert.equal(guestAfterOff, false);

  await huaweiHg8145x6Adapter.disconnect(ctx);
});

test('Virtual Huawei simulator enforces INVALID_CREDENTIALS and SESSION_EXPIRED errors across both adapters', async () => {
  const badCtx = makeSimContext('invalid_credentials', 'huawei-hg8145x6-10');
  await huaweiHg8145x6Adapter.connect(badCtx);
  await assert.rejects(
    () => huaweiHg8145x6Adapter.authenticate(badCtx, { username: 'admin', password: 'wrong' }),
    (err: unknown) => err instanceof RouterError && err.code === 'INVALID_CREDENTIALS'
  );

  const expireCtx = makeSimContext('session_expired', 'huawei-hg8145x6-10');
  await huaweiHg8145x6Adapter.connect(expireCtx);
  await huaweiHg8145x6Adapter.authenticate(expireCtx, { username: 'admin', password: 'admin' });
  await assert.rejects(
    () =>
      huaweiHg8145x6Adapter.updateWifiSettings(expireCtx, {
        band: '2.4GHz',
        enabled: true,
        ssid: 'ShouldFail',
        encryption: 'WPA2-PSK',
        channel: '6'
      }),
    (err: unknown) => err instanceof RouterError && err.code === 'SESSION_EXPIRED'
  );

  // Also ensure generic Huawei adapter stays backwards-compatible with simulator
  const legacyCtx = makeSimContext('normal', 'huawei');
  await huaweiAdapter.connect(legacyCtx);
  await huaweiAdapter.authenticate(legacyCtx, { username: 'admin', password: 'admin' });
  const legacyInfo = await huaweiAdapter.getRouterInfo(legacyCtx);
  assert.ok(legacyInfo.model?.includes('HG8145X6-10'));
});
