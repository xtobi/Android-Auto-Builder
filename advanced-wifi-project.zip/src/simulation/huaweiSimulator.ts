import { HttpRequestOptions, HttpResponse, TransportRequestFn } from '../router-adapters/types';

export type SimulationScenario = 'normal' | 'invalid_credentials' | 'session_expired';

interface SimulatedBand {
  domain: string;
  name: string;
  enabled: boolean;
  ssid: string;
  password: string;
  beaconType: string;
  channel: string;
}

interface SimulatedDevice {
  hostname: string;
  ip: string;
  mac: string;
  port: string;
  state: 'Online' | 'Offline';
}

interface SimulatorWorldState {
  validUsername: string;
  validPassword: string;
  authenticated: boolean;
  sessionExpired: boolean;
  randToken: string;
  modelName: string;
  firmwareVersion: string;
  hardwareVersion: string;
  deviceType: string;
  ispVendor: string;
  uptimeSeconds: number;
  linkSpeedMbps: number;
  rxPowerDbm: number;
  wanConnected: boolean;
  guestWifiEnabled: boolean;
  band24: SimulatedBand;
  band5: SimulatedBand;
  devices: SimulatedDevice[];
  blockedMacs: string[];
  rebootCount: number;
}

function createInitialWorldState(): SimulatorWorldState {
  return {
    validUsername: 'admin',
    validPassword: 'admin',
    authenticated: false,
    sessionExpired: false,
    randToken: `sim_hw_${Date.now().toString(36)}`,
    modelName: 'OptiXstar HG8145X6-10',
    firmwareVersion: 'V5R023C00S174',
    hardwareVersion: '2C6D.A',
    deviceType: 'GPON ONT',
    ispVendor: 'DZTELCOM',
    uptimeSeconds: 43200,
    linkSpeedMbps: 1000,
    rxPowerDbm: -19,
    wanConnected: true,
    guestWifiEnabled: false,
    band24: {
      domain: 'InternetGatewayDevice.LANDevice.1.WLANConfiguration.1',
      name: 'ath0',
      enabled: true,
      ssid: 'Huawei-OptiXstar-2.4G',
      password: 'SimPassword24',
      beaconType: '11i',
      channel: '6'
    },
    band5: {
      domain: 'InternetGatewayDevice.LANDevice.1.WLANConfiguration.5',
      name: 'ath4',
      enabled: true,
      ssid: 'Huawei-OptiXstar-5G',
      password: 'SimPassword5G',
      beaconType: 'WPA3-SAE',
      channel: '36'
    },
    devices: [
      {
        hostname: 'Galaxy-S24-Android',
        ip: '192.168.100.12',
        mac: 'A4:83:E7:11:22:33',
        port: 'SSID5',
        state: 'Online'
      },
      {
        hostname: 'Workstation-Laptop',
        ip: '192.168.100.18',
        mac: '70:4D:7B:44:55:66',
        port: 'SSID5',
        state: 'Online'
      },
      {
        hostname: 'LivingRoom-SmartTV',
        ip: '192.168.100.24',
        mac: 'CC:2D:E0:77:88:99',
        port: 'LAN1',
        state: 'Online'
      },
      {
        hostname: 'Hallway-IoT-Sensor',
        ip: '192.168.100.31',
        mac: '18:FE:34:AA:BB:CC',
        port: 'SSID1',
        state: 'Online'
      }
    ],
    blockedMacs: [],
    rebootCount: 0
  };
}

let activeSimulatorState: SimulatorWorldState = createInitialWorldState();

export function resetHuaweiSimulatorState(): void {
  activeSimulatorState = createInitialWorldState();
}

export function expireSimulatedHuaweiSession(): void {
  activeSimulatorState.sessionExpired = true;
  activeSimulatorState.authenticated = false;
}

function decodeBase64Utf8(b64: string): string {
  try {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i += 1) {
      bytes[i] = bin.charCodeAt(i);
    }
    return new TextDecoder().decode(bytes);
  } catch {
    return b64;
  }
}

function rotateToken(): string {
  activeSimulatorState.randToken = `sim_hw_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
  return activeSimulatorState.randToken;
}

function loginRedirectResponse(): HttpResponse {
  return {
    status: 200,
    headers: { 'content-type': 'text/html' },
    body: `<html><head><title>OptiXstar HG8145X6-10</title></head><body><form action="/login.cgi"><script>top.location.replace('/login.html');</script></form></body></html>`
  };
}

export function createSimulatedHuaweiTransport(scenario: SimulationScenario = 'normal'): TransportRequestFn {
  if (scenario === 'session_expired') {
    activeSimulatorState.sessionExpired = true;
  } else {
    activeSimulatorState.sessionExpired = false;
  }
  let postLoginChecksLeft = 0;

  return async (req: HttpRequestOptions): Promise<HttpResponse> => {
    // Realistic small local LAN latency so UI progress states behave naturally
    await new Promise((r) => setTimeout(r, 45));

    const parsed = new URL(req.path, 'http://192.168.100.1');
    const path = parsed.pathname;

    if (path === '/' || path === '/login.html') {
      return {
        status: 200,
        headers: { 'content-type': 'text/html' },
        body: `<html><head><title>${activeSimulatorState.modelName}</title></head><body><h1>Huawei ${activeSimulatorState.modelName}</h1><form action="/login.cgi"><input type="hidden" name="x.X_HW_Token" value="${activeSimulatorState.randToken}" /></form></body></html>`
      };
    }

    if (path === '/asp/GetRandCount.asp') {
      return {
        status: 200,
        headers: { 'content-type': 'text/plain' },
        body: rotateToken()
      };
    }

    if (path === '/api/webserver/SesTokInfo') {
      // Simulated HG8145X6-10 uses ONT ASP/CGI, not HiLink XML
      return { status: 404, headers: {}, body: 'Not Found' };
    }

    if (path === '/login.cgi' && req.method === 'POST') {
      const form = new URLSearchParams(req.body || '');
      const user = (form.get('UserName') || '').trim();
      const rawPass = form.get('PassWord') || '';
      const decodedPass = decodeBase64Utf8(rawPass);

      if (
        scenario === 'invalid_credentials' ||
        user !== activeSimulatorState.validUsername ||
        decodedPass !== activeSimulatorState.validPassword
      ) {
        return {
          status: 200,
          headers: { 'content-type': 'text/html' },
          body: '<html><script>var errcode="login_fail"; var failtimes=1;</script>Invalid password</body></html>'
        };
      }

      activeSimulatorState.authenticated = true;
      activeSimulatorState.sessionExpired = scenario === 'session_expired';
      postLoginChecksLeft = scenario === 'session_expired' ? 1 : 0;
      rotateToken();
      return {
        status: 200,
        headers: { 'content-type': 'text/html', 'set-cookie': 'Cookie=SessionID_R3=sim_ok; Path=/' },
        body: `<html><script>var ontModal="${activeSimulatorState.modelName}";</script></html>`
      };
    }

    if (path === '/logout.cgi') {
      activeSimulatorState.authenticated = false;
      return { status: 200, headers: {}, body: 'OK' };
    }

    // Protected ONT endpoints below
    if (
      !activeSimulatorState.authenticated ||
      (activeSimulatorState.sessionExpired &&
        !(req.method === 'GET' && path === '/html/ssmp/devinfo/devinfo.asp' && postLoginChecksLeft-- > 0))
    ) {
      return loginRedirectResponse();
    }

    if (path === '/html/ssmp/devinfo/devinfo.asp') {
      return {
        status: 200,
        headers: { 'content-type': 'text/html' },
        body: `<script>
var ModelName = "${activeSimulatorState.modelName}";
var SoftwareVersion = "${activeSimulatorState.firmwareVersion}";
var HardwareVersion = "${activeSimulatorState.hardwareVersion}";
var DeviceType = "${activeSimulatorState.deviceType}";
var VendorName = "Huawei (${activeSimulatorState.ispVendor})";
var UpTime = "${activeSimulatorState.uptimeSeconds}";
var MaxBitRate = "${activeSimulatorState.linkSpeedMbps}";
var RxPower = "${activeSimulatorState.rxPowerDbm}";
</script>`
      };
    }

    if (path === '/html/ssmp/reset/reset.asp') {
      return {
        status: 200,
        headers: { 'content-type': 'text/html' },
        body: `<html><script>var resetSupported = true;</script><input type="hidden" name="x.X_HW_Token" value="${rotateToken()}" /></html>`
      };
    }

    if (path === '/html/bbsp/waninfo/waninfo.asp') {
      return {
        status: 200,
        headers: { 'content-type': 'text/html' },
        body: `<script>var wanStatus = "${activeSimulatorState.wanConnected ? 'Connected' : 'Disconnected'}";</script>`
      };
    }

    if (path === '/html/amp/wlaninfo/wlaninfo.asp' || path === '/html/amp/wlanbasic/WlanBasic.asp') {
      const b24 = activeSimulatorState.band24;
      const b5 = activeSimulatorState.band5;
      return {
        status: 200,
        headers: { 'content-type': 'text/html' },
        body: `<script>
new stWlan("${b24.domain}", "${b24.name}", "${b24.enabled ? '1' : '0'}", "${b24.ssid}", "0", "${b24.beaconType}", "AES", "${b24.password}", "${b24.channel}");
new stWlan("${b5.domain}", "${b5.name}", "${b5.enabled ? '1' : '0'}", "${b5.ssid}", "0", "${b5.beaconType}", "AES", "${b5.password}", "${b5.channel}");
</script>`
      };
    }

    if (path === '/html/amp/wlanbasic/WlanGuest.asp') {
      return {
        status: 200,
        headers: { 'content-type': 'text/html' },
        body: `<script>var guestWifiEnable = "${activeSimulatorState.guestWifiEnabled ? '1' : '0'}";</script>`
      };
    }

    if (path === '/html/amp/wlanbasic/set.cgi' && req.method === 'POST') {
      const xParam = parsed.searchParams.get('x') || '';
      const form = new URLSearchParams(req.body || '');

      if (xParam.includes('WLANConfiguration.2')) {
        activeSimulatorState.guestWifiEnabled = form.get('x.Enable') === '1';
        rotateToken();
        return { status: 200, headers: {}, body: 'OK' };
      }

      const targetBand = xParam.includes('WLANConfiguration.5')
        ? activeSimulatorState.band5
        : activeSimulatorState.band24;

      if (form.has('x.Enable')) targetBand.enabled = form.get('x.Enable') === '1';
      if (form.has('x.SSID')) targetBand.ssid = form.get('x.SSID') || targetBand.ssid;
      if (form.has('y.PreSharedKey') && form.get('y.PreSharedKey')) {
        targetBand.password = form.get('y.PreSharedKey')!;
      }
      if (form.has('x.BeaconType')) {
        const b = form.get('x.BeaconType') || '11i';
        targetBand.beaconType = b === 'Basic' ? 'NONE' : b;
      }
      if (form.has('x.Channel')) {
        targetBand.channel = form.get('x.Channel') || targetBand.channel;
      }
      rotateToken();
      return { status: 200, headers: {}, body: 'OK' };
    }

    if (path === '/html/bbsp/common/GetLanUserDevInfo.asp') {
      const lines = activeSimulatorState.devices.map(
        (d, i) =>
          `new USERDev("InternetGatewayDevice.LANDevice.1.Hosts.Host.${i + 1}", "${d.hostname}", "${d.ip}", "${d.mac}", "${d.port}", "${d.state}");`
      );
      return {
        status: 200,
        headers: { 'content-type': 'text/html' },
        body: `<script>\n${lines.join('\n')}\n</script>`
      };
    }

    if (path === '/html/bbsp/macfilter/macfilter.asp') {
      return {
        status: 200,
        headers: { 'content-type': 'text/html' },
        body: `<script>var blocked = ${JSON.stringify(activeSimulatorState.blockedMacs)};</script>`
      };
    }

    if (path === '/html/bbsp/macfilter/add.cgi' && req.method === 'POST') {
      const form = new URLSearchParams(req.body || '');
      const mac = (form.get('x.SourceMACAddress') || '').toUpperCase();
      if (mac && !activeSimulatorState.blockedMacs.includes(mac)) {
        activeSimulatorState.blockedMacs.push(mac);
      }
      rotateToken();
      return { status: 200, headers: {}, body: 'OK' };
    }

    if (path === '/html/bbsp/macfilter/del.cgi' && req.method === 'POST') {
      const form = new URLSearchParams(req.body || '');
      const mac = (form.get('x.SourceMACAddress') || '').toUpperCase();
      activeSimulatorState.blockedMacs = activeSimulatorState.blockedMacs.filter((m) => m !== mac);
      rotateToken();
      return { status: 200, headers: {}, body: 'OK' };
    }

    if (path === '/html/ssmp/reset/set.cgi' && req.method === 'POST') {
      activeSimulatorState.rebootCount += 1;
      activeSimulatorState.authenticated = false;
      return { status: 200, headers: {}, body: 'OK' };
    }

    return { status: 404, headers: {}, body: 'Not Found' };
  };
}
