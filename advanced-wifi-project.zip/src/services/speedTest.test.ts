import test from 'node:test';
import assert from 'node:assert/strict';
import {
  chooseAdaptiveChunkBytes,
  computeLatencyStats,
  computeMbps,
  computeSteadyStateThroughput,
  DOWNLOAD_PHASE_TARGET_MS,
  MIN_DOWNLOAD_MEASURE_MS,
  MIN_UPLOAD_MEASURE_MS,
  UPLOAD_PHASE_TARGET_MS,
  WARMUP_EXCLUDE_MS
} from './speedTest';

test('computeMbps computes accurate megabits per second from bytes and elapsed ms', () => {
  // 1,250,000 bytes (10 megabits) in 1000ms = 10 Mbps
  assert.equal(computeMbps(1_250_000, 1000), 10);
  assert.equal(computeMbps(0, 1000), 0);
  assert.equal(computeMbps(1000, 0), 0);
});

test('computeLatencyStats computes median ping, jitter, and packet loss percentage', () => {
  const stats = computeLatencyStats([20, 30, 25, 35, 28], 6);
  // Sorted: [20, 25, 28, 30, 35] -> median 28
  assert.equal(stats.pingMs, 28);
  // Successive diffs: |30-20|=10, |25-30|=5, |35-25|=10, |28-35|=7 -> avg 32/4 = 8
  assert.equal(stats.jitterMs, 8);
  // 1 failed out of 6 = 16.7%
  assert.equal(stats.packetLossPct, 16.7);
});

test('computeLatencyStats handles 100% packet loss gracefully', () => {
  const stats = computeLatencyStats([], 6);
  assert.equal(stats.packetLossPct, 100);
  assert.equal(stats.pingMs, 0);
});

test('speed test enforces at least 15 seconds steady-state measurement for download and upload', () => {
  assert.ok(MIN_DOWNLOAD_MEASURE_MS >= 15_000);
  assert.ok(MIN_UPLOAD_MEASURE_MS >= 15_000);
  assert.ok(DOWNLOAD_PHASE_TARGET_MS >= WARMUP_EXCLUDE_MS + 15_000);
  assert.ok(UPLOAD_PHASE_TARGET_MS >= WARMUP_EXCLUDE_MS + 15_000);
});

test('computeSteadyStateThroughput excludes warmup period and trims extreme spikes', () => {
  const samples = [
    // Initial warmup ramp-up (excluded)
    { offsetMs: 400, bytesDelta: 125_000, intervalMs: 400 }, // 2.5 Mbps
    { offsetMs: 1100, bytesDelta: 250_000, intervalMs: 500 }, // 4 Mbps
    // Steady state (~20 Mbps with one outlier spike & one dip)
    { offsetMs: 2000, bytesDelta: 1_250_000, intervalMs: 500 }, // 20 Mbps
    { offsetMs: 3000, bytesDelta: 1_250_000, intervalMs: 500 }, // 20 Mbps
    { offsetMs: 4000, bytesDelta: 625_000, intervalMs: 500 }, // 10 Mbps (low outlier)
    { offsetMs: 5000, bytesDelta: 1_250_000, intervalMs: 500 }, // 20 Mbps
    { offsetMs: 6000, bytesDelta: 1_250_000, intervalMs: 500 }, // 20 Mbps
    { offsetMs: 7000, bytesDelta: 1_250_000, intervalMs: 500 }, // 20 Mbps
    { offsetMs: 8000, bytesDelta: 1_250_000, intervalMs: 500 }, // 20 Mbps
    { offsetMs: 9000, bytesDelta: 5_000_000, intervalMs: 500 } // 80 Mbps (high spike)
  ];

  const stats = computeSteadyStateThroughput(samples, 1500);
  assert.equal(stats.averageMbps, 20);
  assert.equal(stats.usedSampleCount, 6);
});

test('chooseAdaptiveChunkBytes scales payload to connection speed without excess data waste', () => {
  const slowChunk = chooseAdaptiveChunkBytes(1.2, 1.5, 150_000, 8_000_000, 600_000);
  const fastChunk = chooseAdaptiveChunkBytes(80, 1.5, 150_000, 8_000_000, 600_000);
  assert.ok(slowChunk >= 150_000 && slowChunk <= 300_000);
  assert.equal(fastChunk, 8_000_000);
});
