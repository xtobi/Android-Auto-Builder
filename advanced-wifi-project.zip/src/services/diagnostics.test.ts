import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeNetworkDiagnostics } from './diagnostics';

test('diagnostics marks speed and router checks unavailable when no data exists', () => {
  const report = analyzeNetworkDiagnostics({
    latestSpeed: null,
    speedHistory: [],
    routerConnected: false,
    routerInfo: null,
    wifiSettings: null,
    devices: []
  });

  assert.equal(report.confirmed.length, 0);
  assert.equal(report.possible.length, 0);
  assert.equal(report.unavailable.length, 2);
});

test('diagnostics identifies confirmed packet loss, high ping, and low download from real test data', () => {
  const report = analyzeNetworkDiagnostics({
    latestSpeed: {
      id: 'st_1',
      serverName: 'Cloudflare Edge',
      downloadMbps: 3.2,
      uploadMbps: 1.1,
      pingMs: 145,
      jitterMs: 32,
      packetLossPct: 5.5,
      measuredAtIso: '2026-11-25T10:00:00Z'
    },
    speedHistory: [],
    routerConnected: true,
    routerInfo: {
      vendor: 'Huawei',
      model: 'B535',
      firmwareVersion: '10.0',
      gatewayIp: '192.168.8.1',
      wanConnected: true,
      uptimeSeconds: 1200,
      signalStrengthDbm: -82,
      channelCongestionScore: null
    },
    wifiSettings: {
      band24: {
        band: '2.4GHz',
        enabled: true,
        ssid: 'Home',
        password: null,
        encryption: 'WPA2-PSK',
        channel: '3'
      },
      band5: {
        band: '5GHz',
        enabled: false,
        ssid: 'Home_5G',
        password: null,
        encryption: 'WPA2-PSK',
        channel: '36'
      }
    },
    devices: Array.from({ length: 14 }).map((_, i) => ({
      id: `AA:BB:CC:DD:EE:${String(i).padStart(2, '0')}`,
      hostname: `Dev-${i}`,
      ipAddress: `192.168.8.${10 + i}`,
      macAddress: `AA:BB:CC:DD:EE:${String(i).padStart(2, '0')}`,
      vendor: null,
      connectionType: 'Wi-Fi',
      lastSeen: null,
      status: 'online'
    }))
  });

  assert.ok(report.confirmed.some((c) => c.id === 'packet-loss-high'));
  assert.ok(report.confirmed.some((c) => c.id === 'ping-high'));
  assert.ok(report.confirmed.some((c) => c.id === 'low-download'));
  assert.ok(report.confirmed.some((c) => c.id === 'weak-signal'));
  assert.ok(report.possible.some((p) => p.id === 'many-devices'));
  assert.ok(report.possible.some((p) => p.id === 'overlapping-channel-24'));
});
