export type WifiBandTag = '2.4GHz' | '5GHz' | 'unknown';

export interface DeviceSignalSnapshot {
  online: boolean;
  networkType: string | null;
  effectiveType: string | null;
  downlinkHintMbps: number | null;
  rttHintMs: number | null;
  browserRssiAvailable: boolean;
  browserRssiDbm: number | null;
  browserFrequencyBandAvailable: boolean;
  browserFrequencyBand: WifiBandTag;
  routerReportedRssiDbm: number | null;
  lastChangeIso: string | null;
  saveData: boolean | null;
}

interface NetworkInformationLike {
  type?: string;
  effectiveType?: string;
  downlink?: number;
  rtt?: number;
  saveData?: boolean;
  addEventListener?: (type: string, listener: () => void) => void;
  removeEventListener?: (type: string, listener: () => void) => void;
}

function getNetworkConnection(): NetworkInformationLike | null {
  if (typeof navigator === 'undefined') return null;
  const nav = navigator as Navigator & {
    connection?: NetworkInformationLike;
    mozConnection?: NetworkInformationLike;
    webkitConnection?: NetworkInformationLike;
  };
  return nav.connection || nav.mozConnection || nav.webkitConnection || null;
}

/**
 * Reads only genuine, browser-accessible connection information.
 * Standard web browsers do not expose Wi-Fi RSSI (dBm) or physical 2.4/5 GHz channel frequency
 * for privacy/security reasons; this function strictly marks them unavailable rather than inventing values.
 */
export function readDeviceSignalSnapshot(params?: {
  routerReportedRssiDbm?: number | null;
  lastChangeIso?: string | null;
}): DeviceSignalSnapshot {
  const conn = getNetworkConnection();
  const online = typeof navigator !== 'undefined' ? navigator.onLine !== false : true;
  const routerRssi =
    typeof params?.routerReportedRssiDbm === 'number' && Number.isFinite(params.routerReportedRssiDbm)
      ? params.routerReportedRssiDbm
      : null;

  return {
    online,
    networkType: conn?.type && typeof conn.type === 'string' ? conn.type : null,
    effectiveType: conn?.effectiveType && typeof conn.effectiveType === 'string' ? conn.effectiveType : null,
    downlinkHintMbps:
      typeof conn?.downlink === 'number' && Number.isFinite(conn.downlink) ? conn.downlink : null,
    rttHintMs: typeof conn?.rtt === 'number' && Number.isFinite(conn.rtt) ? conn.rtt : null,
    browserRssiAvailable: false,
    browserRssiDbm: null,
    browserFrequencyBandAvailable: false,
    browserFrequencyBand: 'unknown',
    routerReportedRssiDbm: routerRssi,
    lastChangeIso: params?.lastChangeIso ?? null,
    saveData: typeof conn?.saveData === 'boolean' ? conn.saveData : null
  };
}

export function subscribeNetworkChanges(onChange: () => void): () => void {
  if (typeof window === 'undefined') return () => undefined;
  const conn = getNetworkConnection();
  window.addEventListener('online', onChange);
  window.addEventListener('offline', onChange);
  conn?.addEventListener?.('change', onChange);

  return () => {
    window.removeEventListener('online', onChange);
    window.removeEventListener('offline', onChange);
    conn?.removeEventListener?.('change', onChange);
  };
}

export function formatConnectionSummary(snapshot: DeviceSignalSnapshot): string {
  const parts: string[] = [];
  parts.push(snapshot.online ? 'online' : 'offline');
  if (snapshot.networkType) parts.push(`type=${snapshot.networkType}`);
  if (snapshot.effectiveType) parts.push(`net=${snapshot.effectiveType}`);
  if (snapshot.downlinkHintMbps !== null) parts.push(`estLink=${snapshot.downlinkHintMbps}Mbps`);
  if (snapshot.rttHintMs !== null) parts.push(`estRtt=${snapshot.rttHintMs}ms`);
  return parts.join(' · ');
}
