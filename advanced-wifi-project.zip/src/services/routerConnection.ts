import {
  detectAndroidEnvironment,
  FallbackExecutionResult,
  isHttpsPageToHttpTarget,
  MethodExecutionOutcome,
  runMultiMethodFallback
} from '../core/fallbackManager';
import { probeHg8145x6RuntimeCapabilities } from '../router-adapters/huawei-hg8145x6-10';
import { detectBestAdapter, getAdapterById } from '../router-adapters/registry';
import {
  ConnectedDevice,
  ConnectionAttemptLogEntry,
  ConnectionDiagnosticsState,
  ConnectionMethodId,
  CoreTokenSessionInfo,
  HttpRequestOptions,
  HttpResponse,
  RouterAdapter,
  RouterAdapterId,
  RouterCapabilities,
  RouterConnectionContext,
  RouterCredentials,
  RouterError,
  RouterErrorCode,
  RouterInfo,
  TransportRequestFn,
  WifiSettings,
  WifiUpdateInput
} from '../router-adapters/types';
import {
  isNativeAndroidApp,
  nativeClearSession,
  nativeHttpRequest,
  nativeProbeGateway
} from '../native/androidBridge';
import {
  createSimulatedHuaweiTransport,
  SimulationScenario
} from '../simulation/huaweiSimulator';
import { sanitizeDiagnosticText, validateRouterAddress } from '../utils/networkSecurity';

export type TransportMode = 'native_bridge' | 'connector' | 'direct' | 'core_lan' | 'cloud_relay' | 'simulation';

export const CONNECTOR_BASE_URL = 'http://127.0.0.1:4890';

export interface LocalConnectorHealth {
  reachable: boolean;
  authVerified: boolean;
  originBlocked: boolean;
  version?: string;
  platform?: string;
  arch?: string;
  nodeVersion?: string;
  uptimeSec?: number;
  checkedAtIso?: string;
}

export interface ServerCoreStatusSnapshot {
  ok: boolean;
  topology: 'local-lan' | 'cloud-hosted' | 'unknown';
  topologyReason: string;
  localInterfaces: string[];
  relayAgentsOnline: number;
  relayAgentsTotal: number;
}

export interface ActiveRouterSession {
  adapter: RouterAdapter;
  context: RouterConnectionContext;
  transportMode: TransportMode;
  connectionMethod: ConnectionMethodId;
  routerInfo: RouterInfo;
  wifiSettings: WifiSettings;
  devices: ConnectedDevice[];
  blockedMacs: string[];
  guestWifiEnabled: boolean | null;
  internetBlocked: boolean | null;
  runtimeCapabilities?: Partial<RouterCapabilities>;
  lastUpdatedIso: string;
}

export function getEffectiveCapabilities(session: ActiveRouterSession): RouterCapabilities {
  return {
    ...session.adapter.capabilities,
    ...(session.runtimeCapabilities || {})
  };
}

// Memory-only Core token store (never persisted to localStorage, cookies, or logs)
let activeCoreTokenValue: string | null = null;
let activeCoreSessionMeta: CoreTokenSessionInfo | null = null;

export function getCoreSessionSnapshot(): CoreTokenSessionInfo | null {
  return activeCoreSessionMeta;
}

export async function fetchServerCoreStatus(): Promise<ServerCoreStatusSnapshot> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 3000);
    const res = await fetch('/api/core/status', {
      cache: 'no-store',
      signal: controller.signal
    });
    clearTimeout(timer);
    if (!res.ok) {
      return {
        ok: false,
        topology: 'unknown',
        topologyReason: 'Core status endpoint unreachable',
        localInterfaces: [],
        relayAgentsOnline: 0,
        relayAgentsTotal: 0
      };
    }
    const data = (await res.json()) as Partial<ServerCoreStatusSnapshot>;
    return {
      ok: Boolean(data.ok),
      topology:
        data.topology === 'local-lan' || data.topology === 'cloud-hosted'
          ? data.topology
          : 'unknown',
      topologyReason: data.topologyReason || '',
      localInterfaces: Array.isArray(data.localInterfaces) ? data.localInterfaces : [],
      relayAgentsOnline: typeof data.relayAgentsOnline === 'number' ? data.relayAgentsOnline : 0,
      relayAgentsTotal: typeof data.relayAgentsTotal === 'number' ? data.relayAgentsTotal : 0
    };
  } catch {
    return {
      ok: false,
      topology: 'unknown',
      topologyReason: 'Core offline',
      localInterfaces: [],
      relayAgentsOnline: 0,
      relayAgentsTotal: 0
    };
  }
}

export async function ensureValidCoreToken(forceRotate = false): Promise<CoreTokenSessionInfo | null> {
  const now = Date.now();
  if (
    activeCoreTokenValue &&
    activeCoreSessionMeta &&
    !forceRotate &&
    now < activeCoreSessionMeta.refreshAfterMs
  ) {
    return activeCoreSessionMeta;
  }

  // Rotate existing session cleanly if due for renewal
  if (activeCoreTokenValue && activeCoreSessionMeta && now < activeCoreSessionMeta.expiresAtMs) {
    try {
      const res = await fetch('/api/core/tokens/refresh', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${activeCoreTokenValue}`,
          'Content-Type': 'application/json'
        }
      });
      if (res.ok) {
        const data = (await res.json()) as {
          ok: boolean;
          sessionId: string;
          token: string;
          expiresAtIso: string;
          expiresAtMs: number;
          refreshAfterMs: number;
          rotationCount: number;
        };
        if (data.ok && data.token) {
          activeCoreTokenValue = data.token;
          activeCoreSessionMeta = {
            sessionId: data.sessionId,
            expiresAtIso: data.expiresAtIso,
            expiresAtMs: data.expiresAtMs,
            refreshAfterMs: data.refreshAfterMs,
            rotationCount: data.rotationCount,
            status: 'renewed'
          };
          return activeCoreSessionMeta;
        }
      }
    } catch {
      // Fall through to issuing a clean fresh session
    }
  }

  try {
    const res = await fetch('/api/core/tokens/issue', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ clientLabel: 'advanced-wifi-web' })
    });
    if (!res.ok) return null;
    const data = (await res.json()) as {
      ok: boolean;
      sessionId: string;
      token: string;
      expiresAtIso: string;
      expiresAtMs: number;
      refreshAfterMs: number;
      rotationCount: number;
    };
    if (!data.ok || !data.token) return null;
    activeCoreTokenValue = data.token;
    activeCoreSessionMeta = {
      sessionId: data.sessionId,
      expiresAtIso: data.expiresAtIso,
      expiresAtMs: data.expiresAtMs,
      refreshAfterMs: data.refreshAfterMs,
      rotationCount: data.rotationCount,
      status: 'active'
    };
    return activeCoreSessionMeta;
  } catch {
    return null;
  }
}

export async function revokeCoreSessionToken(): Promise<void> {
  const token = activeCoreTokenValue;
  activeCoreTokenValue = null;
  if (activeCoreSessionMeta) {
    activeCoreSessionMeta = { ...activeCoreSessionMeta, status: 'revoked' };
  }
  if (!token) return;
  await fetch('/api/core/tokens/revoke', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  }).catch(() => undefined);
}

export async function registerRelayEnrollment(
  label: string,
  lanGatewayHint?: string
): Promise<{ agentId: string; relayToken: string; expiresAtIso: string } | null> {
  const session = await ensureValidCoreToken();
  if (!session || !activeCoreTokenValue) return null;
  try {
    const res = await fetch('/api/core/relay/register', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${activeCoreTokenValue}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ label, lanGatewayHint })
    });
    if (!res.ok) return null;
    const data = (await res.json()) as {
      ok?: boolean;
      agentId?: string;
      relayToken?: string;
      expiresAtIso?: string;
    };
    if (data.ok && data.agentId && data.relayToken && data.expiresAtIso) {
      return {
        agentId: data.agentId,
        relayToken: data.relayToken,
        expiresAtIso: data.expiresAtIso
      };
    }
    return null;
  } catch {
    return null;
  }
}

export async function checkLocalConnectorStatus(connectorToken?: string): Promise<LocalConnectorHealth> {
  const checkedAtIso = new Date().toISOString();
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 1400);
    const headers: Record<string, string> = {};
    if (connectorToken && connectorToken.trim()) {
      headers['X-Connector-Token'] = connectorToken.trim();
    }
    const res = await fetch(`${CONNECTOR_BASE_URL}/health`, {
      headers,
      cache: 'no-store',
      signal: controller.signal
    });
    clearTimeout(timer);

    if (res.status === 403) {
      return { reachable: true, authVerified: false, originBlocked: true, checkedAtIso };
    }
    if (!res.ok) {
      return { reachable: false, authVerified: false, originBlocked: false, checkedAtIso };
    }

    const data = (await res.json()) as {
      ok?: boolean;
      authVerified?: boolean;
      version?: string;
      platform?: string;
      arch?: string;
      nodeVersion?: string;
      uptimeSec?: number;
    };

    return {
      reachable: Boolean(data?.ok),
      authVerified: Boolean(data?.authVerified),
      originBlocked: false,
      version: data?.version,
      platform: data?.platform,
      arch: data?.arch,
      nodeVersion: data?.nodeVersion,
      uptimeSec: typeof data?.uptimeSec === 'number' ? data.uptimeSec : undefined,
      checkedAtIso
    };
  } catch {
    return { reachable: false, authVerified: false, originBlocked: false, checkedAtIso };
  }
}

export async function checkLocalConnectorHealth(connectorToken?: string): Promise<boolean> {
  const status = await checkLocalConnectorStatus(connectorToken);
  return status.reachable && (!connectorToken || status.authVerified);
}

export async function stopLocalConnector(connectorToken: string): Promise<boolean> {
  if (!connectorToken.trim()) return false;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 2000);
    const res = await fetch(`${CONNECTOR_BASE_URL}/shutdown`, {
      method: 'POST',
      headers: {
        'X-Connector-Token': connectorToken.trim()
      },
      signal: controller.signal
    });
    clearTimeout(timer);
    return res.ok;
  } catch {
    return false;
  }
}

export function createTransport(
  baseUrl: string,
  mode: TransportMode,
  sessionId: string,
  connectorToken = '',
  lanBridgeBaseUrl = '',
  simulationScenario: SimulationScenario = 'normal'
): TransportRequestFn {
  if (mode === 'simulation') {
    if (isNativeAndroidApp()) {
      throw new RouterError(
        'UNSUPPORTED_MODEL',
        'Simulation transport cannot override real hardware inside native Android app.'
      );
    }
    return createSimulatedHuaweiTransport(simulationScenario);
  }

  if (isNativeAndroidApp() && mode !== 'native_bridge') {
    throw new RouterError(
      'UNSUPPORTED_MODEL',
      `Direct Kotlin Native Bridge is enforced inside Android APK (blocked web transport: ${mode}).`
    );
  }

  return async (req: HttpRequestOptions): Promise<HttpResponse> => {
    const targetUrl = new URL(req.path, baseUrl).toString();
    const timeoutMs = req.timeoutMs ?? 6500;

    if (mode === 'native_bridge') {
      return nativeHttpRequest(sessionId, baseUrl, {
        ...req,
        timeoutMs
      });
    }

    if (mode === 'core_lan') {
      const bridgeEndpoint = lanBridgeBaseUrl.trim()
        ? `${lanBridgeBaseUrl.trim().replace(/\/+$/, '')}/api/core/router/request`
        : '/api/core/router/request';

      const tokenSession = await ensureValidCoreToken();
      if (!tokenSession || !activeCoreTokenValue) {
        throw new RouterError('TOKEN_INVALID', 'Failed to obtain Core session token');
      }

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs + 1500);
      try {
        const res = await fetch(bridgeEndpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${activeCoreTokenValue}`
          },
          body: JSON.stringify({
            url: targetUrl,
            method: req.method,
            headers: req.headers || {},
            body: req.body,
            timeoutMs
          }),
          signal: controller.signal
        });

        if (res.headers.get('X-Core-Token-Refresh-Recommended') === '1') {
          void ensureValidCoreToken(true);
        }

        if (res.status === 401) {
          const rotated = await ensureValidCoreToken(true);
          if (!rotated || !activeCoreTokenValue) {
            throw new RouterError('TOKEN_INVALID');
          }
          throw new RouterError('SESSION_EXPIRED');
        }

        const payload = (await res.json()) as {
          ok?: boolean;
          status?: number;
          headers?: Record<string, string>;
          body?: string;
          error?: string;
        };

        if (payload.error === 'CLOUD_ISOLATED_FROM_LAN') {
          throw new RouterError('CLOUD_ISOLATED_FROM_LAN');
        }
        if (payload.error === 'INVALID_ROUTER_ADDRESS') {
          throw new RouterError('INVALID_ROUTER_ADDRESS');
        }
        if (!payload.ok || payload.error === 'ROUTER_OFFLINE') {
          throw new RouterError('ROUTER_OFFLINE');
        }

        return {
          status: payload.status ?? 200,
          headers: payload.headers ?? {},
          body: payload.body ?? ''
        };
      } catch (err) {
        if (err instanceof RouterError) throw err;
        throw new RouterError(lanBridgeBaseUrl.trim() ? 'LAN_BRIDGE_UNAVAILABLE' : 'ROUTER_OFFLINE');
      } finally {
        clearTimeout(timer);
      }
    }

    if (mode === 'cloud_relay') {
      const tokenSession = await ensureValidCoreToken();
      if (!tokenSession || !activeCoreTokenValue) {
        throw new RouterError('TOKEN_INVALID');
      }

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs + 2000);
      try {
        const res = await fetch('/api/core/relay/request', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${activeCoreTokenValue}`
          },
          body: JSON.stringify({
            url: targetUrl,
            method: req.method,
            headers: req.headers || {},
            body: req.body,
            timeoutMs
          }),
          signal: controller.signal
        });
        const payload = (await res.json()) as {
          ok?: boolean;
          status?: number;
          headers?: Record<string, string>;
          body?: string;
          error?: string;
        };
        if (!payload.ok) {
          if (payload.error === 'INVALID_ROUTER_ADDRESS') throw new RouterError('INVALID_ROUTER_ADDRESS');
          throw new RouterError('RELAY_AGENT_OFFLINE');
        }
        return {
          status: payload.status ?? 200,
          headers: payload.headers ?? {},
          body: payload.body ?? ''
        };
      } catch (err) {
        if (err instanceof RouterError) throw err;
        throw new RouterError('RELAY_AGENT_OFFLINE');
      } finally {
        clearTimeout(timer);
      }
    }

    if (mode === 'connector') {
      const attemptProxy = async (): Promise<Response> => {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeoutMs + 1500);
        try {
          const headers: Record<string, string> = {
            'Content-Type': 'application/json',
            'X-Connector-Session': sessionId
          };
          if (connectorToken.trim()) {
            headers['X-Connector-Token'] = connectorToken.trim();
          }
          return await fetch(`${CONNECTOR_BASE_URL}/proxy`, {
            method: 'POST',
            headers,
            body: JSON.stringify({
              url: targetUrl,
              method: req.method,
              headers: req.headers || {},
              body: req.body,
              timeoutMs
            }),
            signal: controller.signal
          });
        } finally {
          clearTimeout(timer);
        }
      };

      let proxyRes: Response;
      try {
        proxyRes = await attemptProxy();
      } catch {
        if (req.method === 'GET') {
          try {
            await new Promise((r) => setTimeout(r, 200));
            proxyRes = await attemptProxy();
          } catch {
            throw new RouterError(
              'CONNECTOR_NOT_FOUND',
              'Local Connector is not reachable on 127.0.0.1:4890'
            );
          }
        } else {
          throw new RouterError(
            'CONNECTOR_NOT_FOUND',
            'Local Connector is not reachable on 127.0.0.1:4890'
          );
        }
      }

      if (proxyRes.status === 401) {
        throw new RouterError('CONNECTOR_AUTH_REQUIRED', 'Missing or invalid Local Connector token');
      }
      if (proxyRes.status === 403) {
        throw new RouterError('CONNECTOR_ORIGIN_BLOCKED', 'Current origin rejected by Local Connector');
      }

      const payload = (await proxyRes.json()) as {
        status?: number;
        headers?: Record<string, string>;
        body?: string;
        error?: string;
      };

      if (payload.error === 'INVALID_ROUTER_ADDRESS') {
        throw new RouterError('INVALID_ROUTER_ADDRESS');
      }
      if (payload.error === 'AUTH_REQUIRED') {
        throw new RouterError('CONNECTOR_AUTH_REQUIRED');
      }
      if (payload.error === 'ORIGIN_NOT_ALLOWED') {
        throw new RouterError('CONNECTOR_ORIGIN_BLOCKED');
      }
      if (payload.error === 'ROUTER_OFFLINE' || !proxyRes.ok) {
        throw new RouterError('ROUTER_OFFLINE');
      }

      return {
        status: payload.status ?? 200,
        headers: payload.headers ?? {},
        body: payload.body ?? ''
      };
    }

    // Direct Browser Request mode
    if (isHttpsPageToHttpTarget(baseUrl)) {
      throw new RouterError(
        'MIXED_CONTENT_HTTPS',
        'HTTPS page cannot issue direct HTTP requests to local LAN IP'
      );
    }

    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      const res = await fetch(targetUrl, {
        method: req.method,
        headers: req.headers,
        body: req.method !== 'GET' ? req.body : undefined,
        credentials: 'include',
        signal: controller.signal
      });
      clearTimeout(timer);
      const headers: Record<string, string> = {};
      res.headers.forEach((v, k) => {
        headers[k.toLowerCase()] = v;
      });
      return {
        status: res.status,
        headers,
        body: await res.text()
      };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      const lower = msg.toLowerCase();
      if (lower.includes('abort') || lower.includes('timeout')) {
        throw new RouterError('ROUTER_OFFLINE');
      }
      throw new RouterError('CORS_BLOCKED', sanitizeDiagnosticText(msg));
    }
  };
}

async function openAndAuthenticateSession(params: {
  normalizedUrl: string;
  preferredAdapterId: RouterAdapterId | 'auto';
  credentials: RouterCredentials;
  transportMode: TransportMode;
  connectionMethod: ConnectionMethodId;
  connectorToken?: string;
  lanBridgeUrl?: string;
  simulationScenario?: SimulationScenario;
  onStageChange?: (stage: ConnectionDiagnosticsState['state']) => void;
}): Promise<ActiveRouterSession> {
  const sessionId = `aw_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const transport = createTransport(
    params.normalizedUrl,
    params.transportMode,
    sessionId,
    params.connectorToken || '',
    params.lanBridgeUrl || '',
    params.simulationScenario || 'normal'
  );

  params.onStageChange?.('connecting');

  let adapter: RouterAdapter;
  if (params.preferredAdapterId === 'auto') {
    const [rootRes, hilinkProbe, ontProbe] = await Promise.all([
      transport({ method: 'GET', path: '/', timeoutMs: 3000 }).catch((e) => {
        throw e;
      }),
      transport({ method: 'GET', path: '/api/webserver/SesTokInfo', timeoutMs: 2500 }).catch(() => null),
      transport({ method: 'GET', path: '/asp/GetRandCount.asp', timeoutMs: 2500 }).catch(() => null)
    ]);

    params.onStageChange?.('modem_reachable');

    const detected = detectBestAdapter({
      rootStatus: rootRes.status,
      rootHeaders: rootRes.headers,
      rootBody: rootRes.body,
      extraProbeBody: hilinkProbe?.body,
      ontProbeBody: ontProbe?.body
    });
    adapter = detected.adapter;
  } else {
    adapter = getAdapterById(params.preferredAdapterId);
  }

  const context: RouterConnectionContext = {
    baseUrl: params.normalizedUrl,
    adapterId: adapter.id,
    transport,
    sessionState: { sessionId, connectorToken: params.connectorToken || '' }
  };

  await adapter.connect(context);
  params.onStageChange?.('modem_reachable');

  try {
    await adapter.authenticate(context, params.credentials);
  } catch (err) {
    if (err instanceof RouterError && err.code === 'INVALID_CREDENTIALS') {
      params.onStageChange?.('login_failed');
    }
    throw err;
  }

  params.onStageChange?.('authenticated');

  let routerInfo: RouterInfo;
  let wifiSettings: WifiSettings;
  let deviceResult: { connected: ConnectedDevice[]; blockedMacs: string[] };
  let guestWifiEnabled: boolean | null;
  let internetBlocked: boolean | null;
  let runtimeCapabilities: Partial<RouterCapabilities> | undefined;

  try {
    [routerInfo, wifiSettings, deviceResult, guestWifiEnabled, internetBlocked, runtimeCapabilities] =
      await Promise.all([
        adapter.getRouterInfo(context),
        adapter.capabilities.readWifiSettings
          ? adapter.getWifiSettings(context)
          : Promise.resolve({ band24: null, band5: null }),
        adapter.capabilities.listDevices
          ? adapter.getConnectedDevices(context)
          : Promise.resolve({ connected: [], blockedMacs: [] }),
        adapter.capabilities.guestWifi && adapter.getGuestWifiEnabled
          ? adapter.getGuestWifiEnabled(context).catch(() => null)
          : Promise.resolve(null),
        adapter.capabilities.blockAllInternet && adapter.getInternetAccessPaused
          ? adapter.getInternetAccessPaused(context).catch(() => null)
          : Promise.resolve(null),
        adapter.id === 'huawei-hg8145x6-10'
          ? probeHg8145x6RuntimeCapabilities(context).catch(() => undefined)
          : Promise.resolve(undefined)
      ]);
  } catch (err) {
    if (err instanceof RouterError && (err.code === 'SESSION_EXPIRED' || err.code === 'INVALID_CREDENTIALS')) {
      params.onStageChange?.('login_failed');
      throw err;
    }
    params.onStageChange?.('data_read_failed');
    throw new RouterError(
      'DATA_READ_FAILED',
      err instanceof RouterError ? err.technicalDetail || err.code : 'Authenticated with modem, but failed to read modem data.'
    );
  }

  const hasDeviceInfo =
    routerInfo.model !== null ||
    routerInfo.firmwareVersion !== null ||
    routerInfo.hardwareVersion !== null ||
    routerInfo.wanConnected !== null ||
    routerInfo.uptimeSeconds !== null;
  const hasWifiInfo = Boolean(wifiSettings.band24 || wifiSettings.band5);
  const hasDevicesInfo = deviceResult.connected.length > 0;

  if (!hasDeviceInfo && !hasWifiInfo && !hasDevicesInfo) {
    params.onStageChange?.('data_read_failed');
    throw new RouterError(
      'DATA_READ_FAILED',
      'Modem authentication succeeded, but no readable device info, Wi-Fi config, or LAN clients were returned.'
    );
  }

  params.onStageChange?.('connected');

  return {
    adapter,
    context,
    transportMode: params.transportMode,
    connectionMethod: params.connectionMethod,
    routerInfo,
    wifiSettings,
    devices: deviceResult.connected,
    blockedMacs: deviceResult.blockedMacs,
    guestWifiEnabled,
    internetBlocked,
    runtimeCapabilities,
    lastUpdatedIso: new Date().toISOString()
  };
}

export async function connectToRouter(params: {
  rawAddress: string;
  preferredAdapterId: RouterAdapterId | 'auto';
  credentials: RouterCredentials;
  transportMode: TransportMode;
  connectorToken?: string;
  lanBridgeUrl?: string;
  simulationScenario?: SimulationScenario;
  onStageChange?: (stage: ConnectionDiagnosticsState['state']) => void;
}): Promise<ActiveRouterSession> {
  // Note: Local LAN connections MUST NOT be blocked simply because navigator.onLine === false (offline WAN still permits LAN Wi-Fi router management).
  const validated = validateRouterAddress(params.rawAddress);
  if (!validated.valid) {
    throw new RouterError('INVALID_ROUTER_ADDRESS', validated.reason);
  }

  const resolvedTransportMode: TransportMode = isNativeAndroidApp() ? 'native_bridge' : params.transportMode;

  const methodMap: Record<TransportMode, ConnectionMethodId> = {
    native_bridge: 'android_native_bridge',
    direct: 'direct_browser',
    connector: 'local_connector',
    core_lan: 'lan_hosted_connector',
    cloud_relay: 'secure_cloud_relay',
    simulation: 'simulation'
  };

  return openAndAuthenticateSession({
    normalizedUrl: validated.normalizedUrl,
    preferredAdapterId: params.preferredAdapterId,
    credentials: params.credentials,
    transportMode: resolvedTransportMode,
    connectionMethod: methodMap[resolvedTransportMode],
    connectorToken: params.connectorToken,
    lanBridgeUrl: params.lanBridgeUrl,
    simulationScenario: params.simulationScenario,
    onStageChange: params.onStageChange
  });
}

async function probeRouterApiOverTransport(
  normalizedUrl: string,
  mode: TransportMode,
  connectorToken = '',
  lanBridgeUrl = ''
): Promise<{ detectedVendor: string; detectedProtocol: string }> {
  const transport = createTransport(normalizedUrl, mode, `probe_${Date.now()}`, connectorToken, lanBridgeUrl);
  const [ontRes, hilinkRes, restRes] = await Promise.all([
    transport({ method: 'GET', path: '/asp/GetRandCount.asp', timeoutMs: 2500 }).catch(() => null),
    transport({ method: 'GET', path: '/api/webserver/SesTokInfo', timeoutMs: 2500 }).catch(() => null),
    transport({ method: 'GET', path: '/api/system/deviceinfo', timeoutMs: 2500 }).catch(() => null)
  ]);

  if (ontRes && ontRes.status >= 200 && ontRes.status < 400 && ontRes.body.trim().length >= 6 && !ontRes.body.includes('<html')) {
    return { detectedVendor: 'Huawei', detectedProtocol: 'Huawei ONT ASP/CGI (/asp/GetRandCount.asp)' };
  }
  if (hilinkRes && hilinkRes.body.includes('<TokInfo>')) {
    return { detectedVendor: 'Huawei', detectedProtocol: 'Huawei HiLink XML (/api/webserver/SesTokInfo)' };
  }
  if (restRes && restRes.status >= 200 && restRes.status < 400) {
    return { detectedVendor: 'Router API', detectedProtocol: 'REST JSON (/api/system/deviceinfo)' };
  }
  throw new RouterError('ROUTER_API_UNSUPPORTED', 'No supported router API family responded on LAN target');
}

export async function executeAutoFallbackConnection(params: {
  rawAddress: string;
  autoDiscoverGateways?: boolean;
  preferredAdapterId: RouterAdapterId | 'auto';
  credentials: RouterCredentials;
  mode: 'probe' | 'connect';
  connectorToken?: string;
  lanBridgeUrl?: string;
  priorAttemptsLog?: ConnectionAttemptLogEntry[];
  onStageChange?: (stage: ConnectionDiagnosticsState['state']) => void;
}): Promise<FallbackExecutionResult<ActiveRouterSession>> {
  const nativeAndroid = isNativeAndroidApp();
  const coreStatus = nativeAndroid
    ? {
        ok: false,
        topology: 'local-lan' as const,
        topologyReason: 'Standalone Android APK',
        localInterfaces: [],
        relayAgentsOnline: 0,
        relayAgentsTotal: 0
      }
    : await fetchServerCoreStatus();
  const coreSession = nativeAndroid ? null : await ensureValidCoreToken();

  return runMultiMethodFallback<ActiveRouterSession>(
    {
      rawAddress: params.rawAddress,
      autoDiscoverGateways: params.autoDiscoverGateways,
      preferredAdapterId: params.preferredAdapterId,
      credentials: params.credentials,
      mode: params.mode,
      preferNativeAndroidBridge: nativeAndroid,
      lanBridgeUrl: params.lanBridgeUrl,
      priorAttemptsLog: params.priorAttemptsLog
    },
    {
      getRuntimeInfo: async () => ({
        serverTopology: coreStatus.topology,
        coreSession,
        isAndroid: nativeAndroid || detectAndroidEnvironment(),
        isNativeAndroidApp: nativeAndroid,
        isNavigatorOnline: typeof navigator !== 'undefined' ? navigator.onLine : true
      }),
      executeMethod: async ({
        methodId,
        gateway,
        mode,
        preferredAdapterId,
        credentials,
        lanBridgeUrl
      }): Promise<MethodExecutionOutcome<ActiveRouterSession>> => {
        const startedAt = Date.now();
        const elapsed = () => Math.max(1, Date.now() - startedAt);

        if (methodId === 'android_native_bridge') {
          if (!nativeAndroid) {
            return {
              ok: false,
              skipped: true,
              latencyMs: elapsed(),
              errorCode: 'NATIVE_BRIDGE_UNAVAILABLE',
              technicalSummary: 'Not running inside the Android APK shell'
            };
          }

          try {
            if (mode === 'probe') {
              const probe = await nativeProbeGateway(gateway.normalizedUrl, 3000);
              if (!probe.reachable) {
                return {
                  ok: false,
                  latencyMs: probe.latencyMs || elapsed(),
                  errorCode: (probe.errorCode as RouterErrorCode) || 'ROUTER_OFFLINE',
                  technicalSummary: probe.detail || 'Router unreachable over Android Wi-Fi interface'
                };
              }
              params.onStageChange?.('modem_reachable');
              return {
                ok: true,
                latencyMs: probe.latencyMs || elapsed(),
                technicalSummary: `Android Wi-Fi HTTP ${probe.status || 200} reachable`
              };
            }

            const session = await openAndAuthenticateSession({
              normalizedUrl: gateway.normalizedUrl,
              preferredAdapterId,
              credentials,
              transportMode: 'native_bridge',
              connectionMethod: 'android_native_bridge',
              onStageChange: params.onStageChange
            });
            return {
              ok: true,
              latencyMs: elapsed(),
              technicalSummary: `Native Bridge · ${session.routerInfo.vendor} ${session.routerInfo.model || 'ONT'}`,
              session
            };
          } catch (err) {
            const code: RouterErrorCode = err instanceof RouterError ? err.code : 'ROUTER_OFFLINE';
            return {
              ok: false,
              latencyMs: elapsed(),
              errorCode: code,
              technicalSummary: err instanceof RouterError ? err.technicalDetail : code
            };
          }
        }

        if (methodId === 'direct_browser') {
          if (isHttpsPageToHttpTarget(gateway.normalizedUrl)) {
            return {
              ok: false,
              latencyMs: elapsed(),
              errorCode: 'MIXED_CONTENT_HTTPS',
              technicalSummary: 'HTTPS origin blocks direct HTTP call to local LAN gateway'
            };
          }
          try {
            if (mode === 'probe') {
              const t = createTransport(gateway.normalizedUrl, 'direct', `probe_${Date.now()}`);
              const res = await t({ method: 'GET', path: '/', timeoutMs: 2500 });
              return {
                ok: res.status > 0,
                latencyMs: elapsed(),
                technicalSummary: `Direct HTTP ${res.status} reachable`
              };
            }
            const session = await openAndAuthenticateSession({
              normalizedUrl: gateway.normalizedUrl,
              preferredAdapterId,
              credentials,
              transportMode: 'direct',
              connectionMethod: 'direct_browser'
            });
            return {
              ok: true,
              latencyMs: elapsed(),
              technicalSummary: `${session.routerInfo.vendor} ${session.routerInfo.model}`,
              session
            };
          } catch (err) {
            const code: RouterErrorCode = err instanceof RouterError ? err.code : 'CORS_BLOCKED';
            return {
              ok: false,
              latencyMs: elapsed(),
              errorCode: code,
              technicalSummary: err instanceof RouterError ? err.technicalDetail : 'Blocked by browser CORS or unreachable'
            };
          }
        }

        if (methodId === 'router_api') {
          if (isHttpsPageToHttpTarget(gateway.normalizedUrl)) {
            return {
              ok: false,
              latencyMs: elapsed(),
              errorCode: 'MIXED_CONTENT_HTTPS',
              technicalSummary: 'Router API requires HTTP LAN origin or local bridge when app runs on HTTPS'
            };
          }
          try {
            const apiProbe = await probeRouterApiOverTransport(gateway.normalizedUrl, 'direct');
            if (mode === 'probe') {
              return {
                ok: true,
                latencyMs: elapsed(),
                technicalSummary: apiProbe.detectedProtocol
              };
            }
            const session = await openAndAuthenticateSession({
              normalizedUrl: gateway.normalizedUrl,
              preferredAdapterId,
              credentials,
              transportMode: 'direct',
              connectionMethod: 'router_api'
            });
            return {
              ok: true,
              latencyMs: elapsed(),
              technicalSummary: apiProbe.detectedProtocol,
              session
            };
          } catch (err) {
            const code: RouterErrorCode = err instanceof RouterError ? err.code : 'ROUTER_API_UNSUPPORTED';
            return {
              ok: false,
              latencyMs: elapsed(),
              errorCode: code,
              technicalSummary: err instanceof RouterError ? err.technicalDetail : code
            };
          }
        }

        if (methodId === 'local_connector') {
          const health = await checkLocalConnectorStatus(params.connectorToken);
          if (!health.reachable) {
            return {
              ok: false,
              latencyMs: elapsed(),
              errorCode: 'CONNECTOR_NOT_FOUND',
              technicalSummary: 'Local Connector is not running on 127.0.0.1:4890'
            };
          }
          if (health.originBlocked) {
            return {
              ok: false,
              latencyMs: elapsed(),
              errorCode: 'CONNECTOR_ORIGIN_BLOCKED',
              technicalSummary: 'Local Connector rejected current browser origin'
            };
          }
          if (params.connectorToken && !health.authVerified) {
            return {
              ok: false,
              latencyMs: elapsed(),
              errorCode: 'CONNECTOR_AUTH_REQUIRED',
              technicalSummary: 'Local Connector token rejected'
            };
          }
          try {
            if (mode === 'probe') {
              const t = createTransport(
                gateway.normalizedUrl,
                'connector',
                `probe_${Date.now()}`,
                params.connectorToken
              );
              const r = await t({ method: 'GET', path: '/', timeoutMs: 2500 });
              return {
                ok: r.status > 0,
                latencyMs: elapsed(),
                technicalSummary: `Local Connector v${health.version || '1.0'} -> HTTP ${r.status}`
              };
            }
            const session = await openAndAuthenticateSession({
              normalizedUrl: gateway.normalizedUrl,
              preferredAdapterId,
              credentials,
              transportMode: 'connector',
              connectionMethod: 'local_connector',
              connectorToken: params.connectorToken
            });
            return {
              ok: true,
              latencyMs: elapsed(),
              technicalSummary: `${session.routerInfo.vendor} ${session.routerInfo.model}`,
              session
            };
          } catch (err) {
            const code: RouterErrorCode = err instanceof RouterError ? err.code : 'ROUTER_OFFLINE';
            return {
              ok: false,
              latencyMs: elapsed(),
              errorCode: code,
              technicalSummary: err instanceof RouterError ? err.technicalDetail : code
            };
          }
        }

        if (methodId === 'lan_hosted_connector') {
          const hasCustomLanBridge = Boolean(lanBridgeUrl && lanBridgeUrl.trim());
          if (!hasCustomLanBridge && coreStatus.topology === 'cloud-hosted') {
            return {
              ok: false,
              skipped: true,
              latencyMs: elapsed(),
              errorCode: 'CLOUD_ISOLATED_FROM_LAN',
              technicalSummary:
                'Hosted on cloud server; cloud cannot directly reach private 192.168.x.x LAN without LAN hosting or a LAN bridge.'
            };
          }
          try {
            if (mode === 'probe') {
              const t = createTransport(
                gateway.normalizedUrl,
                'core_lan',
                `probe_${Date.now()}`,
                '',
                lanBridgeUrl
              );
              const r = await t({ method: 'GET', path: '/', timeoutMs: 3000 });
              return {
                ok: r.status > 0,
                latencyMs: elapsed(),
                technicalSummary: `Core LAN HTTP ${r.status}`
              };
            }
            const session = await openAndAuthenticateSession({
              normalizedUrl: gateway.normalizedUrl,
              preferredAdapterId,
              credentials,
              transportMode: 'core_lan',
              connectionMethod: 'lan_hosted_connector',
              lanBridgeUrl
            });
            return {
              ok: true,
              latencyMs: elapsed(),
              technicalSummary: `Core LAN · ${session.routerInfo.vendor} ${session.routerInfo.model}`,
              session
            };
          } catch (err) {
            const code: RouterErrorCode = err instanceof RouterError ? err.code : 'LAN_BRIDGE_UNAVAILABLE';
            return {
              ok: false,
              latencyMs: elapsed(),
              errorCode: code,
              technicalSummary: err instanceof RouterError ? err.technicalDetail : code
            };
          }
        }

        if (methodId === 'secure_cloud_relay') {
          if (coreStatus.relayAgentsOnline === 0) {
            return {
              ok: false,
              latencyMs: elapsed(),
              errorCode: 'RELAY_AGENT_OFFLINE',
              technicalSummary: 'No enrolled in-LAN relay agent is currently online.'
            };
          }
          try {
            if (mode === 'probe') {
              const t = createTransport(gateway.normalizedUrl, 'cloud_relay', `probe_${Date.now()}`);
              const r = await t({ method: 'GET', path: '/', timeoutMs: 4000 });
              return {
                ok: r.status > 0,
                latencyMs: elapsed(),
                technicalSummary: `Cloud Relay -> HTTP ${r.status}`
              };
            }
            const session = await openAndAuthenticateSession({
              normalizedUrl: gateway.normalizedUrl,
              preferredAdapterId,
              credentials,
              transportMode: 'cloud_relay',
              connectionMethod: 'secure_cloud_relay'
            });
            return {
              ok: true,
              latencyMs: elapsed(),
              technicalSummary: `Relay · ${session.routerInfo.vendor} ${session.routerInfo.model}`,
              session
            };
          } catch (err) {
            const code: RouterErrorCode = err instanceof RouterError ? err.code : 'RELAY_AGENT_OFFLINE';
            return {
              ok: false,
              latencyMs: elapsed(),
              errorCode: code,
              technicalSummary: err instanceof RouterError ? err.technicalDetail : code
            };
          }
        }

        // Method 6: android_companion (Last Resort Only)
        const isAndroid = detectAndroidEnvironment();
        return {
          ok: false,
          latencyMs: elapsed(),
          errorCode: 'ANDROID_COMPANION_REQUIRED',
          technicalSummary: isAndroid
            ? `Android browser sandboxing blocked direct LAN access to ${gateway.ipOrHost}. Use Android direct gateway opener or LAN-hosted session.`
            : `All 5 transport methods failed to reach ${gateway.ipOrHost}; companion LAN access required.`
        };
      }
    }
  );
}

export async function refreshRouterSession(session: ActiveRouterSession): Promise<ActiveRouterSession> {
  const [routerInfo, wifiSettings, deviceResult, guestWifiEnabled, internetBlocked] = await Promise.all([
    session.adapter.getRouterInfo(session.context),
    session.adapter.capabilities.readWifiSettings
      ? session.adapter.getWifiSettings(session.context)
      : Promise.resolve(session.wifiSettings),
    session.adapter.capabilities.listDevices
      ? session.adapter.getConnectedDevices(session.context)
      : Promise.resolve({ connected: session.devices, blockedMacs: session.blockedMacs }),
    session.adapter.capabilities.guestWifi && session.adapter.getGuestWifiEnabled
      ? session.adapter.getGuestWifiEnabled(session.context).catch(() => session.guestWifiEnabled)
      : Promise.resolve(session.guestWifiEnabled),
    session.adapter.capabilities.blockAllInternet && session.adapter.getInternetAccessPaused
      ? session.adapter.getInternetAccessPaused(session.context).catch(() => session.internetBlocked)
      : Promise.resolve(session.internetBlocked)
  ]);

  return {
    ...session,
    routerInfo,
    wifiSettings,
    devices: deviceResult.connected,
    blockedMacs: deviceResult.blockedMacs,
    guestWifiEnabled,
    internetBlocked,
    lastUpdatedIso: new Date().toISOString()
  };
}

export async function applyRouterWifiUpdate(
  session: ActiveRouterSession,
  update: WifiUpdateInput
): Promise<ActiveRouterSession> {
  if (!getEffectiveCapabilities(session).writeWifiSettings) {
    throw new RouterError('UNSUPPORTED_MODEL');
  }
  await session.adapter.updateWifiSettings(session.context, update);
  const wifiSettings = await session.adapter.getWifiSettings(session.context).catch(() => session.wifiSettings);
  return {
    ...session,
    wifiSettings,
    lastUpdatedIso: new Date().toISOString()
  };
}

export async function blockRouterDevice(
  session: ActiveRouterSession,
  macAddress: string
): Promise<ActiveRouterSession> {
  if (!getEffectiveCapabilities(session).blockMacDevice) {
    throw new RouterError('UNSUPPORTED_MODEL');
  }
  await session.adapter.blockDevice(session.context, macAddress);
  const deviceResult = await session.adapter.getConnectedDevices(session.context);
  return {
    ...session,
    devices: deviceResult.connected,
    blockedMacs: deviceResult.blockedMacs,
    lastUpdatedIso: new Date().toISOString()
  };
}

export async function unblockRouterDevice(
  session: ActiveRouterSession,
  macAddress: string
): Promise<ActiveRouterSession> {
  if (!getEffectiveCapabilities(session).unblockMacDevice) {
    throw new RouterError('UNSUPPORTED_MODEL');
  }
  await session.adapter.unblockDevice(session.context, macAddress);
  const deviceResult = await session.adapter.getConnectedDevices(session.context);
  return {
    ...session,
    devices: deviceResult.connected,
    blockedMacs: deviceResult.blockedMacs,
    lastUpdatedIso: new Date().toISOString()
  };
}

export async function rebootConnectedRouter(session: ActiveRouterSession): Promise<void> {
  if (!getEffectiveCapabilities(session).rebootRouter || !session.adapter.rebootRouter) {
    throw new RouterError('UNSUPPORTED_MODEL');
  }
  await session.adapter.rebootRouter(session.context);
}

export async function toggleGuestWifi(
  session: ActiveRouterSession,
  enabled: boolean
): Promise<ActiveRouterSession> {
  if (!getEffectiveCapabilities(session).guestWifi || !session.adapter.setGuestWifiEnabled) {
    throw new RouterError('UNSUPPORTED_MODEL');
  }
  await session.adapter.setGuestWifiEnabled(session.context, enabled);
  return {
    ...session,
    guestWifiEnabled: enabled,
    lastUpdatedIso: new Date().toISOString()
  };
}

export async function toggleInternetAccess(
  session: ActiveRouterSession,
  blocked: boolean
): Promise<ActiveRouterSession> {
  if (!getEffectiveCapabilities(session).blockAllInternet || !session.adapter.setInternetAccessPaused) {
    throw new RouterError('UNSUPPORTED_MODEL');
  }
  await session.adapter.setInternetAccessPaused(session.context, blocked);
  return {
    ...session,
    internetBlocked: blocked,
    routerInfo: {
      ...session.routerInfo,
      wanConnected: !blocked
    },
    lastUpdatedIso: new Date().toISOString()
  };
}

export async function disconnectRouterSession(session: ActiveRouterSession): Promise<void> {
  await session.adapter.disconnect(session.context).catch(() => undefined);
  if (session.transportMode === 'native_bridge' && session.context.sessionState.sessionId) {
    nativeClearSession(session.context.sessionState.sessionId);
  }
  if (session.transportMode === 'connector' && session.context.sessionState.sessionId) {
    const headers: Record<string, string> = {
      'X-Connector-Session': session.context.sessionState.sessionId
    };
    if (session.context.sessionState.connectorToken) {
      headers['X-Connector-Token'] = session.context.sessionState.connectorToken;
    }
    await fetch(`${CONNECTOR_BASE_URL}/session/clear`, {
      method: 'POST',
      headers
    }).catch(() => undefined);
  }
  await revokeCoreSessionToken();
}
