import test from 'node:test';
import assert from 'node:assert/strict';
import { RouterError, TransportRequestFn } from '../router-adapters/types';
import { createSimulatedHuaweiTransport } from '../simulation/huaweiSimulator';
import { runModemProtocolDiagnostics } from './routerDiagnostics';

test('runModemProtocolDiagnostics passes all 10 stages cleanly on simulated HG8145X6-10', async () => {
  const report = await runModemProtocolDiagnostics({
    rawAddress: '192.168.100.1',
    preferredAdapterId: 'huawei-hg8145x6-10',
    credentials: { username: 'admin', password: 'admin' },
    transportMode: 'simulation',
    simulationScenario: 'normal'
  });

  assert.equal(report.isSimulation, true);
  assert.equal(report.adapterId, 'huawei-hg8145x6-10');
  assert.equal(report.detectedVendor, 'Huawei (DZTELCOM)');
  assert.equal(report.detectedModel, 'OptiXstar HG8145X6-10');
  assert.equal(report.stages.length, 10);

  const byId = new Map(report.stages.map((s) => [s.id, s]));
  assert.equal(byId.get('gateway_reachable')?.outcome, 'passed');
  assert.equal(byId.get('http_response')?.outcome, 'passed');
  assert.equal(byId.get('auth_discovery')?.outcome, 'passed');
  assert.equal(byId.get('login')?.outcome, 'passed');
  assert.equal(byId.get('session_valid')?.outcome, 'passed');
  assert.equal(byId.get('read_device_info')?.outcome, 'passed');
  assert.equal(byId.get('read_wifi_info')?.outcome, 'passed');
  assert.equal(byId.get('read_devices')?.outcome, 'passed');
  assert.equal(byId.get('wifi_write_capability')?.outcome, 'supported');
  assert.equal(byId.get('reboot_capability')?.outcome, 'supported');
});

test('runModemProtocolDiagnostics stops at login with INVALID_CREDENTIALS and marks remaining stages not_tested', async () => {
  const report = await runModemProtocolDiagnostics({
    rawAddress: 'http://192.168.100.1',
    preferredAdapterId: 'auto',
    credentials: { username: 'admin', password: 'wrongpassword' },
    transportMode: 'simulation',
    simulationScenario: 'invalid_credentials'
  });

  const byId = new Map(report.stages.map((s) => [s.id, s]));
  assert.equal(byId.get('gateway_reachable')?.outcome, 'passed');
  assert.equal(byId.get('http_response')?.outcome, 'passed');
  assert.equal(byId.get('auth_discovery')?.outcome, 'passed');
  assert.equal(byId.get('login')?.outcome, 'failed');
  assert.equal(byId.get('login')?.httpStatus, 401);
  assert.equal(byId.get('session_valid')?.outcome, 'not_tested');
  assert.equal(byId.get('read_device_info')?.outcome, 'not_tested');
  assert.equal(byId.get('read_wifi_info')?.outcome, 'not_tested');
  assert.equal(byId.get('read_devices')?.outcome, 'not_tested');
  assert.equal(byId.get('wifi_write_capability')?.outcome, 'not_tested');
  assert.equal(byId.get('reboot_capability')?.outcome, 'not_tested');
});

test('runModemProtocolDiagnostics fails cleanly on unreachable gateway without hanging', async () => {
  const offlineTransport: TransportRequestFn = async () => {
    throw new RouterError('ROUTER_OFFLINE', 'Connect timed out to 192.168.100.1:80');
  };

  const report = await runModemProtocolDiagnostics({
    rawAddress: '192.168.100.1',
    preferredAdapterId: 'huawei-hg8145x6-10',
    credentials: { username: 'admin', password: 'admin' },
    transportMode: 'direct',
    customTransport: offlineTransport
  });

  const byId = new Map(report.stages.map((s) => [s.id, s]));
  assert.equal(report.isSimulation, false);
  assert.equal(byId.get('gateway_reachable')?.outcome, 'failed');
  assert.equal(byId.get('http_response')?.outcome, 'failed');
  assert.equal(byId.get('auth_discovery')?.outcome, 'not_tested');
  assert.equal(byId.get('login')?.outcome, 'not_tested');
});

test('runModemProtocolDiagnostics marks reboot_capability unsupported when reset page returns 404', async () => {
  const baseSim = createSimulatedHuaweiTransport('normal');
  const wrappedTransport: TransportRequestFn = async (req) => {
    if (req.path === '/html/ssmp/reset/reset.asp') {
      return { status: 404, headers: {}, body: '404 Not Found' };
    }
    return baseSim(req);
  };

  const report = await runModemProtocolDiagnostics({
    rawAddress: 'http://192.168.100.1',
    preferredAdapterId: 'huawei-hg8145x6-10',
    credentials: { username: 'admin', password: 'admin' },
    transportMode: 'native_bridge',
    customTransport: wrappedTransport
  });

  const byId = new Map(report.stages.map((s) => [s.id, s]));
  assert.equal(byId.get('read_device_info')?.outcome, 'passed');
  assert.equal(byId.get('wifi_write_capability')?.outcome, 'supported');
  assert.equal(byId.get('reboot_capability')?.outcome, 'unsupported');
});
