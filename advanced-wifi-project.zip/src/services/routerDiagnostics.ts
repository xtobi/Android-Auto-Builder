import { isNativeAndroidApp } from '../native/androidBridge';
import { probeHg8145x6RuntimeCapabilities } from '../router-adapters/huawei-hg8145x6-10';
import { detectBestAdapter, getAdapterById } from '../router-adapters/registry';
import {
  HttpResponse,
  ModemDiagnosticReport,
  ModemDiagnosticStageId,
  ModemDiagnosticStageResult,
  RouterAdapter,
  RouterAdapterId,
  RouterCapabilities,
  RouterConnectionContext,
  RouterCredentials,
  RouterError,
  TransportRequestFn
} from '../router-adapters/types';
import { SimulationScenario } from '../simulation/huaweiSimulator';
import { sanitizeDiagnosticText, validateRouterAddress } from '../utils/networkSecurity';
import { createTransport, TransportMode } from './routerConnection';

const ALL_STAGE_IDS: ModemDiagnosticStageId[] = [
  'gateway_reachable',
  'http_response',
  'auth_discovery',
  'login',
  'session_valid',
  'read_device_info',
  'read_wifi_info',
  'read_devices',
  'wifi_write_capability',
  'reboot_capability'
];

function fillRemainingNotTested(
  existing: ModemDiagnosticStageResult[],
  detail?: string
): ModemDiagnosticStageResult[] {
  const map = new Map(existing.map((s) => [s.id, s]));
  return ALL_STAGE_IDS.map(
    (id) =>
      map.get(id) ?? {
        id,
        outcome: 'not_tested',
        httpStatus: null,
        endpoint: null,
        latencyMs: null,
        technicalDetail: detail || null
      }
  );
}

export async function runModemProtocolDiagnostics(params: {
  rawAddress: string;
  preferredAdapterId: RouterAdapterId | 'auto';
  credentials: RouterCredentials;
  transportMode?: TransportMode;
  connectorToken?: string;
  lanBridgeUrl?: string;
  simulationScenario?: SimulationScenario;
  customTransport?: TransportRequestFn;
}): Promise<ModemDiagnosticReport> {
  const checkedAtIso = new Date().toISOString();
  const validated = validateRouterAddress(params.rawAddress);
  const mode: TransportMode =
    params.transportMode ??
    (isNativeAndroidApp() ? 'native_bridge' : 'direct');

  const isSimulation = mode === 'simulation';

  if (!validated.valid) {
    const failedStages: ModemDiagnosticStageResult[] = [
      {
        id: 'gateway_reachable',
        outcome: 'failed',
        httpStatus: null,
        endpoint: '/',
        latencyMs: 0,
        technicalDetail: validated.reason
      }
    ];
    return {
      checkedAtIso,
      targetUrl: params.rawAddress,
      adapterId: params.preferredAdapterId,
      transportMode: mode,
      isSimulation,
      detectedVendor: null,
      detectedModel: null,
      stages: fillRemainingNotTested(failedStages, 'Target address failed LAN validation')
    };
  }

  const sessionId = `diag_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const transport =
    params.customTransport ??
    createTransport(
      validated.normalizedUrl,
      mode,
      sessionId,
      params.connectorToken || '',
      params.lanBridgeUrl || '',
      params.simulationScenario || 'normal'
    );

  const stages: ModemDiagnosticStageResult[] = [];
  let detectedVendor: string | null = null;
  let detectedModel: string | null = null;
  let activeAdapter: RouterAdapter | null = null;
  let ctx: RouterConnectionContext | null = null;

  try {
    // 1. Gateway reachable & 2. HTTP Server response
    const t0 = Date.now();
    let rootRes: HttpResponse;
    try {
      rootRes = await transport({ method: 'GET', path: '/', timeoutMs: 4000 });
      const latencyMs = Math.max(1, Date.now() - t0);
      stages.push({
        id: 'gateway_reachable',
        outcome: 'passed',
        httpStatus: rootRes.status,
        endpoint: '/',
        latencyMs,
        technicalDetail: `HTTP ${rootRes.status} over ${mode}`
      });
      stages.push({
        id: 'http_response',
        outcome: rootRes.status > 0 && rootRes.status < 500 ? 'passed' : 'failed',
        httpStatus: rootRes.status,
        endpoint: '/',
        latencyMs,
        technicalDetail: rootRes.headers['server']
          ? `HTTP ${rootRes.status} (${sanitizeDiagnosticText(rootRes.headers['server'])})`
          : `HTTP ${rootRes.status}`
      });
    } catch (err) {
      const latencyMs = Math.max(1, Date.now() - t0);
      const code = err instanceof RouterError ? err.code : 'ROUTER_OFFLINE';
      const detail = err instanceof RouterError ? err.technicalDetail || code : sanitizeDiagnosticText(String(err));
      stages.push({
        id: 'gateway_reachable',
        outcome: 'failed',
        httpStatus: null,
        endpoint: '/',
        latencyMs,
        technicalDetail: detail
      });
      stages.push({
        id: 'http_response',
        outcome: 'failed',
        httpStatus: null,
        endpoint: '/',
        latencyMs: null,
        technicalDetail: code
      });
      return {
        checkedAtIso,
        targetUrl: validated.normalizedUrl,
        adapterId: params.preferredAdapterId,
        transportMode: mode,
        isSimulation,
        detectedVendor: null,
        detectedModel: null,
        stages: fillRemainingNotTested(stages)
      };
    }

    // 3. Auth interface discovery
    const tAuth0 = Date.now();
    const [ontProbe, hilinkProbe] = await Promise.all([
      transport({ method: 'GET', path: '/asp/GetRandCount.asp', timeoutMs: 3000 }).catch(() => null),
      transport({ method: 'GET', path: '/api/webserver/SesTokInfo', timeoutMs: 3000 }).catch(() => null)
    ]);
    const authLatency = Math.max(1, Date.now() - tAuth0);

    if (params.preferredAdapterId === 'auto') {
      const detected = detectBestAdapter({
        rootStatus: rootRes.status,
        rootHeaders: rootRes.headers,
        rootBody: rootRes.body,
        extraProbeBody: hilinkProbe?.body,
        ontProbeBody: ontProbe?.body
      });
      activeAdapter = detected.adapter;
    } else {
      activeAdapter = getAdapterById(params.preferredAdapterId);
    }
    detectedVendor = activeAdapter.vendor;

    const ontTokenFound =
      Boolean(ontProbe && ontProbe.status >= 200 && ontProbe.status < 400 && ontProbe.body.trim().length >= 6 && !ontProbe.body.includes('<html'));
    const hilinkFound = Boolean(hilinkProbe && hilinkProbe.body.includes('<TokInfo>'));
    const hasLoginForm = /action=["'][^"']*login\.cgi|<form[^>]+login/i.test(rootRes.body);

    stages.push({
      id: 'auth_discovery',
      outcome: ontTokenFound || hilinkFound || hasLoginForm ? 'passed' : 'unknown',
      httpStatus: ontProbe?.status ?? hilinkProbe?.status ?? rootRes.status,
      endpoint: ontTokenFound ? '/asp/GetRandCount.asp' : hilinkFound ? '/api/webserver/SesTokInfo' : '/',
      latencyMs: authLatency,
      technicalDetail: ontTokenFound
        ? 'ONT ASP Challenge (/asp/GetRandCount.asp)'
        : hilinkFound
        ? 'HiLink XML (/api/webserver/SesTokInfo)'
        : hasLoginForm
        ? 'HTML Login Form (/login.cgi)'
        : `Adapter=${activeAdapter.id}`
    });

    // Stop cleanly here if user did not enter password for authenticated checks
    if (!params.credentials.password) {
      return {
        checkedAtIso,
        targetUrl: validated.normalizedUrl,
        adapterId: activeAdapter.id,
        transportMode: mode,
        isSimulation,
        detectedVendor,
        detectedModel: null,
        stages: fillRemainingNotTested(stages, 'Credentials required for authenticated stages')
      };
    }

    ctx = {
      baseUrl: validated.normalizedUrl,
      adapterId: activeAdapter.id,
      transport,
      sessionState: { sessionId, connectorToken: params.connectorToken || '' }
    };

    // 4. Login
    const tLogin0 = Date.now();
    try {
      await activeAdapter.connect(ctx);
      await activeAdapter.authenticate(ctx, params.credentials);
      stages.push({
        id: 'login',
        outcome: 'passed',
        httpStatus: 200,
        endpoint: activeAdapter.id === 'huawei-hg8145x6-10' ? '/login.cgi' : '/',
        latencyMs: Math.max(1, Date.now() - tLogin0),
        technicalDetail: `Authenticated via ${activeAdapter.id}`
      });
    } catch (err) {
      const code = err instanceof RouterError ? err.code : 'INVALID_CREDENTIALS';
      const detail = err instanceof RouterError ? err.technicalDetail || code : sanitizeDiagnosticText(String(err));
      stages.push({
        id: 'login',
        outcome: 'failed',
        httpStatus: code === 'INVALID_CREDENTIALS' ? 401 : null,
        endpoint: '/login.cgi',
        latencyMs: Math.max(1, Date.now() - tLogin0),
        technicalDetail: detail
      });
      return {
        checkedAtIso,
        targetUrl: validated.normalizedUrl,
        adapterId: activeAdapter.id,
        transportMode: mode,
        isSimulation,
        detectedVendor,
        detectedModel: null,
        stages: fillRemainingNotTested(stages, 'Login rejected')
      };
    }

    // 5. Session Valid & 6. Read Device Info
    const tInfo0 = Date.now();
    try {
      const info = await activeAdapter.getRouterInfo(ctx);
      const infoLatency = Math.max(1, Date.now() - tInfo0);
      detectedVendor = info.vendor;
      detectedModel = info.model;

      stages.push({
        id: 'session_valid',
        outcome: 'passed',
        httpStatus: 200,
        endpoint: activeAdapter.id === 'huawei-hg8145x6-10' ? '/html/ssmp/devinfo/devinfo.asp' : '/',
        latencyMs: infoLatency,
        technicalDetail: 'Protected device endpoint accessible'
      });

      const hasUsefulIdentity = Boolean(info.model || info.firmwareVersion || info.hardwareVersion);
      stages.push({
        id: 'read_device_info',
        outcome: hasUsefulIdentity ? 'passed' : 'unknown',
        httpStatus: 200,
        endpoint: activeAdapter.id === 'huawei-hg8145x6-10' ? '/html/ssmp/devinfo/devinfo.asp' : '/',
        latencyMs: infoLatency,
        technicalDetail: [
          info.model ? `Model=${info.model}` : 'Model=unavailable',
          info.firmwareVersion ? `FW=${info.firmwareVersion}` : null,
          info.hardwareVersion ? `HW=${info.hardwareVersion}` : null
        ]
          .filter(Boolean)
          .join(' · ')
      });
    } catch (err) {
      const code = err instanceof RouterError ? err.code : 'SESSION_EXPIRED';
      const latency = Math.max(1, Date.now() - tInfo0);
      stages.push({
        id: 'session_valid',
        outcome: 'failed',
        httpStatus: code === 'SESSION_EXPIRED' ? 401 : null,
        endpoint: '/html/ssmp/devinfo/devinfo.asp',
        latencyMs: latency,
        technicalDetail: code
      });
      stages.push({
        id: 'read_device_info',
        outcome: 'failed',
        httpStatus: null,
        endpoint: '/html/ssmp/devinfo/devinfo.asp',
        latencyMs: null,
        technicalDetail: code
      });
      return {
        checkedAtIso,
        targetUrl: validated.normalizedUrl,
        adapterId: activeAdapter.id,
        transportMode: mode,
        isSimulation,
        detectedVendor,
        detectedModel,
        stages: fillRemainingNotTested(stages)
      };
    }

    // 7. Read Wi-Fi info
    const tWifi0 = Date.now();
    try {
      const wifi = await activeAdapter.getWifiSettings(ctx);
      const count = [wifi.band24, wifi.band5].filter(Boolean).length;
      stages.push({
        id: 'read_wifi_info',
        outcome: count > 0 ? 'passed' : 'failed',
        httpStatus: 200,
        endpoint: activeAdapter.id === 'huawei-hg8145x6-10' ? '/html/amp/wlaninfo/wlaninfo.asp' : '/wlan',
        latencyMs: Math.max(1, Date.now() - tWifi0),
        technicalDetail:
          count > 0
            ? `Parsed ${count} band(s): ${[wifi.band24?.ssid, wifi.band5?.ssid].filter(Boolean).join(', ')}`
            : 'No WLAN configuration entries parsed'
      });
    } catch (err) {
      const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
      stages.push({
        id: 'read_wifi_info',
        outcome: 'failed',
        httpStatus: null,
        endpoint: '/html/amp/wlaninfo/wlaninfo.asp',
        latencyMs: Math.max(1, Date.now() - tWifi0),
        technicalDetail: code
      });
    }

    // 8. Read Connected Devices
    const tDev0 = Date.now();
    try {
      const devs = await activeAdapter.getConnectedDevices(ctx);
      stages.push({
        id: 'read_devices',
        outcome: 'passed',
        httpStatus: 200,
        endpoint: activeAdapter.id === 'huawei-hg8145x6-10' ? '/html/bbsp/common/GetLanUserDevInfo.asp' : '/hosts',
        latencyMs: Math.max(1, Date.now() - tDev0),
        technicalDetail: `${devs.connected.length} active, ${devs.blockedMacs.length} blocked`
      });
    } catch (err) {
      const code = err instanceof RouterError ? err.code : 'SETTINGS_APPLY_FAILED';
      stages.push({
        id: 'read_devices',
        outcome: 'failed',
        httpStatus: null,
        endpoint: '/html/bbsp/common/GetLanUserDevInfo.asp',
        latencyMs: Math.max(1, Date.now() - tDev0),
        technicalDetail: code
      });
    }

    // 9. Wi-Fi write capability & 10. Reboot capability (non-destructive page probes!)
    const tCap0 = Date.now();
    if (activeAdapter.id === 'huawei-hg8145x6-10') {
      const probedCaps: Partial<RouterCapabilities> = await probeHg8145x6RuntimeCapabilities(ctx).catch(() => ({}));
      const capLatency = Math.max(1, Date.now() - tCap0);
      stages.push({
        id: 'wifi_write_capability',
        outcome:
          probedCaps.writeWifiSettings === true
            ? 'supported'
            : probedCaps.writeWifiSettings === false
            ? 'unsupported'
            : 'unknown',
        httpStatus: probedCaps.writeWifiSettings === true ? 200 : null,
        endpoint: '/html/amp/wlanbasic/WlanBasic.asp',
        latencyMs: capLatency,
        technicalDetail:
          probedCaps.writeWifiSettings === true
            ? 'WLAN configuration form accessible'
            : 'WLAN configuration page did not expose editable controls'
      });
      stages.push({
        id: 'reboot_capability',
        outcome:
          probedCaps.rebootRouter === true
            ? 'supported'
            : probedCaps.rebootRouter === false
            ? 'unsupported'
            : 'unknown',
        httpStatus: probedCaps.rebootRouter === true ? 200 : null,
        endpoint: '/html/ssmp/reset/reset.asp',
        latencyMs: capLatency,
        technicalDetail:
          probedCaps.rebootRouter === true
            ? 'Reboot endpoint accessible (not executed during diagnostics)'
            : 'Reboot page did not respond cleanly'
      });
    } else {
      stages.push({
        id: 'wifi_write_capability',
        outcome: activeAdapter.capabilities.writeWifiSettings ? 'supported' : 'unsupported',
        httpStatus: null,
        endpoint: null,
        latencyMs: null,
        technicalDetail: `Declared by ${activeAdapter.id} adapter`
      });
      stages.push({
        id: 'reboot_capability',
        outcome: activeAdapter.capabilities.rebootRouter ? 'supported' : 'unsupported',
        httpStatus: null,
        endpoint: null,
        latencyMs: null,
        technicalDetail: `Declared by ${activeAdapter.id} adapter`
      });
    }

    return {
      checkedAtIso,
      targetUrl: validated.normalizedUrl,
      adapterId: activeAdapter.id,
      transportMode: mode,
      isSimulation,
      detectedVendor,
      detectedModel,
      stages: fillRemainingNotTested(stages)
    };
  } finally {
    if (activeAdapter && ctx) {
      await activeAdapter.disconnect(ctx).catch(() => undefined);
    }
  }
}
