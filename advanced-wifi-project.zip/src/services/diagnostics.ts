import { ConnectedDevice, RouterInfo, WifiSettings } from '../router-adapters/types';
import { SpeedTestMeasurement } from './speedTest';

export type DiagnosticCategory = 'confirmed' | 'possible' | 'unavailable';
export type DiagnosticSeverity = 'high' | 'medium' | 'info';

export interface DiagnosticItem {
  id: string;
  category: DiagnosticCategory;
  severity: DiagnosticSeverity;
  titleKey: string;
  evidenceText: string;
  recommendationKey: string;
}

export interface DiagnosticsInput {
  latestSpeed: SpeedTestMeasurement | null;
  speedHistory: SpeedTestMeasurement[];
  routerConnected: boolean;
  routerInfo: RouterInfo | null;
  wifiSettings: WifiSettings | null;
  devices: ConnectedDevice[];
}

export interface DiagnosticsReport {
  analyzedAtIso: string;
  confirmed: DiagnosticItem[];
  possible: DiagnosticItem[];
  unavailable: DiagnosticItem[];
}

export function analyzeNetworkDiagnostics(input: DiagnosticsInput): DiagnosticsReport {
  const confirmed: DiagnosticItem[] = [];
  const possible: DiagnosticItem[] = [];
  const unavailable: DiagnosticItem[] = [];

  // 1. Speed & Latency checks (only if real measurement exists)
  if (!input.latestSpeed) {
    unavailable.push({
      id: 'no-speed-data',
      category: 'unavailable',
      severity: 'info',
      titleKey: 'diag.unavailSpeedTitle',
      evidenceText: '0 tests',
      recommendationKey: 'diag.unavailSpeedRec'
    });
  } else {
    const s = input.latestSpeed;

    if (s.packetLossPct > 2) {
      confirmed.push({
        id: 'packet-loss-high',
        category: 'confirmed',
        severity: 'high',
        titleKey: 'diag.packetLossTitle',
        evidenceText: `${s.packetLossPct}% packet loss`,
        recommendationKey: 'diag.packetLossRec'
      });
    }

    if (s.pingMs > 100) {
      confirmed.push({
        id: 'ping-high',
        category: 'confirmed',
        severity: 'high',
        titleKey: 'diag.highPingTitle',
        evidenceText: `${s.pingMs} ms`,
        recommendationKey: 'diag.highPingRec'
      });
    } else if (s.pingMs > 60 || s.jitterMs > 25) {
      possible.push({
        id: 'latency-jitter',
        category: 'possible',
        severity: 'medium',
        titleKey: 'diag.jitterTitle',
        evidenceText: `Ping ${s.pingMs} ms / Jitter ${s.jitterMs} ms`,
        recommendationKey: 'diag.jitterRec'
      });
    }

    if (s.downloadMbps < 5) {
      confirmed.push({
        id: 'low-download',
        category: 'confirmed',
        severity: 'high',
        titleKey: 'diag.lowDownloadTitle',
        evidenceText: `${s.downloadMbps} Mbps`,
        recommendationKey: 'diag.lowDownloadRec'
      });
    } else if (input.speedHistory.length >= 3) {
      const prevTests = input.speedHistory.filter((item) => item.id !== s.id).slice(0, 5);
      if (prevTests.length > 0) {
        const avgPrev = prevTests.reduce((sum, item) => sum + item.downloadMbps, 0) / prevTests.length;
        if (avgPrev > 10 && s.downloadMbps < avgPrev * 0.5) {
          possible.push({
            id: 'speed-drop-vs-baseline',
            category: 'possible',
            severity: 'medium',
            titleKey: 'diag.speedDropTitle',
            evidenceText: `${s.downloadMbps} Mbps vs ${avgPrev.toFixed(1)} Mbps avg`,
            recommendationKey: 'diag.speedDropRec'
          });
        }
      }
    }
  }

  // 2. Router-derived checks (only if router is connected and exposes the telemetry)
  if (!input.routerConnected || !input.routerInfo) {
    unavailable.push({
      id: 'router-not-connected',
      category: 'unavailable',
      severity: 'info',
      titleKey: 'diag.unavailRouterTitle',
      evidenceText: 'Disconnected',
      recommendationKey: 'diag.unavailRouterRec'
    });
  } else {
    if (input.routerInfo.wanConnected === false) {
      confirmed.push({
        id: 'wan-disconnected',
        category: 'confirmed',
        severity: 'high',
        titleKey: 'diag.wanDownTitle',
        evidenceText: 'WAN status: Disconnected',
        recommendationKey: 'diag.wanDownRec'
      });
    }

    if (input.routerInfo.signalStrengthDbm !== null) {
      if (input.routerInfo.signalStrengthDbm < -75) {
        confirmed.push({
          id: 'weak-signal',
          category: 'confirmed',
          severity: 'high',
          titleKey: 'diag.weakSignalTitle',
          evidenceText: `${input.routerInfo.signalStrengthDbm} dBm`,
          recommendationKey: 'diag.weakSignalRec'
        });
      }
    } else {
      unavailable.push({
        id: 'signal-unavailable',
        category: 'unavailable',
        severity: 'info',
        titleKey: 'diag.unavailSignalTitle',
        evidenceText: 'Not exposed by adapter',
        recommendationKey: 'diag.unavailSignalRec'
      });
    }

    const activeDevices = input.devices.filter((d) => d.status === 'online');
    if (activeDevices.length >= 12) {
      possible.push({
        id: 'many-devices',
        category: 'possible',
        severity: 'medium',
        titleKey: 'diag.manyDevicesTitle',
        evidenceText: `${activeDevices.length} active clients`,
        recommendationKey: 'diag.manyDevicesRec'
      });
    }

    const ch24 = input.wifiSettings?.band24?.channel;
    if (ch24 && ['2', '3', '4', '5', '7', '8', '9', '10'].includes(ch24)) {
      possible.push({
        id: 'overlapping-channel-24',
        category: 'possible',
        severity: 'medium',
        titleKey: 'diag.channelOverlapTitle',
        evidenceText: `2.4GHz Channel ${ch24}`,
        recommendationKey: 'diag.channelOverlapRec'
      });
    }

    if (input.wifiSettings?.band5 && !input.wifiSettings.band5.enabled) {
      possible.push({
        id: 'band5-disabled',
        category: 'possible',
        severity: 'info',
        titleKey: 'diag.band5DisabledTitle',
        evidenceText: '5GHz Disabled',
        recommendationKey: 'diag.band5DisabledRec'
      });
    }
  }

  return {
    analyzedAtIso: new Date().toISOString(),
    confirmed,
    possible,
    unavailable
  };
}
