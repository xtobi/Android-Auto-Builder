import { HttpRequestOptions, HttpResponse, RouterError } from '../router-adapters/types';

export interface NativeAndroidEnv {
  isNativeAndroid: boolean;
  appVersion: string;
  sdkInt: number;
  wifiConnected: boolean;
  ssid: string | null;
  gatewayIp: string | null;
  localIp: string | null;
  networkBound: boolean;
  wifiLinkSpeedMbps: number | null;
  wifiFrequencyMhz: number | null;
  wifiRssiDbm: number | null;
}

export interface NativeProbeResult {
  reachable: boolean;
  status?: number;
  latencyMs: number;
  errorCode?: string;
  detail?: string;
}

interface AndroidNativeJavascriptInterface {
  isNativeAndroid?: () => boolean;
  getEnvironmentJson?: () => string;
  probeGatewayAsync?: (requestId: string, url: string, timeoutMs: number) => void;
  httpRequestAsync?: (requestId: string, payloadJson: string) => void;
  clearSessionCookies?: (sessionId: string) => void;
  openExternalPortal?: (url: string) => boolean;
}

declare global {
  interface Window {
    AdvancedWifiNative?: AndroidNativeJavascriptInterface;
    __awNativeResolve?: (requestId: string, payloadJson: string) => void;
    __awNativeReject?: (requestId: string, errorJson: string) => void;
    __awHandleHardwareBack?: () => boolean;
  }
}

interface PendingCallback {
  resolve: (value: string) => void;
  reject: (reason: Error) => void;
  timer: ReturnType<typeof setTimeout>;
}

const pendingCallbacks = new Map<string, PendingCallback>();

function ensureGlobalCallbackReceivers(): void {
  if (typeof window === 'undefined') return;

  if (!window.__awNativeResolve) {
    window.__awNativeResolve = (requestId: string, payloadJson: string) => {
      const entry = pendingCallbacks.get(requestId);
      if (!entry) return;
      pendingCallbacks.delete(requestId);
      clearTimeout(entry.timer);
      entry.resolve(payloadJson);
    };
  }

  if (!window.__awNativeReject) {
    window.__awNativeReject = (requestId: string, errorJson: string) => {
      const entry = pendingCallbacks.get(requestId);
      if (!entry) return;
      pendingCallbacks.delete(requestId);
      clearTimeout(entry.timer);
      try {
        const parsed = JSON.parse(errorJson) as { code?: string; message?: string };
        entry.reject(new Error(parsed.code || parsed.message || 'NATIVE_BRIDGE_ERROR'));
      } catch {
        entry.reject(new Error(errorJson || 'NATIVE_BRIDGE_ERROR'));
      }
    };
  }
}

function nextRequestId(): string {
  return `aw_nat_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

export function isNativeAndroidApp(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    return window.AdvancedWifiNative?.isNativeAndroid?.() === true;
  } catch {
    return false;
  }
}

export async function getNativeEnvironment(): Promise<NativeAndroidEnv | null> {
  if (!isNativeAndroidApp()) return null;
  try {
    const raw = window.AdvancedWifiNative?.getEnvironmentJson?.();
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<NativeAndroidEnv>;
    return {
      isNativeAndroid: true,
      appVersion: typeof parsed.appVersion === 'string' ? parsed.appVersion : '1.0.0',
      sdkInt: typeof parsed.sdkInt === 'number' ? parsed.sdkInt : 0,
      wifiConnected: Boolean(parsed.wifiConnected),
      ssid: typeof parsed.ssid === 'string' && parsed.ssid.trim() ? parsed.ssid.trim() : null,
      gatewayIp: typeof parsed.gatewayIp === 'string' && parsed.gatewayIp.trim() ? parsed.gatewayIp.trim() : null,
      localIp: typeof parsed.localIp === 'string' && parsed.localIp.trim() ? parsed.localIp.trim() : null,
      networkBound: Boolean(parsed.networkBound),
      wifiLinkSpeedMbps:
        typeof parsed.wifiLinkSpeedMbps === 'number' && parsed.wifiLinkSpeedMbps > 0
          ? parsed.wifiLinkSpeedMbps
          : null,
      wifiFrequencyMhz:
        typeof parsed.wifiFrequencyMhz === 'number' && parsed.wifiFrequencyMhz > 0
          ? parsed.wifiFrequencyMhz
          : null,
      wifiRssiDbm:
        typeof parsed.wifiRssiDbm === 'number' && parsed.wifiRssiDbm < 0
          ? parsed.wifiRssiDbm
          : null
    };
  } catch {
    return null;
  }
}

export async function nativeProbeGateway(url: string, timeoutMs = 3500): Promise<NativeProbeResult> {
  if (!isNativeAndroidApp() || !window.AdvancedWifiNative?.probeGatewayAsync) {
    return {
      reachable: false,
      latencyMs: 0,
      errorCode: 'NATIVE_BRIDGE_UNAVAILABLE',
      detail: 'Android Native Bridge is not present in this runtime.'
    };
  }

  ensureGlobalCallbackReceivers();
  const requestId = nextRequestId();
  const startedAt = Date.now();

  try {
    const raw = await new Promise<string>((resolve, reject) => {
      const timer = setTimeout(() => {
        pendingCallbacks.delete(requestId);
        reject(new Error('ROUTER_OFFLINE'));
      }, timeoutMs + 1500);

      pendingCallbacks.set(requestId, { resolve, reject, timer });
      window.AdvancedWifiNative!.probeGatewayAsync!(requestId, url, timeoutMs);
    });

    const parsed = JSON.parse(raw) as Partial<NativeProbeResult>;
    return {
      reachable: Boolean(parsed.reachable),
      status: typeof parsed.status === 'number' ? parsed.status : undefined,
      latencyMs: typeof parsed.latencyMs === 'number' ? parsed.latencyMs : Math.max(1, Date.now() - startedAt),
      errorCode: typeof parsed.errorCode === 'string' ? parsed.errorCode : undefined,
      detail: typeof parsed.detail === 'string' ? parsed.detail : undefined
    };
  } catch (err) {
    return {
      reachable: false,
      latencyMs: Math.max(1, Date.now() - startedAt),
      errorCode: err instanceof Error ? err.message : 'ROUTER_OFFLINE'
    };
  }
}

export async function nativeHttpRequest(
  sessionId: string,
  baseUrl: string,
  req: HttpRequestOptions
): Promise<HttpResponse> {
  if (!isNativeAndroidApp() || !window.AdvancedWifiNative?.httpRequestAsync) {
    throw new RouterError('NATIVE_BRIDGE_UNAVAILABLE', 'Android Native Bridge unavailable');
  }

  ensureGlobalCallbackReceivers();
  const requestId = nextRequestId();
  const timeoutMs = req.timeoutMs ?? 6500;
  const targetUrl = new URL(req.path, baseUrl).toString();

  const raw = await new Promise<string>((resolve, reject) => {
    const timer = setTimeout(() => {
      pendingCallbacks.delete(requestId);
      reject(new RouterError('ROUTER_OFFLINE', 'Native HTTP bridge timed out'));
    }, timeoutMs + 2000);

    pendingCallbacks.set(requestId, {
      resolve,
      reject: (err) => {
        if (err.message === 'INVALID_ROUTER_ADDRESS') {
          reject(new RouterError('INVALID_ROUTER_ADDRESS', 'Native validator rejected target URL'));
        } else {
          reject(new RouterError('ROUTER_OFFLINE', err.message));
        }
      },
      timer
    });

    const payload = JSON.stringify({
      sessionId,
      url: targetUrl,
      method: req.method,
      headers: req.headers ?? {},
      body: req.body ?? null,
      timeoutMs
    });

    window.AdvancedWifiNative!.httpRequestAsync!(requestId, payload);
  });

  const parsed = JSON.parse(raw) as {
    ok?: boolean;
    status?: number;
    headers?: Record<string, string>;
    body?: string;
    errorCode?: string;
    detail?: string;
  };

  if (!parsed.ok) {
    if (parsed.errorCode === 'INVALID_ROUTER_ADDRESS') {
      throw new RouterError('INVALID_ROUTER_ADDRESS', parsed.detail);
    }
    throw new RouterError('ROUTER_OFFLINE', parsed.detail || parsed.errorCode);
  }

  return {
    status: parsed.status ?? 200,
    headers: parsed.headers ?? {},
    body: parsed.body ?? ''
  };
}

export function nativeClearSession(sessionId: string): void {
  if (!isNativeAndroidApp() || !window.AdvancedWifiNative?.clearSessionCookies) return;
  try {
    window.AdvancedWifiNative.clearSessionCookies(sessionId);
  } catch {
    // Ignore cleanup errors
  }
}

export function nativeOpenExternalPortal(url: string): boolean {
  if (!isNativeAndroidApp() || !window.AdvancedWifiNative?.openExternalPortal) return false;
  try {
    return Boolean(window.AdvancedWifiNative.openExternalPortal(url));
  } catch {
    return false;
  }
}

export function registerHardwareBackHandler(handler: () => boolean): () => void {
  if (typeof window === 'undefined') return () => undefined;
  window.__awHandleHardwareBack = handler;
  return () => {
    if (window.__awHandleHardwareBack === handler) {
      delete window.__awHandleHardwareBack;
    }
  };
}
