/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { AppProvider, useApp } from './context/AppContext';
import { I18nProvider, useI18n } from './i18n';
import { registerHardwareBackHandler } from './native/androidBridge';
import { Account } from './pages/Account';
import { ActivityLog } from './pages/ActivityLog';
import { Dashboard } from './pages/Dashboard';
import { Devices } from './pages/Devices';
import { Diagnostics } from './pages/Diagnostics';
import { FloorPlanSurvey } from './pages/FloorPlanSurvey';
import { LocalConnectorSetup } from './pages/LocalConnectorSetup';
import { Login } from './pages/Login';
import { RouterConnection } from './pages/RouterConnection';
import { SpeedTest } from './pages/SpeedTest';
import { WiFiSettings } from './pages/WiFiSettings';

const MainShell: React.FC = () => {
  const { page, setPage, navigateBack, routerError, clearRouterError, routerSession } = useApp();
  const { t } = useI18n();
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    return registerHardwareBackHandler(() => {
      if (mobileOpen) {
        setMobileOpen(false);
        return true;
      }
      return navigateBack();
    });
  }, [mobileOpen, navigateBack]);

  const renderPage = () => {
    switch (page) {
      case 'dashboard':
        return <Dashboard />;
      case 'floor-plan':
        return <FloorPlanSurvey />;
      case 'wifi-settings':
        return <WiFiSettings />;
      case 'speed-test':
        return <SpeedTest />;
      case 'diagnostics':
        return <Diagnostics />;
      case 'devices':
        return <Devices />;
      case 'activity-log':
        return <ActivityLog />;
      case 'router-connection':
        return <RouterConnection />;
      case 'local-connector':
        return <LocalConnectorSetup />;
      case 'account':
        return <Account />;
      case 'login':
        return <Login />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen flex bg-[#F4F7FB] dark:bg-[#0B1522] text-[#102B49] dark:text-[#EAF1F8]">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:start-3 focus:z-50 focus:px-4 focus:py-2 focus:rounded-xl focus:bg-[#174C78] focus:text-white focus:text-sm"
      >
        {t('app.skipToContent')}
      </a>

      <Sidebar mobileOpen={mobileOpen} onCloseMobile={() => setMobileOpen(false)} />

      <div className="flex-1 flex flex-col min-w-0">
        <Header onOpenMobileMenu={() => setMobileOpen(true)} />
        <main id="main-content" className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-5">
          {routerSession?.transportMode === 'simulation' && (
            <div className="rounded-2xl border border-amber-300 dark:border-amber-800/70 bg-amber-50 dark:bg-amber-950/30 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs text-amber-950 dark:text-amber-200">
              <span>{t('router.simulationActiveBanner')}</span>
              <button
                type="button"
                onClick={() => setPage('router-connection')}
                className="px-3 py-1.5 rounded-lg bg-amber-700 hover:bg-amber-800 text-white font-medium whitespace-nowrap"
              >
                {t('nav.routerConnection')}
              </button>
            </div>
          )}

          {routerError === 'SESSION_EXPIRED' && page !== 'router-connection' && (
            <div className="rounded-2xl border border-red-300 dark:border-red-800/70 bg-red-50 dark:bg-red-950/30 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs text-red-900 dark:text-red-200">
              <span>{t('router.errors.SESSION_EXPIRED')}</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    clearRouterError();
                    setPage('router-connection');
                  }}
                  className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-medium whitespace-nowrap"
                >
                  {t('router.reauthenticateBtn')}
                </button>
              </div>
            </div>
          )}

          {renderPage()}
        </main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <I18nProvider>
        <AppProvider>
          <MainShell />
        </AppProvider>
      </I18nProvider>
    </ErrorBoundary>
  );
}
