export type WallMaterial = 'drywall' | 'brick' | 'concrete';
export type FrequencyBandMode = '2.4GHz' | '5GHz' | 'dual';
export type HomePresetId = 'apartment' | 'single-story' | 'workspace';
export type SignalTier = 'optimal' | 'good' | 'fair' | 'weak';

export interface Point2D {
  /** Normalized X coordinate (0..100 mapped across floorWidthMeters) */
  x: number;
  /** Normalized Y coordinate (0..100 mapped across floorHeightMeters) */
  y: number;
}

export interface RoomZone {
  id: string;
  labelKey: string;
  x: number;
  y: number;
  width: number;
  height: number;
  priority: 'high' | 'standard';
}

export interface WallSegment {
  id: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  material: WallMaterial;
}

export interface HomeFloorplanPreset {
  id: HomePresetId;
  widthMeters: number;
  heightMeters: number;
  defaultRouter: Point2D;
  defaultRepeater: Point2D;
  rooms: RoomZone[];
  walls: WallSegment[];
}

export interface RoomConnectionEvaluation {
  roomId: string;
  labelKey: string;
  center: Point2D;
  distanceMeters: number;
  wallsCrossed: number;
  rssi24Dbm: number;
  rssi5Dbm: number;
  effectiveRssiDbm: number;
  qualityPct: number;
  tier: SignalTier;
  recommendedBand: '5GHz' | '2.4GHz' | 'mesh';
  servedBy: 'router' | 'repeater';
}

export interface HomeSignalMapEvaluation {
  rooms: RoomConnectionEvaluation[];
  bestPoints: RoomConnectionEvaluation[];
  weakPoints: RoomConnectionEvaluation[];
  averageQualityPct: number;
  coverageScorePct: number;
}

export const WALL_ATTENUATION_DB: Record<WallMaterial, { band24: number; band5: number }> = {
  drywall: { band24: 3.0, band5: 4.8 },
  brick: { band24: 7.0, band5: 12.0 },
  concrete: { band24: 11.5, band5: 18.5 }
};

export const HOME_PRESETS: Record<HomePresetId, HomeFloorplanPreset> = {
  apartment: {
    id: 'apartment',
    widthMeters: 12,
    heightMeters: 8,
    defaultRouter: { x: 24, y: 28 },
    defaultRepeater: { x: 74, y: 66 },
    rooms: [
      { id: 'living', labelKey: 'homeMap.rooms.livingRoom', x: 4, y: 6, width: 44, height: 48, priority: 'high' },
      { id: 'kitchen', labelKey: 'homeMap.rooms.kitchen', x: 4, y: 54, width: 44, height: 40, priority: 'standard' },
      { id: 'hallway', labelKey: 'homeMap.rooms.hallway', x: 48, y: 6, width: 16, height: 88, priority: 'standard' },
      { id: 'office', labelKey: 'homeMap.rooms.office', x: 64, y: 6, width: 32, height: 44, priority: 'high' },
      { id: 'bedroom', labelKey: 'homeMap.rooms.bedroom', x: 64, y: 50, width: 32, height: 44, priority: 'standard' }
    ],
    walls: [
      { id: 'w1', x1: 4, y1: 54, x2: 48, y2: 54, material: 'drywall' },
      { id: 'w2', x1: 48, y1: 6, x2: 48, y2: 42, material: 'brick' },
      { id: 'w3', x1: 48, y1: 56, x2: 48, y2: 94, material: 'brick' },
      { id: 'w4', x1: 64, y1: 6, x2: 64, y2: 34, material: 'brick' },
      { id: 'w5', x1: 64, y1: 48, x2: 64, y2: 94, material: 'brick' },
      { id: 'w6', x1: 64, y1: 50, x2: 96, y2: 50, material: 'concrete' }
    ]
  },
  'single-story': {
    id: 'single-story',
    widthMeters: 16,
    heightMeters: 10,
    defaultRouter: { x: 18, y: 26 },
    defaultRepeater: { x: 78, y: 70 },
    rooms: [
      { id: 'living', labelKey: 'homeMap.rooms.livingRoom', x: 4, y: 6, width: 34, height: 46, priority: 'high' },
      { id: 'dining', labelKey: 'homeMap.rooms.dining', x: 4, y: 52, width: 34, height: 42, priority: 'standard' },
      { id: 'office', labelKey: 'homeMap.rooms.office', x: 38, y: 6, width: 28, height: 46, priority: 'high' },
      { id: 'hallway', labelKey: 'homeMap.rooms.hallway', x: 38, y: 52, width: 28, height: 42, priority: 'standard' },
      { id: 'bedroom1', labelKey: 'homeMap.rooms.masterBedroom', x: 66, y: 6, width: 30, height: 46, priority: 'high' },
      { id: 'bedroom2', labelKey: 'homeMap.rooms.guestBedroom', x: 66, y: 52, width: 30, height: 42, priority: 'standard' }
    ],
    walls: [
      { id: 's1', x1: 4, y1: 52, x2: 38, y2: 52, material: 'drywall' },
      { id: 's2', x1: 38, y1: 6, x2: 38, y2: 40, material: 'brick' },
      { id: 's3', x1: 38, y1: 64, x2: 38, y2: 94, material: 'brick' },
      { id: 's4', x1: 38, y1: 52, x2: 66, y2: 52, material: 'drywall' },
      { id: 's5', x1: 66, y1: 6, x2: 66, y2: 42, material: 'concrete' },
      { id: 's6', x1: 66, y1: 58, x2: 66, y2: 94, material: 'concrete' },
      { id: 's7', x1: 66, y1: 52, x2: 96, y2: 52, material: 'brick' }
    ]
  },
  workspace: {
    id: 'workspace',
    widthMeters: 14,
    heightMeters: 9,
    defaultRouter: { x: 50, y: 24 },
    defaultRepeater: { x: 82, y: 74 },
    rooms: [
      { id: 'reception', labelKey: 'homeMap.rooms.lounge', x: 4, y: 6, width: 30, height: 88, priority: 'standard' },
      { id: 'studio', labelKey: 'homeMap.rooms.office', x: 34, y: 6, width: 34, height: 48, priority: 'high' },
      { id: 'meeting', labelKey: 'homeMap.rooms.meetingRoom', x: 34, y: 54, width: 34, height: 40, priority: 'high' },
      { id: 'server', labelKey: 'homeMap.rooms.bedroom', x: 68, y: 6, width: 28, height: 48, priority: 'standard' },
      { id: 'patio', labelKey: 'homeMap.rooms.patio', x: 68, y: 54, width: 28, height: 40, priority: 'standard' }
    ],
    walls: [
      { id: 'o1', x1: 34, y1: 6, x2: 34, y2: 38, material: 'brick' },
      { id: 'o2', x1: 34, y1: 58, x2: 34, y2: 94, material: 'brick' },
      { id: 'o3', x1: 34, y1: 54, x2: 68, y2: 54, material: 'drywall' },
      { id: 'o4', x1: 68, y1: 6, x2: 68, y2: 40, material: 'concrete' },
      { id: 'o5', x1: 68, y1: 58, x2: 68, y2: 94, material: 'concrete' },
      { id: 'o6', x1: 68, y1: 54, x2: 96, y2: 54, material: 'brick' }
    ]
  }
};

function crossProduct(a: Point2D, b: Point2D, c: Point2D): number {
  return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
}

function onSegment(a: Point2D, b: Point2D, c: Point2D): boolean {
  return (
    Math.min(a.x, b.x) <= c.x + 1e-6 &&
    c.x <= Math.max(a.x, b.x) + 1e-6 &&
    Math.min(a.y, b.y) <= c.y + 1e-6 &&
    c.y <= Math.max(a.y, b.y) + 1e-6
  );
}

export function segmentsIntersect(p1: Point2D, p2: Point2D, q1: Point2D, q2: Point2D): boolean {
  const d1 = crossProduct(q1, q2, p1);
  const d2 = crossProduct(q1, q2, p2);
  const d3 = crossProduct(p1, p2, q1);
  const d4 = crossProduct(p1, p2, q2);

  if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))) {
    return true;
  }
  if (Math.abs(d1) < 1e-6 && onSegment(q1, q2, p1)) return true;
  if (Math.abs(d2) < 1e-6 && onSegment(q1, q2, p2)) return true;
  if (Math.abs(d3) < 1e-6 && onSegment(p1, p2, q1)) return true;
  if (Math.abs(d4) < 1e-6 && onSegment(p1, p2, q2)) return true;
  return false;
}

export function distanceMetersBetween(
  a: Point2D,
  b: Point2D,
  widthMeters: number,
  heightMeters: number
): number {
  const dx = ((b.x - a.x) / 100) * widthMeters;
  const dy = ((b.y - a.y) / 100) * heightMeters;
  return Math.max(0.6, Math.hypot(dx, dy));
}

export function computePointRssi(params: {
  source: Point2D;
  target: Point2D;
  preset: HomeFloorplanPreset;
  band: '2.4GHz' | '5GHz';
  wallMaterialOverride?: WallMaterial | 'preset';
  txOffsetDb?: number;
}): { rssiDbm: number; wallsCrossed: number; distanceMeters: number } {
  const { source, target, preset, band, wallMaterialOverride = 'preset', txOffsetDb = 0 } = params;
  const d = distanceMetersBetween(source, target, preset.widthMeters, preset.heightMeters);
  const freqMhz = band === '5GHz' ? 5180 : 2437;
  // Free-space path loss in dB
  const fspl = 20 * Math.log10(d) + 20 * Math.log10(freqMhz) - 27.55;

  let wallsCrossed = 0;
  let wallLossDb = 0;
  for (const wall of preset.walls) {
    if (segmentsIntersect(source, target, { x: wall.x1, y: wall.y1 }, { x: wall.x2, y: wall.y2 })) {
      wallsCrossed += 1;
      const mat = wallMaterialOverride === 'preset' ? wall.material : wallMaterialOverride;
      wallLossDb += band === '5GHz' ? WALL_ATTENUATION_DB[mat].band5 : WALL_ATTENUATION_DB[mat].band24;
    }
  }

  // Realistic consumer router EIRP (~20 dBm) minus receiver/antenna baseline (~18 dB) => 2 dBm baseline at 1m pre-FSPL
  const baselineDbm = (band === '5GHz' ? 4 : 2) + txOffsetDb;
  const rawRssi = baselineDbm - fspl - wallLossDb;
  const rssiDbm = Math.round(Math.max(-96, Math.min(-26, rawRssi)));
  return { rssiDbm, wallsCrossed, distanceMeters: Number(d.toFixed(1)) };
}

export function rssiToQualityPct(rssiDbm: number): number {
  if (rssiDbm >= -45) return 100;
  if (rssiDbm <= -90) return 5;
  return Math.round(((rssiDbm + 90) / 45) * 95 + 5);
}

export function classifySignalTier(rssiDbm: number): SignalTier {
  if (rssiDbm >= -56) return 'optimal';
  if (rssiDbm >= -67) return 'good';
  if (rssiDbm >= -76) return 'fair';
  return 'weak';
}

export function evaluateHomeSignalMap(params: {
  preset: HomeFloorplanPreset;
  routerPos: Point2D;
  bandMode: FrequencyBandMode;
  wallMaterialOverride?: WallMaterial | 'preset';
  repeaterEnabled?: boolean;
  repeaterPos?: Point2D;
  txOffsetDb?: number;
}): HomeSignalMapEvaluation {
  const {
    preset,
    routerPos,
    bandMode,
    wallMaterialOverride = 'preset',
    repeaterEnabled = false,
    repeaterPos = preset.defaultRepeater,
    txOffsetDb = 0
  } = params;

  // Repeater link penalty based on router -> repeater backhaul attenuation (realistic wireless mesh loss)
  const repeaterBackhaul = repeaterEnabled
    ? computePointRssi({
        source: routerPos,
        target: repeaterPos,
        preset,
        band: '5GHz',
        wallMaterialOverride,
        txOffsetDb
      })
    : null;
  const repeaterBackhaulPenaltyDb = repeaterBackhaul
    ? repeaterBackhaul.rssiDbm < -75
      ? 10
      : repeaterBackhaul.rssiDbm < -65
      ? 5
      : 2
    : 0;

  const rooms: RoomConnectionEvaluation[] = preset.rooms.map((room) => {
    const center: Point2D = {
      x: room.x + room.width / 2,
      y: room.y + room.height / 2
    };

    const r24 = computePointRssi({
      source: routerPos,
      target: center,
      preset,
      band: '2.4GHz',
      wallMaterialOverride,
      txOffsetDb
    });
    const r5 = computePointRssi({
      source: routerPos,
      target: center,
      preset,
      band: '5GHz',
      wallMaterialOverride,
      txOffsetDb
    });

    let best24 = r24.rssiDbm;
    let best5 = r5.rssiDbm;
    let wallsCrossed = r24.wallsCrossed;
    let distanceMeters = r24.distanceMeters;
    let servedBy: 'router' | 'repeater' = 'router';

    if (repeaterEnabled) {
      const rep24 = computePointRssi({
        source: repeaterPos,
        target: center,
        preset,
        band: '2.4GHz',
        wallMaterialOverride,
        txOffsetDb: txOffsetDb - repeaterBackhaulPenaltyDb
      });
      const rep5 = computePointRssi({
        source: repeaterPos,
        target: center,
        preset,
        band: '5GHz',
        wallMaterialOverride,
        txOffsetDb: txOffsetDb - repeaterBackhaulPenaltyDb
      });
      const routerPeak = bandMode === '5GHz' ? r5.rssiDbm : bandMode === '2.4GHz' ? r24.rssiDbm : Math.max(r24.rssiDbm, r5.rssiDbm);
      const repPeak = bandMode === '5GHz' ? rep5.rssiDbm : bandMode === '2.4GHz' ? rep24.rssiDbm : Math.max(rep24.rssiDbm, rep5.rssiDbm);
      if (repPeak > routerPeak + 2) {
        servedBy = 'repeater';
        best24 = rep24.rssiDbm;
        best5 = rep5.rssiDbm;
        wallsCrossed = rep24.wallsCrossed;
        distanceMeters = rep24.distanceMeters;
      }
    }

    const effectiveRssiDbm =
      bandMode === '5GHz' ? best5 : bandMode === '2.4GHz' ? best24 : best5 >= -67 ? best5 : Math.max(best24, best5);
    const qualityPct = rssiToQualityPct(effectiveRssiDbm);
    const tier = classifySignalTier(effectiveRssiDbm);
    const recommendedBand: '5GHz' | '2.4GHz' | 'mesh' =
      best5 >= -67 ? '5GHz' : best24 >= -76 ? '2.4GHz' : 'mesh';

    return {
      roomId: room.id,
      labelKey: room.labelKey,
      center,
      distanceMeters,
      wallsCrossed,
      rssi24Dbm: best24,
      rssi5Dbm: best5,
      effectiveRssiDbm,
      qualityPct,
      tier,
      recommendedBand,
      servedBy
    };
  });

  const sorted = [...rooms].sort((a, b) => b.effectiveRssiDbm - a.effectiveRssiDbm);
  const bestPoints = sorted.slice(0, 2);
  const weakPoints = sorted.filter((r) => r.tier === 'fair' || r.tier === 'weak').reverse();
  const averageQualityPct = Math.round(rooms.reduce((acc, r) => acc + r.qualityPct, 0) / Math.max(1, rooms.length));
  const coveredRooms = rooms.filter((r) => r.tier === 'optimal' || r.tier === 'good').length;
  const coverageScorePct = Math.round((coveredRooms / Math.max(1, rooms.length)) * 100);

  return {
    rooms,
    bestPoints,
    weakPoints,
    averageQualityPct,
    coverageScorePct
  };
}

export function findOptimalRouterPlacement(params: {
  preset: HomeFloorplanPreset;
  bandMode: FrequencyBandMode;
  wallMaterialOverride?: WallMaterial | 'preset';
  txOffsetDb?: number;
}): Point2D {
  const { preset, bandMode, wallMaterialOverride = 'preset', txOffsetDb = 0 } = params;
  let bestPoint = preset.defaultRouter;
  let bestScore = -Infinity;

  for (let x = 10; x <= 90; x += 8) {
    for (let y = 12; y <= 88; y += 8) {
      const candidate = { x, y };
      const evaluation = evaluateHomeSignalMap({
        preset,
        routerPos: candidate,
        bandMode,
        wallMaterialOverride,
        repeaterEnabled: false,
        txOffsetDb
      });
      const minRssi = Math.min(...evaluation.rooms.map((r) => r.effectiveRssiDbm));
      const priorityBonus = evaluation.rooms.reduce((acc, r, idx) => {
        const weight = preset.rooms[idx]?.priority === 'high' ? 1.25 : 1;
        return acc + r.qualityPct * weight;
      }, 0);
      // Favor raising the worst room floor first, then weighted average coverage
      const score = minRssi * 4 + priorityBonus;
      if (score > bestScore) {
        bestScore = score;
        bestPoint = candidate;
      }
    }
  }

  return bestPoint;
}
