import test from 'node:test';
import assert from 'node:assert/strict';
import {
  computePointRssi,
  evaluateHomeSignalMap,
  findOptimalRouterPlacement,
  HOME_PRESETS,
  segmentsIntersect
} from './homeSignalMap';

test('segmentsIntersect detects crossing vs non-crossing segments', () => {
  assert.equal(
    segmentsIntersect({ x: 0, y: 50 }, { x: 100, y: 50 }, { x: 50, y: 0 }, { x: 50, y: 100 }),
    true
  );
  assert.equal(
    segmentsIntersect({ x: 0, y: 10 }, { x: 100, y: 10 }, { x: 50, y: 20 }, { x: 50, y: 100 }),
    false
  );
});

test('5GHz attenuates more strongly than 2.4GHz across concrete/brick walls', () => {
  const preset = HOME_PRESETS.apartment;
  const source = { x: 20, y: 20 };
  const target = { x: 82, y: 22 };

  const r24 = computePointRssi({ source, target, preset, band: '2.4GHz' });
  const r5 = computePointRssi({ source, target, preset, band: '5GHz' });

  assert.ok(r24.wallsCrossed >= 2);
  assert.ok(r24.rssiDbm > r5.rssiDbm);
});

test('findOptimalRouterPlacement improves worst-room coverage over corner placement', () => {
  const preset = HOME_PRESETS['single-story'];
  const cornerEval = evaluateHomeSignalMap({
    preset,
    routerPos: { x: 8, y: 10 },
    bandMode: 'dual'
  });

  const optimalPos = findOptimalRouterPlacement({
    preset,
    bandMode: 'dual'
  });
  const optimalEval = evaluateHomeSignalMap({
    preset,
    routerPos: optimalPos,
    bandMode: 'dual'
  });

  const cornerMin = Math.min(...cornerEval.rooms.map((r) => r.effectiveRssiDbm));
  const optimalMin = Math.min(...optimalEval.rooms.map((r) => r.effectiveRssiDbm));

  assert.ok(optimalMin >= cornerMin);
  assert.ok(optimalEval.averageQualityPct >= cornerEval.averageQualityPct);
});

test('enabling mesh repeater improves coverage in far rooms', () => {
  const preset = HOME_PRESETS['single-story'];
  const withoutRepeater = evaluateHomeSignalMap({
    preset,
    routerPos: { x: 12, y: 20 },
    bandMode: '5GHz',
    repeaterEnabled: false
  });
  const withRepeater = evaluateHomeSignalMap({
    preset,
    routerPos: { x: 12, y: 20 },
    bandMode: '5GHz',
    repeaterEnabled: true,
    repeaterPos: { x: 76, y: 70 }
  });

  assert.ok(withRepeater.averageQualityPct > withoutRepeater.averageQualityPct);
  assert.ok(withRepeater.rooms.some((r) => r.servedBy === 'repeater'));
});
