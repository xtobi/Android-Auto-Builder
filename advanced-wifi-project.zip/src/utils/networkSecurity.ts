export interface ValidatedRouterAddress {
  valid: boolean;
  normalizedUrl: string;
  host: string;
  protocol: 'http:' | 'https:';
  reason?: string;
}

const KNOWN_ROUTER_HOSTNAMES = new Set([
  'tplinkwifi.net',
  'tplinklogin.net',
  'mwlogin.net',
  'router.asus.com',
  'www.routerlogin.net',
  'routerlogin.net',
  'tendawifi.com',
  'dlinkrouter.local',
  'fritz.box',
  'myrouter.local',
  'huawei.local'
]);

export function isPrivateLanIpv4(ip: string): boolean {
  const parts = ip.split('.');
  if (parts.length !== 4) return false;
  const nums = parts.map((p) => (/^\d{1,3}$/.test(p) ? Number(p) : -1));
  if (nums.some((n) => n < 0 || n > 255)) return false;

  const [a, b] = nums;
  // 10.0.0.0/8
  if (a === 10) return true;
  // 172.16.0.0/12
  if (a === 172 && b >= 16 && b <= 31) return true;
  // 192.168.0.0/16
  if (a === 192 && b === 168) return true;
  return false;
}

export function validateRouterAddress(rawInput: string): ValidatedRouterAddress {
  const trimmed = rawInput.trim();
  if (!trimmed) {
    return { valid: false, normalizedUrl: '', host: '', protocol: 'http:', reason: 'empty' };
  }

  const withScheme = /^https?:\/\//i.test(trimmed) ? trimmed : `http://${trimmed}`;
  let parsed: URL;
  try {
    parsed = new URL(withScheme);
  } catch {
    return { valid: false, normalizedUrl: '', host: '', protocol: 'http:', reason: 'malformed_url' };
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return { valid: false, normalizedUrl: '', host: '', protocol: 'http:', reason: 'invalid_scheme' };
  }

  // Block credentials embedded in URL (user:pass@host)
  if (parsed.username || parsed.password) {
    return { valid: false, normalizedUrl: '', host: '', protocol: 'http:', reason: 'embedded_credentials' };
  }

  const hostname = parsed.hostname.toLowerCase();

  // Strictly block loopback, link-local / cloud metadata, and unspecified addresses
  if (
    hostname === 'localhost' ||
    hostname.startsWith('127.') ||
    hostname.startsWith('169.254.') ||
    hostname === '0.0.0.0' ||
    hostname === '::1' ||
    hostname === '[::1]' ||
    hostname.startsWith('fe80:') ||
    hostname.startsWith('[fe80:')
  ) {
    return { valid: false, normalizedUrl: '', host: hostname, protocol: parsed.protocol, reason: 'blocked_internal_target' };
  }

  const isPrivateIp = isPrivateLanIpv4(hostname);
  const isAllowedRouterDomain = KNOWN_ROUTER_HOSTNAMES.has(hostname) || hostname.endsWith('.local');

  if (!isPrivateIp && !isAllowedRouterDomain) {
    return { valid: false, normalizedUrl: '', host: hostname, protocol: parsed.protocol, reason: 'non_lan_target' };
  }

  const portSegment = parsed.port ? `:${parsed.port}` : '';
  return {
    valid: true,
    normalizedUrl: `${parsed.protocol}//${hostname}${portSegment}`,
    host: hostname,
    protocol: parsed.protocol,
  };
}

export function normalizeMac(mac: string): string {
  const cleaned = mac.trim().replace(/-/g, ':').toUpperCase();
  return cleaned;
}

export function isValidMacAddress(mac: string): boolean {
  return /^([0-9A-F]{2}:){5}[0-9A-F]{2}$/.test(normalizeMac(mac));
}

export function macToDocId(mac: string): string {
  return normalizeMac(mac).replace(/:/g, '_');
}

const OUI_VENDORS: Record<string, string> = {
  '00:1A:2B': 'Cisco / Linksys',
  '00:E0:4C': 'Realtek Semiconductor',
  '00:17:88': 'Philips',
  '04:D9:F5': 'ASUS',
  '08:00:27': 'Oracle VirtualBox',
  '10:C6:1F': 'Huawei Technologies',
  '14:CC:20': 'TP-Link Technologies',
  '18:FE:34': 'Espressif (IoT)',
  '24:0A:C4': 'Espressif (IoT)',
  '28:6C:07': 'Xiaomi Communications',
  '34:CE:00': 'Xiaomi Communications',
  '3C:5A:B4': 'Google',
  '40:B0:76': 'ASUS',
  '48:57:02': 'Huawei Technologies',
  '50:C7:BF': 'TP-Link Technologies',
  '54:60:09': 'Google',
  '60:38:E0': 'Belkin / Linksys',
  '64:16:66': 'Nest Labs',
  '70:4D:7B': 'ASUSTek Computer',
  '74:DA:38': 'Edimax Technology',
  '7C:2F:80': 'Gigaset',
  '80:2A:A8': 'Ubiquiti Networks',
  '84:D8:1B': 'TP-Link Technologies',
  '88:71:B1': 'ARRIS / CommScope',
  '90:9A:4A': 'TP-Link Technologies',
  '98:DA:C4': 'TP-Link Technologies',
  'A4:83:E7': 'Apple',
  'AC:BC:32': 'Apple',
  'B0:BE:76': 'TP-Link Technologies',
  'B8:27:EB': 'Raspberry Pi',
  'C0:25:E9': 'TP-Link Technologies',
  'C8:3A:35': 'Tenda Technology',
  'CC:2D:E0': 'Huawei Technologies',
  'D4:6E:0E': 'TP-Link Technologies',
  'D8:0D:17': 'TP-Link Technologies',
  'DC:A6:32': 'Raspberry Pi',
  'E0:B9:A5': 'Huawei Technologies',
  'E4:F0:42': 'Google',
  'EC:08:6B': 'TP-Link Technologies',
  'F0:9F:C2': 'Ubiquiti Networks',
  'F4:F5:D8': 'Google',
  'FC:EC:DA': 'Ubiquiti Networks'
};

export function lookupMacVendor(mac: string): string | null {
  const norm = normalizeMac(mac);
  if (!isValidMacAddress(norm)) return null;
  const prefix = norm.slice(0, 8);
  return OUI_VENDORS[prefix] ?? null;
}

export function validateSsid(ssid: string): boolean {
  const byteLength = new TextEncoder().encode(ssid).length;
  return ssid.trim().length >= 1 && byteLength <= 32;
}

export function validateWifiPassword(password: string, encryption: string): boolean {
  if (encryption === 'OPEN' || encryption === 'NONE') return true;
  return password.length >= 8 && password.length <= 63;
}

export function sanitizeDiagnosticText(input: string, secrets: string[] = []): string {
  let out = input;
  for (const secret of secrets) {
    if (secret && secret.length >= 2) {
      out = out.split(secret).join('[REDACTED]');
    }
  }
  return out.slice(0, 400);
}
