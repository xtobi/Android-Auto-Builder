import { WifiBandTag } from '../services/networkSignalInfo';
import { Point2D, WallMaterial } from './homeSignalMap';

export type RoomCategory =
  | 'living'
  | 'bedroom'
  | 'kitchen'
  | 'bathroom'
  | 'corridor'
  | 'office'
  | 'custom';

export type FloorLayoutTemplate = 'grid' | 'corridor' | 'l-shape' | 'open-suite' | 'custom-sketch';

export type HeatmapMetric = 'download' | 'upload' | 'ping' | 'jitter' | 'signal';
export type HeatmapTier = 'strong' | 'moderate' | 'weak' | 'unmeasured';
export type RouterScenarioId = 'original' | 'alt-a' | 'alt-b';

export const MIN_ROOM_M = 2.0;
export const MAX_ROOM_M = 10.0;
export const DEFAULT_ROOM_W_M = 4.0;
export const DEFAULT_ROOM_H_M = 3.5;
export const WALL_GAP_M = 0.2;
export const CORRIDOR_GAP_M = 1.6;
export const FLOOR_MARGIN_M = 1.2;
export const MAX_FLOOR_SPAN_M = 28.0;

export interface FloorRoom {
  id: string;
  name: string;
  category: RoomCategory;
  /** Metric (meters) adaptive coordinates within floor canvas; origin fixed during resize */
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface FloorSegment {
  id: string;
  kind: 'wall' | 'door';
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  material: WallMaterial;
  userDrawn?: boolean;
}

export interface FloorPlan {
  id: string;
  index: number;
  name: string;
  layoutTemplate: FloorLayoutTemplate;
  includeCorridor: boolean;
  /** Total SVG canvas width in meters (adaptive to rooms) */
  canvasWidth: number;
  /** Total SVG canvas height in meters (adaptive to rooms) */
  canvasHeight: number;
  /** Inner occupied width/height in meters for display & coverage scale */
  widthMeters: number;
  heightMeters: number;
  rooms: FloorRoom[];
  segments: FloorSegment[];
}

export interface RouterPlacement {
  floorId: string;
  /** Position in floor meters */
  x: number;
  y: number;
  showApproxCoverage: boolean;
}

export interface RouterScenario {
  id: RouterScenarioId;
  routerPlacement: RouterPlacement;
}

export interface RoomMeasurementRecord {
  id: string;
  scenarioId: RouterScenarioId;
  floorId: string;
  floorName: string;
  roomId: string;
  roomName: string;
  measuredAtIso: string;
  serverName: string;
  downloadMbps: number;
  uploadMbps: number;
  pingMs: number;
  jitterMs: number;
  packetLossPct: number;
  bandUsed: WifiBandTag;
  /** Separate from internet speed: only populated when real RSSI dBm is accessible */
  signalStrengthDbm: number | null;
  connectionSummary: string;
  totalBytesTransferred?: number;
  durationSec?: number;
}

export interface HomeSurveyProject {
  version: 2;
  updatedAtIso: string;
  floors: FloorPlan[];
  activeFloorId: string;
  activeScenarioId: RouterScenarioId;
  scenarios: Record<RouterScenarioId, RouterScenario>;
  measurements: RoomMeasurementRecord[];
}

export interface FloorLayoutHistory {
  past: FloorPlan[][];
  present: FloorPlan[];
  future: FloorPlan[][];
}

export type ResizeBlockedReason =
  | 'none'
  | 'blocked_by_neighbor'
  | 'min_limit'
  | 'max_limit'
  | 'floor_limit';

export interface RoomResizeResult {
  floor: FloorPlan;
  room: FloorRoom;
  appliedWidth: number;
  appliedHeight: number;
  clampedWidth: boolean;
  clampedHeight: boolean;
  reason: ResizeBlockedReason;
  blockingRoomName?: string;
}

export function round1(val: number): number {
  return Math.round(val * 10) / 10;
}

export function clampCoord(val: number, min = FLOOR_MARGIN_M, max = MAX_FLOOR_SPAN_M): number {
  return round1(Math.max(min, Math.min(max, val)));
}

export function snapCoord(val: number, gridStep = 0.2): number {
  return round1(Math.round(val / gridStep) * gridStep);
}

export function verifyNoRoomOverlaps(rooms: FloorRoom[], minGap = WALL_GAP_M - 0.02): boolean {
  for (let i = 0; i < rooms.length; i++) {
    const a = rooms[i];
    for (let j = i + 1; j < rooms.length; j++) {
      const b = rooms[j];
      const overlapsX = a.x < b.x + b.width + minGap && a.x + a.width + minGap > b.x;
      const overlapsY = a.y < b.y + b.height + minGap && a.y + a.height + minGap > b.y;
      if (overlapsX && overlapsY) {
        return false;
      }
    }
  }
  return true;
}

const DEFAULT_ROOM_SPECS: Array<{
  category: RoomCategory;
  defaultName: string;
  w: number;
  h: number;
}> = [
  { category: 'living', defaultName: 'Living Room', w: 4.8, h: 3.8 },
  { category: 'kitchen', defaultName: 'Kitchen', w: 3.8, h: 3.5 },
  { category: 'bedroom', defaultName: 'Master Bedroom', w: 4.4, h: 3.6 },
  { category: 'office', defaultName: 'Home Office', w: 3.6, h: 3.4 },
  { category: 'bathroom', defaultName: 'Bathroom', w: 2.8, h: 2.8 },
  { category: 'bedroom', defaultName: 'Bedroom 2', w: 3.8, h: 3.4 },
  { category: 'corridor', defaultName: 'Corridor', w: 3.6, h: 2.4 },
  { category: 'custom', defaultName: 'Room 8', w: 3.8, h: 3.4 }
];

function computeOccupiedBounds(rooms: FloorRoom[]): {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
} {
  if (rooms.length === 0) {
    return {
      minX: FLOOR_MARGIN_M,
      minY: FLOOR_MARGIN_M,
      maxX: FLOOR_MARGIN_M + DEFAULT_ROOM_W_M,
      maxY: FLOOR_MARGIN_M + DEFAULT_ROOM_H_M
    };
  }
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const r of rooms) {
    minX = Math.min(minX, r.x);
    minY = Math.min(minY, r.y);
    maxX = Math.max(maxX, r.x + r.width);
    maxY = Math.max(maxY, r.y + r.height);
  }
  return {
    minX: round1(minX),
    minY: round1(minY),
    maxX: round1(maxX),
    maxY: round1(maxY)
  };
}

export function generateFloorWallsFromRooms(
  floorId: string,
  rooms: FloorRoom[],
  existingUserSegments: FloorSegment[] = []
): FloorSegment[] {
  const { minX, minY, maxX, maxY } = computeOccupiedBounds(rooms);
  const pad = round1(WALL_GAP_M * 0.5);
  const left = round1(minX - pad);
  const top = round1(minY - pad);
  const right = round1(maxX + pad);
  const bottom = round1(maxY + pad);

  const segments: FloorSegment[] = [
    { id: `${floorId}_ext_top`, kind: 'wall', x1: left, y1: top, x2: right, y2: top, material: 'concrete' },
    { id: `${floorId}_ext_bottom`, kind: 'wall', x1: left, y1: bottom, x2: right, y2: bottom, material: 'concrete' },
    { id: `${floorId}_ext_left`, kind: 'wall', x1: left, y1: top, x2: left, y2: bottom, material: 'concrete' },
    { id: `${floorId}_ext_right`, kind: 'wall', x1: right, y1: top, x2: right, y2: bottom, material: 'concrete' }
  ];

  // Add subtle interior divider walls + centered doorways on edges away from outer boundary
  const seenKeys = new Set<string>();
  rooms.forEach((r, idx) => {
    const wallX = round1(r.x + r.width + pad);
    const wallY = round1(r.y + r.height + pad);

    if (wallX < right - 0.15) {
      const k = `v_${wallX}_${round1(r.y)}_${round1(r.y + r.height)}`;
      if (!seenKeys.has(k)) {
        seenKeys.add(k);
        const yStart = round1(r.y);
        const yEnd = round1(r.y + r.height);
        const midY = round1((yStart + yEnd) / 2);
        const doorHalf = Math.min(0.45, round1((yEnd - yStart) * 0.18));
        segments.push({
          id: `${floorId}_w_v_${idx}_a`,
          kind: 'wall',
          x1: wallX,
          y1: yStart,
          x2: wallX,
          y2: round1(midY - doorHalf),
          material: 'brick'
        });
        segments.push({
          id: `${floorId}_door_v_${idx}`,
          kind: 'door',
          x1: wallX,
          y1: round1(midY - doorHalf),
          x2: wallX,
          y2: round1(midY + doorHalf),
          material: 'drywall'
        });
        segments.push({
          id: `${floorId}_w_v_${idx}_b`,
          kind: 'wall',
          x1: wallX,
          y1: round1(midY + doorHalf),
          x2: wallX,
          y2: yEnd,
          material: 'brick'
        });
      }
    }

    if (wallY < bottom - 0.15) {
      const k = `h_${wallY}_${round1(r.x)}_${round1(r.x + r.width)}`;
      if (!seenKeys.has(k)) {
        seenKeys.add(k);
        const xStart = round1(r.x);
        const xEnd = round1(r.x + r.width);
        const midX = round1((xStart + xEnd) / 2);
        const doorHalf = Math.min(0.45, round1((xEnd - xStart) * 0.18));
        segments.push({
          id: `${floorId}_w_h_${idx}_a`,
          kind: 'wall',
          x1: xStart,
          y1: wallY,
          x2: round1(midX - doorHalf),
          y2: wallY,
          material: 'drywall'
        });
        segments.push({
          id: `${floorId}_door_h_${idx}`,
          kind: 'door',
          x1: round1(midX - doorHalf),
          y1: wallY,
          x2: round1(midX + doorHalf),
          y2: wallY,
          material: 'drywall'
        });
        segments.push({
          id: `${floorId}_w_h_${idx}_b`,
          kind: 'wall',
          x1: round1(midX + doorHalf),
          y1: wallY,
          x2: xEnd,
          y2: wallY,
          material: 'drywall'
        });
      }
    }
  });

  // Preserve custom user-drawn segments safely bounded within the adaptive floor
  const maxW = right + FLOOR_MARGIN_M;
  const maxH = bottom + FLOOR_MARGIN_M;
  for (const seg of existingUserSegments) {
    if (!seg.userDrawn) continue;
    segments.push({
      ...seg,
      x1: clampCoord(seg.x1, 0.2, maxW - 0.2),
      y1: clampCoord(seg.y1, 0.2, maxH - 0.2),
      x2: clampCoord(seg.x2, 0.2, maxW - 0.2),
      y2: clampCoord(seg.y2, 0.2, maxH - 0.2)
    });
  }

  return segments;
}

/**
 * Recomputes adaptive canvas bounds and walls WITHOUT modifying any room's (x, y, width, height).
 */
export function updateFloorBoundsAndWalls(floor: FloorPlan): FloorPlan {
  const { minX, minY, maxX, maxY } = computeOccupiedBounds(floor.rooms);
  const canvasWidth = round1(Math.max(minX + DEFAULT_ROOM_W_M + FLOOR_MARGIN_M, maxX + FLOOR_MARGIN_M));
  const canvasHeight = round1(Math.max(minY + DEFAULT_ROOM_H_M + FLOOR_MARGIN_M, maxY + FLOOR_MARGIN_M));
  const userSegments = floor.segments.filter((s) => s.userDrawn);
  const segments = generateFloorWallsFromRooms(floor.id, floor.rooms, userSegments);
  return {
    ...floor,
    canvasWidth,
    canvasHeight,
    widthMeters: round1(Math.max(2, maxX - minX)),
    heightMeters: round1(Math.max(2, maxY - minY)),
    segments
  };
}

function alignNearbyValues(values: number[], threshold = 0.5): Map<number, number> {
  const sorted = [...values].sort((a, b) => a - b);
  const map = new Map<number, number>();
  if (sorted.length === 0) return map;

  let cluster: number[] = [sorted[0]];
  const flush = () => {
    const anchor = round1(cluster[0]);
    for (const v of cluster) {
      map.set(v, anchor);
    }
  };

  for (let i = 1; i < sorted.length; i++) {
    if (sorted[i] - cluster[0] <= threshold) {
      cluster.push(sorted[i]);
    } else {
      flush();
      cluster = [sorted[i]];
    }
  }
  flush();
  return map;
}

/**
 * Topology-preserving automatic organizer for user-sketched custom floor plans.
 * Preserves relative Left/Right/Top/Bottom spatial layout and wing shapes while snapping edges
 * cleanly and eliminating every room overlap or leading empty space.
 */
export function packCustomTopologyRooms(rooms: FloorRoom[]): FloorRoom[] {
  if (rooms.length === 0) return [];

  const sanitized: FloorRoom[] = rooms.map((r) => ({
    ...r,
    name: r.name.trim().slice(0, 48) || r.category,
    x: round1(Math.max(FLOOR_MARGIN_M, r.x || FLOOR_MARGIN_M)),
    y: round1(Math.max(FLOOR_MARGIN_M, r.y || FLOOR_MARGIN_M)),
    width: round1(Math.max(MIN_ROOM_M, Math.min(MAX_ROOM_M, r.width || DEFAULT_ROOM_W_M))),
    height: round1(Math.max(MIN_ROOM_M, Math.min(MAX_ROOM_M, r.height || DEFAULT_ROOM_H_M)))
  }));

  // Snap nearly-aligned left/top edges for clean architectural lines without scrambling wings
  const xMap = alignNearbyValues(sanitized.map((r) => r.x), 0.5);
  const yMap = alignNearbyValues(sanitized.map((r) => r.y), 0.5);

  const work: FloorRoom[] = sanitized.map((r) => ({
    ...r,
    x: xMap.get(r.x) ?? r.x,
    y: yMap.get(r.y) ?? r.y
  }));

  // Sort deterministically by visual reading order (top-to-bottom bands, then left-to-right)
  const order = work
    .map((r, idx) => ({ r, idx }))
    .sort((a, b) => {
      const bandDiff = Math.round(a.r.y * 1.5) - Math.round(b.r.y * 1.5);
      if (bandDiff !== 0) return bandDiff;
      return a.r.x - b.r.x || a.idx - b.idx;
    });

  const ordered = order.map((o) => ({ ...o.r }));
  const EPS = 0.01;

  for (let pass = 0; pass < 64; pass++) {
    let moved = false;
    for (let i = 0; i < ordered.length; i++) {
      const a = ordered[i];
      for (let j = i + 1; j < ordered.length; j++) {
        const b = ordered[j];
        const gapX = a.x + a.width + WALL_GAP_M - b.x;
        const gapXRev = b.x + b.width + WALL_GAP_M - a.x;
        const gapY = a.y + a.height + WALL_GAP_M - b.y;
        const gapYRev = b.y + b.height + WALL_GAP_M - a.y;

        if (gapX > EPS && gapXRev > EPS && gapY > EPS && gapYRev > EPS) {
          // Rooms overlap or violate WALL_GAP_M: separate along the axis of smaller push
          const pushRight = gapX;
          const pushDown = gapY;
          if (pushRight <= pushDown) {
            b.x = round1(a.x + a.width + WALL_GAP_M);
          } else {
            b.y = round1(a.y + a.height + WALL_GAP_M);
          }
          moved = true;
        }
      }
    }
    if (!moved) break;
  }

  // Normalize origin so top-left occupied room starts flush at (FLOOR_MARGIN_M, FLOOR_MARGIN_M)
  let minX = Infinity;
  let minY = Infinity;
  for (const r of ordered) {
    minX = Math.min(minX, r.x);
    minY = Math.min(minY, r.y);
  }
  const shiftX = round1(FLOOR_MARGIN_M - minX);
  const shiftY = round1(FLOOR_MARGIN_M - minY);

  const byId = new Map(
    ordered.map((r) => [
      r.id,
      {
        ...r,
        x: round1(Math.max(FLOOR_MARGIN_M, r.x + shiftX)),
        y: round1(Math.max(FLOOR_MARGIN_M, r.y + shiftY))
      }
    ])
  );

  // Return rooms in original input order so IDs and quick lists stay stable
  return sanitized.map((orig) => byId.get(orig.id) ?? orig);
}

/**
 * Deterministic automatic architectural room packing.
 * Assigns non-overlapping (x, y) coordinates while preserving every room's immutable ID, name, category, and sizes.
 */
export function autoArrangeFloorRooms(
  rooms: FloorRoom[],
  template: FloorLayoutTemplate,
  includeCorridor: boolean
): FloorRoom[] {
  if (rooms.length === 0) return [];

  if (template === 'custom-sketch') {
    return packCustomTopologyRooms(rooms);
  }

  const sanitized = rooms.map((r) => ({
    ...r,
    name: r.name.trim().slice(0, 48) || r.category,
    width: round1(Math.max(MIN_ROOM_M, Math.min(MAX_ROOM_M, r.width || DEFAULT_ROOM_W_M))),
    height: round1(Math.max(MIN_ROOM_M, Math.min(MAX_ROOM_M, r.height || DEFAULT_ROOM_H_M)))
  }));

  const n = sanitized.length;

  if (template === 'corridor') {
    const topCount = Math.ceil(n / 2);
    const topRooms = sanitized.slice(0, topCount);
    const bottomRooms = sanitized.slice(topCount);

    const corridorGap = includeCorridor ? Math.max(CORRIDOR_GAP_M, 1.8) : 1.4;
    const maxTopH = topRooms.reduce((m, r) => Math.max(m, r.height), 0);

    const arranged: FloorRoom[] = [];
    let curX = FLOOR_MARGIN_M;
    for (const r of topRooms) {
      arranged.push({
        ...r,
        x: round1(curX),
        y: FLOOR_MARGIN_M
      });
      curX = round1(curX + r.width + WALL_GAP_M);
    }

    if (bottomRooms.length > 0) {
      const bottomY = round1(FLOOR_MARGIN_M + maxTopH + corridorGap);
      let botX = FLOOR_MARGIN_M;
      for (const r of bottomRooms) {
        arranged.push({
          ...r,
          x: round1(botX),
          y: bottomY
        });
        botX = round1(botX + r.width + WALL_GAP_M);
      }
    }

    return arranged;
  }

  if (template === 'l-shape') {
    const topCount = n <= 2 ? n : Math.max(2, Math.ceil(n * 0.6));
    const topRooms = sanitized.slice(0, topCount);
    const legRooms = sanitized.slice(topCount);

    const maxTopH = topRooms.reduce((m, r) => Math.max(m, r.height), 0);
    const arranged: FloorRoom[] = [];

    let curX = FLOOR_MARGIN_M;
    for (const r of topRooms) {
      arranged.push({
        ...r,
        x: round1(curX),
        y: FLOOR_MARGIN_M
      });
      curX = round1(curX + r.width + WALL_GAP_M);
    }

    let curY = round1(FLOOR_MARGIN_M + maxTopH + (includeCorridor ? CORRIDOR_GAP_M : WALL_GAP_M));
    for (const r of legRooms) {
      arranged.push({
        ...r,
        x: FLOOR_MARGIN_M,
        y: round1(curY)
      });
      curY = round1(curY + r.height + WALL_GAP_M);
    }

    return arranged;
  }

  if (template === 'open-suite') {
    const main = sanitized[0];
    const sideCount = Math.min(2, Math.max(0, n - 1));
    const sideRooms = sanitized.slice(1, 1 + sideCount);
    const lowerRooms = sanitized.slice(1 + sideCount);

    const mainRoom: FloorRoom = {
      ...main,
      x: FLOOR_MARGIN_M,
      y: FLOOR_MARGIN_M
    };
    const arranged: FloorRoom[] = [mainRoom];

    const sideStartX = round1(FLOOR_MARGIN_M + mainRoom.width + (includeCorridor ? 0.9 : WALL_GAP_M));
    let sideY = FLOOR_MARGIN_M;
    let sideMaxX = mainRoom.x + mainRoom.width;
    let upperMaxY = mainRoom.y + mainRoom.height;

    for (const r of sideRooms) {
      arranged.push({
        ...r,
        x: sideStartX,
        y: round1(sideY)
      });
      sideMaxX = Math.max(sideMaxX, sideStartX + r.width);
      upperMaxY = Math.max(upperMaxY, sideY + r.height);
      sideY = round1(sideY + r.height + WALL_GAP_M);
    }

    if (lowerRooms.length > 0) {
      const cols = lowerRooms.length <= 2 ? lowerRooms.length : 3;
      let curY = round1(upperMaxY + (includeCorridor ? CORRIDOR_GAP_M : WALL_GAP_M));

      const rows = Math.ceil(lowerRooms.length / cols);
      for (let row = 0; row < rows; row++) {
        let curX = FLOOR_MARGIN_M;
        let rowMaxH = 0;
        for (let col = 0; col < cols; col++) {
          const idx = row * cols + col;
          if (idx >= lowerRooms.length) break;
          const r = lowerRooms[idx];
          arranged.push({
            ...r,
            x: round1(curX),
            y: round1(curY)
          });
          curX = round1(curX + r.width + WALL_GAP_M);
          rowMaxH = Math.max(rowMaxH, r.height);
        }
        curY = round1(curY + rowMaxH + WALL_GAP_M);
      }
    }

    return arranged;
  }

  // Default: 'grid' gap-free tight row packing (zero horizontal gaps, tight vertical rows)
  const cols = n <= 2 ? n : n <= 4 ? 2 : n <= 9 ? 3 : 4;
  const rows = Math.ceil(n / cols);
  const corridorSplitAfterRow = includeCorridor && rows >= 2 ? Math.floor(rows / 2) - 1 : -1;

  const arranged: FloorRoom[] = [];
  let accY = FLOOR_MARGIN_M;
  for (let row = 0; row < rows; row++) {
    let curX = FLOOR_MARGIN_M;
    let rowMaxH = 0;
    for (let col = 0; col < cols; col++) {
      const idx = row * cols + col;
      if (idx >= n) break;
      const r = sanitized[idx];
      arranged.push({
        ...r,
        x: round1(curX),
        y: round1(accY)
      });
      curX = round1(curX + r.width + WALL_GAP_M);
      rowMaxH = Math.max(rowMaxH, r.height);
    }
    const gap = row === corridorSplitAfterRow ? CORRIDOR_GAP_M : WALL_GAP_M;
    accY = round1(accY + rowMaxH + gap);
  }

  return arranged;
}

export function generateDefaultRooms(
  floorIndex: number,
  count: number,
  template: FloorLayoutTemplate = 'grid',
  includeCorridor = false
): FloorRoom[] {
  const safeCount = Math.max(1, Math.min(16, Math.round(count)));
  const rawRooms: FloorRoom[] = [];
  for (let i = 0; i < safeCount; i++) {
    const spec = DEFAULT_ROOM_SPECS[i] ?? {
      category: 'custom' as RoomCategory,
      defaultName: `Room ${i + 1}`,
      w: DEFAULT_ROOM_W_M,
      h: DEFAULT_ROOM_H_M
    };
    const suffix = floorIndex > 1 && i < DEFAULT_ROOM_SPECS.length ? ` (F${floorIndex})` : '';
    rawRooms.push({
      id: `f${floorIndex}_r${i + 1}_${Math.random().toString(36).slice(2, 6)}`,
      name: `${spec.defaultName}${suffix}`,
      category: spec.category,
      x: FLOOR_MARGIN_M,
      y: FLOOR_MARGIN_M,
      width: spec.w,
      height: spec.h
    });
  }
  return autoArrangeFloorRooms(rawRooms, template, includeCorridor);
}

export function createFloorPlan(
  index: number,
  roomCount = 5,
  template: FloorLayoutTemplate = 'grid',
  includeCorridor = false
): FloorPlan {
  const id = `floor_${index}_${Math.random().toString(36).slice(2, 6)}`;
  const rooms = generateDefaultRooms(index, roomCount, template, includeCorridor);
  const baseFloor: FloorPlan = {
    id,
    index,
    name: index === 1 ? 'Ground Floor' : `Floor ${index}`,
    layoutTemplate: template,
    includeCorridor,
    canvasWidth: 12,
    canvasHeight: 8,
    widthMeters: 10,
    heightMeters: 6,
    rooms,
    segments: []
  };
  return updateFloorBoundsAndWalls(baseFloor);
}

export function clampRouterToFloor(placement: RouterPlacement, floor: FloorPlan): RouterPlacement {
  if (placement.floorId !== floor.id) return placement;
  const minX = round1(FLOOR_MARGIN_M + 0.3);
  const minY = round1(FLOOR_MARGIN_M + 0.3);
  const maxX = round1(Math.max(minX + 0.5, floor.canvasWidth - FLOOR_MARGIN_M - 0.3));
  const maxY = round1(Math.max(minY + 0.5, floor.canvasHeight - FLOOR_MARGIN_M - 0.3));
  return {
    ...placement,
    x: round1(Math.max(minX, Math.min(maxX, placement.x))),
    y: round1(Math.max(minY, Math.min(maxY, placement.y)))
  };
}

export function clampProjectScenariosToFloors(project: HomeSurveyProject): HomeSurveyProject {
  const nextScenarios = { ...project.scenarios };
  (['original', 'alt-a', 'alt-b'] as RouterScenarioId[]).forEach((sid) => {
    const placement = nextScenarios[sid].routerPlacement;
    const floor = project.floors.find((f) => f.id === placement.floorId) ?? project.floors[0];
    if (!floor) return;
    nextScenarios[sid] = {
      ...nextScenarios[sid],
      routerPlacement: clampRouterToFloor({ ...placement, floorId: floor.id }, floor)
    };
  });
  return {
    ...project,
    scenarios: nextScenarios
  };
}

export function createDefaultSurveyProject(): HomeSurveyProject {
  const ground = createFloorPlan(1, 5, 'grid', false);
  const cx = round1(ground.canvasWidth / 2);
  const cy = round1(ground.canvasHeight / 2);
  const baseRouter: RouterPlacement = {
    floorId: ground.id,
    x: round1(FLOOR_MARGIN_M + 0.8),
    y: round1(FLOOR_MARGIN_M + 0.8),
    showApproxCoverage: true
  };
  return {
    version: 2,
    updatedAtIso: new Date().toISOString(),
    floors: [ground],
    activeFloorId: ground.id,
    activeScenarioId: 'original',
    scenarios: {
      original: { id: 'original', routerPlacement: { ...baseRouter } },
      'alt-a': { id: 'alt-a', routerPlacement: { ...baseRouter, x: cx, y: cy } },
      'alt-b': {
        id: 'alt-b',
        routerPlacement: {
          ...baseRouter,
          x: round1(Math.max(FLOOR_MARGIN_M + 1.5, ground.canvasWidth - FLOOR_MARGIN_M - 2.0)),
          y: round1(FLOOR_MARGIN_M + 2.0)
        }
      }
    },
    measurements: []
  };
}

export function setProjectFloorCount(project: HomeSurveyProject, targetCount: number): HomeSurveyProject {
  const safeCount = Math.max(1, Math.min(6, Math.round(targetCount)));
  const current = [...project.floors];
  if (safeCount === current.length) return project;

  let nextFloors: FloorPlan[];
  if (safeCount > current.length) {
    nextFloors = [...current];
    for (let i = current.length + 1; i <= safeCount; i++) {
      nextFloors.push(createFloorPlan(i, 4, 'grid', false));
    }
  } else {
    nextFloors = current.slice(0, safeCount);
  }

  const validIds = new Set(nextFloors.map((f) => f.id));
  const fallbackFloorId = nextFloors[0].id;
  const activeFloorId = validIds.has(project.activeFloorId) ? project.activeFloorId : fallbackFloorId;

  const updated = clampProjectScenariosToFloors({
    ...project,
    floors: nextFloors,
    activeFloorId,
    updatedAtIso: new Date().toISOString()
  });
  return updated;
}

export function applyFloorLayoutTemplate(
  floor: FloorPlan,
  template: FloorLayoutTemplate,
  includeCorridor = floor.includeCorridor
): FloorPlan {
  const arranged = autoArrangeFloorRooms(floor.rooms, template, includeCorridor);
  return updateFloorBoundsAndWalls({
    ...floor,
    layoutTemplate: template,
    includeCorridor,
    rooms: arranged
  });
}

export function setFloorRoomCount(floor: FloorPlan, targetCount: number): FloorPlan {
  const safeCount = Math.max(1, Math.min(16, Math.round(targetCount)));
  if (safeCount === floor.rooms.length) return floor;

  let nextRooms: FloorRoom[];
  if (safeCount < floor.rooms.length) {
    nextRooms = floor.rooms.slice(0, safeCount);
  } else {
    nextRooms = [...floor.rooms];
    let appendY = computeOccupiedBounds(nextRooms).maxY + WALL_GAP_M;
    while (nextRooms.length < safeCount) {
      const idx = nextRooms.length;
      const spec = DEFAULT_ROOM_SPECS[idx] ?? {
        category: 'custom' as RoomCategory,
        defaultName: `Room ${idx + 1}`,
        w: DEFAULT_ROOM_W_M,
        h: DEFAULT_ROOM_H_M
      };
      nextRooms.push({
        id: `${floor.id}_r${Date.now().toString(36)}_${idx}_${Math.random().toString(36).slice(2, 5)}`,
        name: spec.defaultName,
        category: spec.category,
        x: FLOOR_MARGIN_M,
        y: floor.layoutTemplate === 'custom-sketch' ? snapCoord(appendY, 0.2) : FLOOR_MARGIN_M,
        width: spec.w,
        height: spec.h
      });
      appendY = round1(appendY + spec.h + WALL_GAP_M);
    }
  }

  const arranged = autoArrangeFloorRooms(nextRooms, floor.layoutTemplate, floor.includeCorridor);
  return updateFloorBoundsAndWalls({
    ...floor,
    rooms: arranged
  });
}

export function addRoomToFloor(
  floor: FloorPlan,
  customName?: string,
  category?: RoomCategory
): { floor: FloorPlan; addedRoom: FloorRoom | null } {
  if (floor.rooms.length >= 16) {
    return { floor, addedRoom: null };
  }
  const idx = floor.rooms.length;
  const spec = DEFAULT_ROOM_SPECS[idx] ?? {
    category: 'custom' as RoomCategory,
    defaultName: `Room ${idx + 1}`,
    w: DEFAULT_ROOM_W_M,
    h: DEFAULT_ROOM_H_M
  };
  const chosenCat = category ?? spec.category;
  const bounds = computeOccupiedBounds(floor.rooms);
  const newRoom: FloorRoom = {
    id: `${floor.id}_r${Date.now().toString(36)}_${idx}_${Math.random().toString(36).slice(2, 5)}`,
    name: customName?.trim() ? customName.trim().slice(0, 48) : spec.defaultName,
    category: chosenCat,
    x: FLOOR_MARGIN_M,
    y: floor.layoutTemplate === 'custom-sketch' ? snapCoord(bounds.maxY + WALL_GAP_M, 0.2) : FLOOR_MARGIN_M,
    width: chosenCat === 'bathroom' ? 2.8 : chosenCat === 'corridor' ? 3.8 : spec.w,
    height: chosenCat === 'bathroom' ? 2.8 : chosenCat === 'corridor' ? 2.2 : spec.h
  };

  const arranged = autoArrangeFloorRooms(
    [...floor.rooms, newRoom],
    floor.layoutTemplate,
    floor.includeCorridor
  );
  const nextFloor = updateFloorBoundsAndWalls({
    ...floor,
    rooms: arranged
  });
  return {
    floor: nextFloor,
    addedRoom: nextFloor.rooms.find((r) => r.id === newRoom.id) ?? newRoom
  };
}

export function deleteRoomFromFloor(floor: FloorPlan, roomId: string): FloorPlan {
  if (floor.rooms.length <= 1) return floor;
  const remaining = floor.rooms.filter((r) => r.id !== roomId);
  if (remaining.length === floor.rooms.length) return floor;
  const arranged = autoArrangeFloorRooms(remaining, floor.layoutTemplate, floor.includeCorridor);
  return updateFloorBoundsAndWalls({
    ...floor,
    rooms: arranged
  });
}

export function renameRoomOnFloor(
  floor: FloorPlan,
  roomId: string,
  nextName: string,
  nextCategory?: RoomCategory
): FloorPlan {
  const cleanName = nextName.trim().slice(0, 48);
  const nextRooms = floor.rooms.map((r) => {
    if (r.id !== roomId) return r;
    return {
      ...r,
      name: cleanName || r.name,
      category: nextCategory ?? r.category
    };
  });
  return {
    ...floor,
    rooms: nextRooms
  };
}

/**
 * Independently resizes a room's width & height while keeping its origin (x, y) STRICTLY FIXED.
 * Never allows overlapping sibling rooms (maintains WALL_GAP_M clearance) or exceeding floor bounds.
 * Expands up to free space before a blocking neighbor and returns a clear reason code when blocked.
 */
export function resizeRoomSafely(
  floor: FloorPlan,
  roomId: string,
  requestedWidthM: number,
  requestedHeightM: number
): RoomResizeResult {
  const target = floor.rooms.find((r) => r.id === roomId);
  if (!target) {
    return {
      floor,
      room: floor.rooms[0],
      appliedWidth: 0,
      appliedHeight: 0,
      clampedWidth: false,
      clampedHeight: false,
      reason: 'none'
    };
  }

  const originX = target.x;
  const originY = target.y;
  const reqW = round1(requestedWidthM);
  const reqH = round1(requestedHeightM);

  const floorCapW = round1(Math.max(MIN_ROOM_M, MAX_FLOOR_SPAN_M - FLOOR_MARGIN_M - originX));
  const floorCapH = round1(Math.max(MIN_ROOM_M, MAX_FLOOR_SPAN_M - FLOOR_MARGIN_M - originY));
  const absoluteMaxW = Math.min(MAX_ROOM_M, floorCapW);
  const absoluteMaxH = Math.min(MAX_ROOM_M, floorCapH);

  let nextW = round1(Math.max(MIN_ROOM_M, Math.min(absoluteMaxW, reqW)));
  let nextH = round1(Math.max(MIN_ROOM_M, Math.min(absoluteMaxH, reqH)));

  let reason: ResizeBlockedReason = 'none';
  let blockingRoomName: string | undefined;

  if (reqW < MIN_ROOM_M || reqH < MIN_ROOM_M) {
    reason = 'min_limit';
  } else if (reqW > MAX_ROOM_M || reqH > MAX_ROOM_M) {
    reason = 'max_limit';
  } else if (reqW > floorCapW || reqH > floorCapH) {
    reason = 'floor_limit';
  }

  const EPS = 0.01;
  const siblings = floor.rooms.filter((r) => r.id !== roomId);

  // 1) Check rightward width limit against siblings overlapping vertically [originY, originY + curH]
  let maxAllowedW = absoluteMaxW;
  let widthBlocker: string | undefined;
  for (const other of siblings) {
    const sharesRow =
      originY < other.y + other.height + WALL_GAP_M - EPS &&
      originY + target.height + WALL_GAP_M - EPS > other.y;
    const isToRight = other.x + EPS >= originX + target.width;
    if (sharesRow && isToRight) {
      const limitW = round1(other.x - WALL_GAP_M - originX);
      if (limitW < maxAllowedW) {
        maxAllowedW = Math.max(target.width, Math.max(MIN_ROOM_M, limitW));
        widthBlocker = other.name;
      }
    }
  }

  if (nextW > maxAllowedW + EPS) {
    nextW = round1(maxAllowedW);
    reason = 'blocked_by_neighbor';
    blockingRoomName = widthBlocker;
  }

  // 2) Check downward height limit against siblings overlapping horizontally [originX, originX + nextW]
  let maxAllowedH = absoluteMaxH;
  let heightBlocker: string | undefined;
  for (const other of siblings) {
    const sharesCol =
      originX < other.x + other.width + WALL_GAP_M - EPS &&
      originX + nextW + WALL_GAP_M - EPS > other.x;
    const isBelow = other.y + EPS >= originY + target.height;
    if (sharesCol && isBelow) {
      const limitH = round1(other.y - WALL_GAP_M - originY);
      if (limitH < maxAllowedH) {
        maxAllowedH = Math.max(target.height, Math.max(MIN_ROOM_M, limitH));
        heightBlocker = other.name;
      }
    }
  }

  if (nextH > maxAllowedH + EPS) {
    nextH = round1(maxAllowedH);
    reason = 'blocked_by_neighbor';
    blockingRoomName = blockingRoomName ?? heightBlocker;
  }

  // 3) Final diagonal collision invariant check (when simultaneous W + H growth enters a diagonal neighbor)
  for (const other of siblings) {
    const overlapsX =
      originX < other.x + other.width + WALL_GAP_M - EPS &&
      originX + nextW + WALL_GAP_M - EPS > other.x;
    const overlapsY =
      originY < other.y + other.height + WALL_GAP_M - EPS &&
      originY + nextH + WALL_GAP_M - EPS > other.y;
    if (overlapsX && overlapsY) {
      const limitW = round1(other.x - WALL_GAP_M - originX);
      const limitH = round1(other.y - WALL_GAP_M - originY);
      if (other.x >= originX + target.width - EPS && limitW >= target.width - EPS) {
        nextW = Math.min(nextW, Math.max(MIN_ROOM_M, limitW));
      } else if (other.y >= originY + target.height - EPS && limitH >= target.height - EPS) {
        nextH = Math.min(nextH, Math.max(MIN_ROOM_M, limitH));
      } else {
        nextW = target.width;
        nextH = target.height;
      }
      reason = 'blocked_by_neighbor';
      blockingRoomName = blockingRoomName ?? other.name;
    }
  }

  const updatedRoom: FloorRoom = {
    ...target,
    x: originX, // Origin is NEVER shifted
    y: originY,
    width: round1(nextW),
    height: round1(nextH)
  };

  const nextRooms = floor.rooms.map((r) => (r.id === roomId ? updatedRoom : r));
  if (!verifyNoRoomOverlaps(nextRooms)) {
    // Hard safety net: never commit an overlapping layout
    return {
      floor,
      room: target,
      appliedWidth: target.width,
      appliedHeight: target.height,
      clampedWidth: nextW !== reqW,
      clampedHeight: nextH !== reqH,
      reason: 'blocked_by_neighbor',
      blockingRoomName
    };
  }

  const nextFloor = updateFloorBoundsAndWalls({
    ...floor,
    rooms: nextRooms
  });

  return {
    floor: nextFloor,
    room: updatedRoom,
    appliedWidth: updatedRoom.width,
    appliedHeight: updatedRoom.height,
    clampedWidth: Math.abs(updatedRoom.width - reqW) > 0.05,
    clampedHeight: Math.abs(updatedRoom.height - reqH) > 0.05,
    reason,
    blockingRoomName
  };
}

/**
 * Automated-layout room resize: updates width/height within logical & floor bounds,
 * dynamically reflows sibling room positions and adapts overall grid size with zero empty spaces and zero overlaps.
 */
export function resizeRoomAndReflow(
  floor: FloorPlan,
  roomId: string,
  requestedWidthM: number,
  requestedHeightM: number
): RoomResizeResult {
  const target = floor.rooms.find((r) => r.id === roomId);
  if (!target) {
    return {
      floor,
      room: floor.rooms[0],
      appliedWidth: 0,
      appliedHeight: 0,
      clampedWidth: false,
      clampedHeight: false,
      reason: 'none'
    };
  }

  const reqW = round1(requestedWidthM);
  const reqH = round1(requestedHeightM);
  let nextW = round1(Math.max(MIN_ROOM_M, Math.min(MAX_ROOM_M, reqW)));
  let nextH = round1(Math.max(MIN_ROOM_M, Math.min(MAX_ROOM_M, reqH)));

  let reason: ResizeBlockedReason = 'none';
  if (reqW < MIN_ROOM_M || reqH < MIN_ROOM_M) {
    reason = 'min_limit';
  } else if (reqW > MAX_ROOM_M || reqH > MAX_ROOM_M) {
    reason = 'max_limit';
  }

  // Test candidate reflow; if total canvas exceeds MAX_FLOOR_SPAN_M, clamp back smoothly
  const tryArrange = (w: number, h: number) => {
    const rw = round1(w);
    const rh = round1(h);
    const dW = round1(rw - target.width);
    const dH = round1(rh - target.height);

    const candidateRooms = floor.rooms.map((r) => {
      if (r.id === roomId) {
        return { ...r, width: rw, height: rh };
      }
      if (floor.layoutTemplate === 'custom-sketch') {
        const sharesRow =
          r.y < target.y + Math.max(target.height, rh) - 0.1 &&
          r.y + r.height > target.y + 0.1;
        const isToRight = r.x >= target.x + target.width - 0.1;
        const sharesCol =
          r.x < target.x + Math.max(target.width, rw) - 0.1 &&
          r.x + r.width > target.x + 0.1;
        const isBelow = r.y >= target.y + target.height - 0.1;

        return {
          ...r,
          x: isToRight && sharesRow ? snapCoord(Math.max(FLOOR_MARGIN_M, r.x + dW), 0.2) : r.x,
          y: isBelow && sharesCol ? snapCoord(Math.max(FLOOR_MARGIN_M, r.y + dH), 0.2) : r.y
        };
      }
      return r;
    });
    const arranged = autoArrangeFloorRooms(candidateRooms, floor.layoutTemplate, floor.includeCorridor);
    const built = updateFloorBoundsAndWalls({ ...floor, rooms: arranged });
    return built;
  };

  let nextFloor = tryArrange(nextW, nextH);

  if (nextFloor.canvasWidth > MAX_FLOOR_SPAN_M) {
    const overflowW = nextFloor.canvasWidth - MAX_FLOOR_SPAN_M;
    nextW = round1(Math.max(MIN_ROOM_M, nextW - overflowW));
    nextFloor = tryArrange(nextW, nextH);
    reason = 'floor_limit';
  }

  if (nextFloor.canvasHeight > MAX_FLOOR_SPAN_M) {
    const overflowH = nextFloor.canvasHeight - MAX_FLOOR_SPAN_M;
    nextH = round1(Math.max(MIN_ROOM_M, nextH - overflowH));
    nextFloor = tryArrange(nextW, nextH);
    reason = 'floor_limit';
  }

  if (!verifyNoRoomOverlaps(nextFloor.rooms)) {
    return {
      floor,
      room: target,
      appliedWidth: target.width,
      appliedHeight: target.height,
      clampedWidth: true,
      clampedHeight: true,
      reason: 'blocked_by_neighbor'
    };
  }

  const finalRoom = nextFloor.rooms.find((r) => r.id === roomId) ?? target;
  return {
    floor: nextFloor,
    room: finalRoom,
    appliedWidth: finalRoom.width,
    appliedHeight: finalRoom.height,
    clampedWidth: Math.abs(finalRoom.width - reqW) > 0.05,
    clampedHeight: Math.abs(finalRoom.height - reqH) > 0.05,
    reason
  };
}

export interface SketchRoomInput {
  name: string;
  category?: string;
  xPct: number;
  yPct: number;
  wPct: number;
  hPct: number;
}

export interface SketchConversionInput {
  rooms: SketchRoomInput[];
  suggestedSpanMeters?: {
    width?: number;
    height?: number;
  };
  routerPct?: {
    detected?: boolean;
    xPct?: number;
    yPct?: number;
  } | null;
}

export interface SketchOrganizedPlanResult {
  floor: FloorPlan;
  routerMeters?: {
    x: number;
    y: number;
  };
}

const VALID_ROOM_CATEGORIES = new Set<RoomCategory>([
  'living',
  'bedroom',
  'kitchen',
  'bathroom',
  'corridor',
  'office',
  'custom'
]);

/**
 * Converts AI-extracted sketch bounding boxes into an organized, zero-overlap metric FloorPlan
 * preserving the user's exact 2D spatial layout, wings, and relative sizes.
 */
export function organizeCustomSketchLayout(
  input: SketchConversionInput,
  activeFloor: FloorPlan
): SketchOrganizedPlanResult {
  const rawList = Array.isArray(input.rooms) ? input.rooms.slice(0, 16) : [];
  if (rawList.length === 0) {
    return { floor: activeFloor };
  }

  const cleanBoxes = rawList.map((r, idx) => {
    const xPct = Math.max(0, Math.min(96, Number(r.xPct) || 0));
    const yPct = Math.max(0, Math.min(96, Number(r.yPct) || 0));
    const wPct = Math.max(6, Math.min(100 - xPct, Number(r.wPct) || 25));
    const hPct = Math.max(6, Math.min(100 - yPct, Number(r.hPct) || 25));
    const catCandidate = (r.category || '').toLowerCase() as RoomCategory;
    return {
      name: (r.name || '').trim().slice(0, 48) || `Room ${idx + 1}`,
      category: VALID_ROOM_CATEGORIES.has(catCandidate) ? catCandidate : ('custom' as RoomCategory),
      xPct,
      yPct,
      wPct,
      hPct
    };
  });

  let minXPct = Infinity;
  let minYPct = Infinity;
  let maxXPct = -Infinity;
  let maxYPct = -Infinity;
  for (const b of cleanBoxes) {
    minXPct = Math.min(minXPct, b.xPct);
    minYPct = Math.min(minYPct, b.yPct);
    maxXPct = Math.max(maxXPct, b.xPct + b.wPct);
    maxYPct = Math.max(maxYPct, b.yPct + b.hPct);
  }
  const spanXPct = Math.max(15, maxXPct - minXPct);
  const spanYPct = Math.max(15, maxYPct - minYPct);

  const defaultSpan = Math.max(7.5, Math.min(19.0, Math.sqrt(cleanBoxes.length) * 5.2));
  const targetW = Math.max(
    6.0,
    Math.min(22.0, Number(input.suggestedSpanMeters?.width) || defaultSpan)
  );
  const targetH = Math.max(
    5.5,
    Math.min(
      20.0,
      Number(input.suggestedSpanMeters?.height) || defaultSpan * (spanYPct / spanXPct)
    )
  );

  let mappedRooms: FloorRoom[] = cleanBoxes.map((b, idx) => ({
    id: `${activeFloor.id}_sk_${Date.now().toString(36)}_${idx}_${Math.random().toString(36).slice(2, 5)}`,
    name: b.name,
    category: b.category,
    x: snapCoord(FLOOR_MARGIN_M + ((b.xPct - minXPct) / spanXPct) * targetW, 0.2),
    y: snapCoord(FLOOR_MARGIN_M + ((b.yPct - minYPct) / spanYPct) * targetH, 0.2),
    width: round1(Math.max(MIN_ROOM_M, Math.min(MAX_ROOM_M, (b.wPct / spanXPct) * targetW))),
    height: round1(Math.max(MIN_ROOM_M, Math.min(MAX_ROOM_M, (b.hPct / spanYPct) * targetH)))
  }));

  mappedRooms = packCustomTopologyRooms(mappedRooms);

  // Guard against exceeding MAX_FLOOR_SPAN_M on dense 12..16 room sketches
  for (let shrink = 0; shrink < 8; shrink++) {
    const bounds = computeOccupiedBounds(mappedRooms);
    if (
      bounds.maxX + FLOOR_MARGIN_M <= MAX_FLOOR_SPAN_M &&
      bounds.maxY + FLOOR_MARGIN_M <= MAX_FLOOR_SPAN_M
    ) {
      break;
    }
    const overX = bounds.maxX + FLOOR_MARGIN_M > MAX_FLOOR_SPAN_M;
    const overY = bounds.maxY + FLOOR_MARGIN_M > MAX_FLOOR_SPAN_M;
    mappedRooms = packCustomTopologyRooms(
      mappedRooms.map((r) => ({
        ...r,
        x: overX ? snapCoord(FLOOR_MARGIN_M + (r.x - FLOOR_MARGIN_M) * 0.85, 0.2) : r.x,
        y: overY ? snapCoord(FLOOR_MARGIN_M + (r.y - FLOOR_MARGIN_M) * 0.85, 0.2) : r.y,
        width: overX ? round1(Math.max(MIN_ROOM_M, r.width * 0.85)) : r.width,
        height: overY ? round1(Math.max(MIN_ROOM_M, r.height * 0.85)) : r.height
      }))
    );
  }

  const floor = updateFloorBoundsAndWalls({
    ...activeFloor,
    layoutTemplate: 'custom-sketch',
    includeCorridor: false,
    rooms: mappedRooms,
    segments: [] // Replace manual wall clutter with freshly organized walls & doors
  });

  let routerMeters: { x: number; y: number } | undefined;
  if (
    input.routerPct?.detected &&
    typeof input.routerPct.xPct === 'number' &&
    typeof input.routerPct.yPct === 'number'
  ) {
    const occupied = computeOccupiedBounds(floor.rooms);
    const rxRatio = Math.max(0.05, Math.min(0.95, (input.routerPct.xPct - minXPct) / spanXPct));
    const ryRatio = Math.max(0.05, Math.min(0.95, (input.routerPct.yPct - minYPct) / spanYPct));
    routerMeters = {
      x: round1(occupied.minX + rxRatio * (occupied.maxX - occupied.minX)),
      y: round1(occupied.minY + ryRatio * (occupied.maxY - occupied.minY))
    };
  }

  return { floor, routerMeters };
}

export function pushFloorHistory(history: FloorLayoutHistory, nextFloors: FloorPlan[]): FloorLayoutHistory {
  return {
    past: [...history.past.slice(-29), history.present],
    present: nextFloors,
    future: []
  };
}

export function undoFloorHistory(history: FloorLayoutHistory): FloorLayoutHistory {
  if (history.past.length === 0) return history;
  const previous = history.past[history.past.length - 1];
  return {
    past: history.past.slice(0, -1),
    present: previous,
    future: [history.present, ...history.future]
  };
}

export function redoFloorHistory(history: FloorLayoutHistory): FloorLayoutHistory {
  if (history.future.length === 0) return history;
  const next = history.future[0];
  return {
    past: [...history.past, history.present],
    present: next,
    future: history.future.slice(1)
  };
}

export function getLatestRoomMeasurement(
  measurements: RoomMeasurementRecord[],
  roomId: string,
  scenarioId: RouterScenarioId
): RoomMeasurementRecord | null {
  let latest: RoomMeasurementRecord | null = null;
  for (const m of measurements) {
    if (m.roomId !== roomId || m.scenarioId !== scenarioId) continue;
    if (!latest || m.measuredAtIso > latest.measuredAtIso) {
      latest = m;
    }
  }
  return latest;
}

export function getRoomMeasurementHistory(
  measurements: RoomMeasurementRecord[],
  roomId: string,
  scenarioId?: RouterScenarioId
): RoomMeasurementRecord[] {
  return measurements
    .filter((m) => m.roomId === roomId && (!scenarioId || m.scenarioId === scenarioId))
    .sort((a, b) => b.measuredAtIso.localeCompare(a.measuredAtIso));
}

export interface MeasurementDelta {
  downloadDeltaMbps: number;
  uploadDeltaMbps: number;
  pingDeltaMs: number;
  jitterDeltaMs: number;
}

export function computeMeasurementDelta(
  latest: RoomMeasurementRecord,
  previous: RoomMeasurementRecord | undefined
): MeasurementDelta | null {
  if (!previous) return null;
  return {
    downloadDeltaMbps: Number((latest.downloadMbps - previous.downloadMbps).toFixed(2)),
    uploadDeltaMbps: Number((latest.uploadMbps - previous.uploadMbps).toFixed(2)),
    pingDeltaMs: Number((latest.pingMs - previous.pingMs).toFixed(1)),
    jitterDeltaMs: Number((latest.jitterMs - previous.jitterMs).toFixed(1))
  };
}

/**
 * Classifies a room for the heatmap STRICTLY from its actual measurement.
 * Never colors an unmeasured room or fabricates signal values.
 */
export function classifyRoomHeatmapMetric(
  measurement: RoomMeasurementRecord | null,
  metric: HeatmapMetric
): { tier: HeatmapTier; valueText: string | null } {
  if (!measurement) {
    return { tier: 'unmeasured', valueText: null };
  }

  switch (metric) {
    case 'download': {
      const v = measurement.downloadMbps;
      const tier: HeatmapTier = v >= 50 ? 'strong' : v >= 15 ? 'moderate' : 'weak';
      return { tier, valueText: `${v.toFixed(1)} Mbps` };
    }
    case 'upload': {
      const v = measurement.uploadMbps;
      const tier: HeatmapTier = v >= 20 ? 'strong' : v >= 5 ? 'moderate' : 'weak';
      return { tier, valueText: `${v.toFixed(1)} Mbps` };
    }
    case 'ping': {
      const v = measurement.pingMs;
      const tier: HeatmapTier = v <= 35 ? 'strong' : v <= 80 ? 'moderate' : 'weak';
      return { tier, valueText: `${v.toFixed(1)} ms` };
    }
    case 'jitter': {
      const v = measurement.jitterMs;
      const tier: HeatmapTier = v <= 10 ? 'strong' : v <= 30 ? 'moderate' : 'weak';
      return { tier, valueText: `${v.toFixed(1)} ms` };
    }
    case 'signal': {
      if (measurement.signalStrengthDbm === null || !Number.isFinite(measurement.signalStrengthDbm)) {
        return { tier: 'unmeasured', valueText: null };
      }
      const s = measurement.signalStrengthDbm;
      const tier: HeatmapTier = s >= -60 ? 'strong' : s >= -72 ? 'moderate' : 'weak';
      return { tier, valueText: `${s} dBm` };
    }
  }
}

export interface SurveyInsight {
  id: string;
  kind: 'confirmed' | 'recommendation';
  severity: 'good' | 'warn' | 'bad' | 'info';
  titleKey: string;
  evidence: string;
}

export interface FloorSummary {
  floorId: string;
  floorName: string;
  totalRooms: number;
  measuredRooms: number;
  avgDownloadMbps: number | null;
  avgUploadMbps: number | null;
  avgPingMs: number | null;
}

export interface ScenarioComparisonSummary {
  scenarioId: RouterScenarioId;
  routerFloorName: string;
  routerCoords: Point2D;
  measuredRoomsCount: number;
  totalRoomsCount: number;
  avgDownloadMbps: number | null;
  minDownloadMbps: number | null;
  avgUploadMbps: number | null;
  avgPingMs: number | null;
  sufficientForComparison: boolean;
}

export interface HomeSurveyAnalysisReport {
  totalRooms: number;
  measuredRoomsCount: number;
  strongestRoom: RoomMeasurementRecord | null;
  weakestRoom: RoomMeasurementRecord | null;
  floorSummaries: FloorSummary[];
  scenarioComparisons: ScenarioComparisonSummary[];
  bestTestedScenario: RouterScenarioId | null;
  confirmedFindings: SurveyInsight[];
  recommendations: SurveyInsight[];
}

export function analyzeHomeSurvey(project: HomeSurveyProject): HomeSurveyAnalysisReport {
  const activeScenario = project.activeScenarioId;
  const allRooms = project.floors.flatMap((f) => f.rooms.map((r) => ({ floor: f, room: r })));
  const totalRooms = allRooms.length;

  const latestActiveList: RoomMeasurementRecord[] = [];
  for (const { room } of allRooms) {
    const latest = getLatestRoomMeasurement(project.measurements, room.id, activeScenario);
    if (latest) latestActiveList.push(latest);
  }

  const sortedByDownload = [...latestActiveList].sort((a, b) => b.downloadMbps - a.downloadMbps);
  const strongestRoom = sortedByDownload[0] ?? null;
  const weakestRoom =
    sortedByDownload.length > 1 ? sortedByDownload[sortedByDownload.length - 1] : sortedByDownload[0] ?? null;

  const floorSummaries: FloorSummary[] = project.floors.map((floor) => {
    const floorLatest = floor.rooms
      .map((r) => getLatestRoomMeasurement(project.measurements, r.id, activeScenario))
      .filter((m): m is RoomMeasurementRecord => Boolean(m));

    return {
      floorId: floor.id,
      floorName: floor.name,
      totalRooms: floor.rooms.length,
      measuredRooms: floorLatest.length,
      avgDownloadMbps:
        floorLatest.length > 0
          ? Number((floorLatest.reduce((a, m) => a + m.downloadMbps, 0) / floorLatest.length).toFixed(1))
          : null,
      avgUploadMbps:
        floorLatest.length > 0
          ? Number((floorLatest.reduce((a, m) => a + m.uploadMbps, 0) / floorLatest.length).toFixed(1))
          : null,
      avgPingMs:
        floorLatest.length > 0
          ? Number((floorLatest.reduce((a, m) => a + m.pingMs, 0) / floorLatest.length).toFixed(1))
          : null
    };
  });

  const scenarioComparisons: ScenarioComparisonSummary[] = (['original', 'alt-a', 'alt-b'] as RouterScenarioId[]).map(
    (sid) => {
      const scenario = project.scenarios[sid];
      const routerFloor = project.floors.find((f) => f.id === scenario.routerPlacement.floorId) ?? project.floors[0];
      const list = allRooms
        .map(({ room }) => getLatestRoomMeasurement(project.measurements, room.id, sid))
        .filter((m): m is RoomMeasurementRecord => Boolean(m));

      return {
        scenarioId: sid,
        routerFloorName: routerFloor?.name ?? '-',
        routerCoords: { x: scenario.routerPlacement.x, y: scenario.routerPlacement.y },
        measuredRoomsCount: list.length,
        totalRoomsCount: totalRooms,
        avgDownloadMbps:
          list.length > 0 ? Number((list.reduce((a, m) => a + m.downloadMbps, 0) / list.length).toFixed(1)) : null,
        minDownloadMbps:
          list.length > 0 ? Number(Math.min(...list.map((m) => m.downloadMbps)).toFixed(1)) : null,
        avgUploadMbps:
          list.length > 0 ? Number((list.reduce((a, m) => a + m.uploadMbps, 0) / list.length).toFixed(1)) : null,
        avgPingMs:
          list.length > 0 ? Number((list.reduce((a, m) => a + m.pingMs, 0) / list.length).toFixed(1)) : null,
        sufficientForComparison: list.length >= Math.min(2, totalRooms)
      };
    }
  );

  const comparableScenarios = scenarioComparisons.filter((s) => s.sufficientForComparison && s.avgDownloadMbps !== null);
  let bestTestedScenario: RouterScenarioId | null = null;
  if (comparableScenarios.length >= 2) {
    const ranked = [...comparableScenarios].sort((a, b) => {
      const scoreA = (a.minDownloadMbps ?? 0) * 1.5 + (a.avgDownloadMbps ?? 0);
      const scoreB = (b.minDownloadMbps ?? 0) * 1.5 + (b.avgDownloadMbps ?? 0);
      return scoreB - scoreA;
    });
    bestTestedScenario = ranked[0].scenarioId;
  }

  const confirmedFindings: SurveyInsight[] = [];
  const recommendations: SurveyInsight[] = [];

  if (latestActiveList.length === 0) {
    recommendations.push({
      id: 'rec_need_measurements',
      kind: 'recommendation',
      severity: 'info',
      titleKey: 'survey.analysis.needMeasurementsTitle',
      evidence: `0 / ${totalRooms}`
    });
    return {
      totalRooms,
      measuredRoomsCount: 0,
      strongestRoom: null,
      weakestRoom: null,
      floorSummaries,
      scenarioComparisons,
      bestTestedScenario,
      confirmedFindings,
      recommendations
    };
  }

  if (strongestRoom) {
    confirmedFindings.push({
      id: 'fact_strongest',
      kind: 'confirmed',
      severity: 'good',
      titleKey: 'survey.analysis.strongestRoomTitle',
      evidence: `${strongestRoom.roomName} (${strongestRoom.floorName}): ${strongestRoom.downloadMbps.toFixed(1)} Mbps DL · ${strongestRoom.pingMs.toFixed(1)} ms`
    });
  }

  if (weakestRoom && latestActiveList.length >= 2) {
    confirmedFindings.push({
      id: 'fact_weakest',
      kind: 'confirmed',
      severity: weakestRoom.downloadMbps < 15 || weakestRoom.pingMs > 80 ? 'bad' : 'warn',
      titleKey: 'survey.analysis.weakestRoomTitle',
      evidence: `${weakestRoom.roomName} (${weakestRoom.floorName}): ${weakestRoom.downloadMbps.toFixed(1)} Mbps DL · ${weakestRoom.pingMs.toFixed(1)} ms`
    });
  }

  const measuredFloors = floorSummaries.filter((f) => f.measuredRooms > 0 && f.avgDownloadMbps !== null);
  if (measuredFloors.length >= 2) {
    const sortedFloors = [...measuredFloors].sort((a, b) => (b.avgDownloadMbps ?? 0) - (a.avgDownloadMbps ?? 0));
    const topF = sortedFloors[0];
    const botF = sortedFloors[sortedFloors.length - 1];
    confirmedFindings.push({
      id: 'fact_floor_diff',
      kind: 'confirmed',
      severity: (topF.avgDownloadMbps ?? 0) - (botF.avgDownloadMbps ?? 0) > 15 ? 'warn' : 'info',
      titleKey: 'survey.analysis.floorComparisonTitle',
      evidence: `${topF.floorName}: ${topF.avgDownloadMbps} Mbps vs ${botF.floorName}: ${botF.avgDownloadMbps} Mbps`
    });

    if ((botF.avgDownloadMbps ?? 0) < 20) {
      recommendations.push({
        id: 'rec_floor_extender',
        kind: 'recommendation',
        severity: 'warn',
        titleKey: 'survey.analysis.extenderFloorTitle',
        evidence: `${botF.floorName} avg ${botF.avgDownloadMbps} Mbps`
      });
    }
  }

  const scenarioMeasurements = project.measurements.filter((m) => m.scenarioId === activeScenario);
  for (const { room } of allRooms) {
    const r5 = scenarioMeasurements.find((m) => m.roomId === room.id && m.bandUsed === '5GHz');
    const r24 = scenarioMeasurements.find((m) => m.roomId === room.id && m.bandUsed === '2.4GHz');
    if (r5 && r24 && r5.downloadMbps < r24.downloadMbps * 0.9) {
      confirmedFindings.push({
        id: `fact_band_${room.id}`,
        kind: 'confirmed',
        severity: 'warn',
        titleKey: 'survey.analysis.fiveGhzWeakerTitle',
        evidence: `${room.name}: 5 GHz ${r5.downloadMbps.toFixed(1)} Mbps < 2.4 GHz ${r24.downloadMbps.toFixed(1)} Mbps`
      });
      recommendations.push({
        id: `rec_band_${room.id}`,
        kind: 'recommendation',
        severity: 'info',
        titleKey: 'survey.analysis.use24GhzTitle',
        evidence: `${room.name}`
      });
    }
  }

  const weakRooms = latestActiveList.filter((m) => m.downloadMbps < 15 || m.pingMs > 80);
  if (weakRooms.length > 0) {
    recommendations.push({
      id: 'rec_weak_ap',
      kind: 'recommendation',
      severity: 'warn',
      titleKey: 'survey.analysis.weakZoneApTitle',
      evidence: weakRooms.map((r) => `${r.roomName} (${r.downloadMbps.toFixed(1)} Mbps)`).join(', ')
    });
  }

  if (strongestRoom && weakestRoom && strongestRoom.roomId !== weakestRoom.roomId) {
    const dropPct =
      strongestRoom.downloadMbps > 0
        ? Math.round(((strongestRoom.downloadMbps - weakestRoom.downloadMbps) / strongestRoom.downloadMbps) * 100)
        : 0;
    if (dropPct >= 40) {
      recommendations.push({
        id: 'rec_central_router',
        kind: 'recommendation',
        severity: 'info',
        titleKey: 'survey.analysis.testCentralLocationTitle',
        evidence: `-${dropPct}% (${strongestRoom.roomName} -> ${weakestRoom.roomName})`
      });
    }
  }

  if (latestActiveList.length < totalRooms) {
    recommendations.push({
      id: 'rec_incomplete_coverage',
      kind: 'recommendation',
      severity: 'info',
      titleKey: 'survey.analysis.incompleteSurveyTitle',
      evidence: `${latestActiveList.length} / ${totalRooms}`
    });
  }

  return {
    totalRooms,
    measuredRoomsCount: latestActiveList.length,
    strongestRoom,
    weakestRoom,
    floorSummaries,
    scenarioComparisons,
    bestTestedScenario,
    confirmedFindings,
    recommendations
  };
}

/**
 * Rough visual coverage radius in meters (~6.5m indoor consumer router radius).
 * Explicitly marked as estimated — never presented as measured truth.
 */
export function estimateApproxCoverageRadiusMeters(floor: FloorPlan): number {
  const maxSpan = Math.max(floor.canvasWidth, floor.canvasHeight);
  return round1(Math.min(7.0, Math.max(3.2, maxSpan * 0.42)));
}
