import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  addRoomToFloor,
  analyzeHomeSurvey,
  applyFloorLayoutTemplate,
  clampProjectScenariosToFloors,
  classifyRoomHeatmapMetric,
  computeMeasurementDelta,
  createDefaultSurveyProject,
  createFloorPlan,
  deleteRoomFromFloor,
  FloorLayoutHistory,
  HomeSurveyProject,
  MAX_FLOOR_SPAN_M,
  MAX_ROOM_M,
  MIN_ROOM_M,
  organizeCustomSketchLayout,
  packCustomTopologyRooms,
  pushFloorHistory,
  redoFloorHistory,
  renameRoomOnFloor,
  resizeRoomAndReflow,
  resizeRoomSafely,
  RoomMeasurementRecord,
  setFloorRoomCount,
  setProjectFloorCount,
  undoFloorHistory,
  verifyNoRoomOverlaps,
  WALL_GAP_M
} from './floorPlanEngine.ts';
import { migrateV1ToV2Project, normalizeStoredSurveyProject } from './floorPlanStore.ts';

function makeMeasurement(overrides: Partial<RoomMeasurementRecord> = {}): RoomMeasurementRecord {
  return {
    id: `m_${Math.random().toString(36).slice(2, 6)}`,
    scenarioId: 'original',
    floorId: 'f1',
    floorName: 'Ground Floor',
    roomId: 'r1',
    roomName: 'Living Room',
    measuredAtIso: '2026-11-25T10:00:00.000Z',
    serverName: 'Test Endpoint',
    downloadMbps: 64.5,
    uploadMbps: 22.1,
    pingMs: 18.4,
    jitterMs: 3.2,
    packetLossPct: 0,
    bandUsed: 'unknown',
    signalStrengthDbm: null,
    connectionSummary: 'online',
    ...overrides
  };
}

describe('Smart Adaptive Home Map Engine (Metric + Zero-Overlap)', () => {
  it('adapts canvas dimensions for 1 floor with 2 rooms vs 6 rooms (zero overlap)', () => {
    const floor2 = createFloorPlan(1, 2, 'grid', false);
    const floor6 = createFloorPlan(1, 6, 'grid', false);

    assert.equal(floor2.rooms.length, 2);
    assert.equal(floor6.rooms.length, 6);
    assert.ok(verifyNoRoomOverlaps(floor2.rooms), '2-room layout must have zero overlap');
    assert.ok(verifyNoRoomOverlaps(floor6.rooms), '6-room layout must have zero overlap');

    const area2 = floor2.canvasWidth * floor2.canvasHeight;
    const area6 = floor6.canvasWidth * floor6.canvasHeight;
    assert.ok(area2 < area6 * 0.7, `2-room canvas (${area2}) should be noticeably smaller than 6-room canvas (${area6})`);
  });

  it('supports multi-floor homes with independent room counts & valid router clamping', () => {
    let project = createDefaultSurveyProject();
    project = setProjectFloorCount(project, 2);
    assert.equal(project.floors.length, 2);

    const floor1Updated = setFloorRoomCount(project.floors[0], 3);
    const floor2Updated = setFloorRoomCount(project.floors[1], 7);
    project = clampProjectScenariosToFloors({
      ...project,
      floors: [floor1Updated, floor2Updated]
    });

    assert.equal(project.floors[0].rooms.length, 3);
    assert.equal(project.floors[1].rooms.length, 7);
    assert.ok(verifyNoRoomOverlaps(project.floors[0].rooms));
    assert.ok(verifyNoRoomOverlaps(project.floors[1].rooms));

    const routerOrig = project.scenarios.original.routerPlacement;
    assert.ok(routerOrig.x <= project.floors[0].canvasWidth);
    assert.ok(routerOrig.y <= project.floors[0].canvasHeight);
  });

  it('expands canvas on addRoomToFloor and shrinks cleanly on deleteRoomFromFloor while keeping existing IDs', () => {
    let floor = createFloorPlan(1, 2, 'grid', false);
    const initialIds = floor.rooms.map((r) => r.id);
    const areaInitial = floor.canvasWidth * floor.canvasHeight;

    const added = addRoomToFloor(floor, 'Study Room', 'office');
    floor = added.floor;
    assert.equal(floor.rooms.length, 3);
    assert.ok(floor.rooms.some((r) => r.id === initialIds[0]));
    assert.ok(floor.rooms.some((r) => r.id === initialIds[1]));
    assert.ok(floor.rooms.some((r) => r.name === 'Study Room'));
    assert.ok(verifyNoRoomOverlaps(floor.rooms));

    const areaAfterAdd = floor.canvasWidth * floor.canvasHeight;
    assert.ok(areaAfterAdd > areaInitial, 'Adding room should expand adaptive map bounds');

    const addedId = added.addedRoom!.id;
    floor = deleteRoomFromFloor(floor, addedId);
    assert.equal(floor.rooms.length, 2);
    assert.deepEqual(
      floor.rooms.map((r) => r.id),
      initialIds
    );
    assert.equal(floor.canvasWidth * floor.canvasHeight, areaInitial);
  });

  it('supports all layout templates and corridor mode with zero room overlaps', () => {
    const templates = ['grid', 'corridor', 'l-shape', 'open-suite'] as const;
    const base = createFloorPlan(1, 6);
    const initialIds = base.rooms.map((r) => r.id);

    for (const tpl of templates) {
      for (const corridor of [false, true]) {
        const arranged = applyFloorLayoutTemplate(base, tpl, corridor);
        assert.ok(
          verifyNoRoomOverlaps(arranged.rooms),
          `Template ${tpl} (corridor=${corridor}) must produce zero overlaps`
        );
        assert.deepEqual(
          arranged.rooms.map((r) => r.id),
          initialIds,
          'Template reflow must keep every room immutable ID'
        );
      }
    }
  });

  it('resizes room width and height independently without EVER shifting its (x, y) origin', () => {
    // 2 rooms side-by-side: room[0] is on top-left, room[1] is to its right
    const floor = createFloorPlan(1, 2, 'grid', false);
    const leftRoom = floor.rooms[0];
    const rightRoom = floor.rooms[1];
    const origX = leftRoom.x;
    const origY = leftRoom.y;

    // Lengthen room 0 downward (no room below it in a 2-room 1-row grid) & narrow width
    const res = resizeRoomSafely(floor, leftRoom.id, leftRoom.width - 1.2, leftRoom.height + 2.5);
    assert.equal(res.reason, 'none');
    assert.equal(res.room.x, origX, 'Origin X must remain strictly unchanged');
    assert.equal(res.room.y, origY, 'Origin Y must remain strictly unchanged');
    assert.equal(res.room.width, Math.round((leftRoom.width - 1.2) * 10) / 10);
    assert.equal(res.room.height, Math.round((leftRoom.height + 2.5) * 10) / 10);
    assert.ok(verifyNoRoomOverlaps(res.floor.rooms));

    // Right room stays at its exact position too
    const rightAfter = res.floor.rooms.find((r) => r.id === rightRoom.id)!;
    assert.equal(rightAfter.x, rightRoom.x);
    assert.equal(rightAfter.y, rightRoom.y);
  });

  it('prevents room overlap on resize when blocked by adjacent sibling and returns clear reason + blocker name', () => {
    const floor = createFloorPlan(1, 2, 'grid', false);
    const leftRoom = floor.rooms[0];
    const rightRoom = floor.rooms[1];

    // First narrow leftRoom slightly, then expand heavily rightward past rightRoom.x
    const narrowed = resizeRoomSafely(floor, leftRoom.id, MIN_ROOM_M, leftRoom.height).floor;
    const expanded = resizeRoomSafely(narrowed, leftRoom.id, MAX_ROOM_M, leftRoom.height);

    assert.equal(expanded.reason, 'blocked_by_neighbor');
    assert.equal(expanded.blockingRoomName, rightRoom.name);
    assert.equal(expanded.room.x, leftRoom.x);
    assert.equal(expanded.room.y, leftRoom.y);
    assert.ok(expanded.room.x + expanded.room.width + WALL_GAP_M <= rightRoom.x + 0.01);
    assert.ok(verifyNoRoomOverlaps(expanded.floor.rooms));
  });

  it('enforces MIN_ROOM_M and MAX_ROOM_M boundaries cleanly', () => {
    const floor = createFloorPlan(1, 1, 'grid', false);
    const single = floor.rooms[0];

    const tooSmall = resizeRoomSafely(floor, single.id, 0.4, 0.5);
    assert.equal(tooSmall.reason, 'min_limit');
    assert.equal(tooSmall.appliedWidth, MIN_ROOM_M);
    assert.equal(tooSmall.appliedHeight, MIN_ROOM_M);

    const tooBig = resizeRoomSafely(floor, single.id, 15.0, 14.0);
    assert.equal(tooBig.reason, 'max_limit');
    assert.equal(tooBig.appliedWidth, MAX_ROOM_M);
    assert.equal(tooBig.appliedHeight, MAX_ROOM_M);
  });

  it('renames a room cleanly without changing coordinates, ID, or measurements', () => {
    const project = createDefaultSurveyProject();
    const floor = project.floors[0];
    const target = floor.rooms[0];

    const m = makeMeasurement({
      floorId: floor.id,
      floorName: floor.name,
      roomId: target.id,
      roomName: target.name
    });

    const renamedFloor = renameRoomOnFloor(floor, target.id, 'غرفة المعيشة الرئيسية', 'living');
    const renamedRoom = renamedFloor.rooms.find((r) => r.id === target.id)!;

    assert.equal(renamedRoom.name, 'غرفة المعيشة الرئيسية');
    assert.equal(renamedRoom.x, target.x);
    assert.equal(renamedRoom.y, target.y);

    const updatedProject: HomeSurveyProject = {
      ...project,
      floors: [renamedFloor],
      measurements: [m]
    };

    const report = analyzeHomeSurvey(updatedProject);
    assert.equal(report.measuredRoomsCount, 1);
    assert.equal(report.strongestRoom?.roomId, target.id);
  });

  it('undo/redo preserves and restores floor dimensions cleanly', () => {
    const floor = createFloorPlan(1, 2);
    let history: FloorLayoutHistory = {
      past: [],
      present: [floor],
      future: []
    };
    const nextFloor = addRoomToFloor(floor, 'Extra').floor;
    history = pushFloorHistory(history, [nextFloor]);
    assert.equal(history.present[0].rooms.length, 3);

    history = undoFloorHistory(history);
    assert.equal(history.present[0].rooms.length, 2);

    history = redoFloorHistory(history);
    assert.equal(history.present[0].rooms.length, 3);
  });

  it('migrates legacy v1 survey projects cleanly to v2 without losing rooms or measurements', () => {
    const legacy = {
      version: 1 as const,
      updatedAtIso: '2026-11-20T12:00:00.000Z',
      floors: [
        {
          id: 'floor_1_old',
          index: 1,
          name: 'Ground Floor',
          widthMeters: 12,
          heightMeters: 8,
          rooms: [
            { id: 'room_legacy_1', name: 'Lounge', category: 'living' as const, x: 5, y: 6, width: 45, height: 40 },
            { id: 'room_legacy_2', name: 'Office', category: 'office' as const, x: 52, y: 6, width: 42, height: 40 }
          ]
        }
      ],
      activeFloorId: 'floor_1_old',
      activeScenarioId: 'original' as const,
      scenarios: {
        original: { id: 'original' as const, routerPlacement: { floorId: 'floor_1_old', x: 25, y: 25, showApproxCoverage: true } },
        'alt-a': { id: 'alt-a' as const, routerPlacement: { floorId: 'floor_1_old', x: 50, y: 50, showApproxCoverage: true } },
        'alt-b': { id: 'alt-b' as const, routerPlacement: { floorId: 'floor_1_old', x: 75, y: 25, showApproxCoverage: true } }
      },
      measurements: [
        makeMeasurement({ floorId: 'floor_1_old', roomId: 'room_legacy_1', roomName: 'Lounge', downloadMbps: 88.2 })
      ]
    };

    const migrated = migrateV1ToV2Project(legacy);
    assert.equal(migrated.version, 2);
    assert.equal(migrated.floors[0].rooms.length, 2);
    assert.equal(migrated.floors[0].rooms[0].id, 'room_legacy_1');
    assert.equal(migrated.measurements.length, 1);
    assert.equal(migrated.measurements[0].downloadMbps, 88.2);
    assert.ok(verifyNoRoomOverlaps(migrated.floors[0].rooms));

    const normalized = normalizeStoredSurveyProject(legacy);
    assert.ok(normalized !== null && normalized.version === 2);
  });

  it('keeps strict heatmap classification and measurement deltas honest', () => {
    const unmeasured = classifyRoomHeatmapMetric(null, 'download');
    assert.equal(unmeasured.tier, 'unmeasured');
    assert.equal(unmeasured.valueText, null);

    const prev = makeMeasurement({ downloadMbps: 25, uploadMbps: 8, pingMs: 42, jitterMs: 9 });
    const curr = makeMeasurement({ downloadMbps: 60, uploadMbps: 22, pingMs: 18, jitterMs: 3 });
    const delta = computeMeasurementDelta(curr, prev);
    assert.deepEqual(delta, {
      downloadDeltaMbps: 35,
      uploadDeltaMbps: 14,
      pingDeltaMs: -24,
      jitterDeltaMs: -6
    });
  });

  it('packs uneven rooms in 6-room grid tightly with zero horizontal gaps', () => {
    const floor6 = createFloorPlan(1, 6, 'grid', false);
    // Row 0: indices 0, 1, 2; Row 1: indices 3, 4, 5
    const [r0, r1, r2, r3, r4, r5] = floor6.rooms;
    assert.equal(r1.x, Math.round((r0.x + r0.width + WALL_GAP_M) * 10) / 10);
    assert.equal(r2.x, Math.round((r1.x + r1.width + WALL_GAP_M) * 10) / 10);
    assert.equal(r4.x, Math.round((r3.x + r3.width + WALL_GAP_M) * 10) / 10);
    assert.equal(r5.x, Math.round((r4.x + r4.width + WALL_GAP_M) * 10) / 10);
    assert.ok(verifyNoRoomOverlaps(floor6.rooms));
  });

  it('dynamically reflows sibling positions and adapts canvas bounds when resizing via resizeRoomAndReflow', () => {
    const floor = createFloorPlan(1, 4, 'grid', false); // 2x2 grid
    const r0 = floor.rooms[0];
    const r1Initial = floor.rooms[1];
    const r2Initial = floor.rooms[2];
    const origCanvasW = floor.canvasWidth;
    const origCanvasH = floor.canvasHeight;

    // Grow room 0 significantly wider and taller -> sibling r1 shifts right, r2 shifts down, canvas expands
    const grown = resizeRoomAndReflow(floor, r0.id, r0.width + 2.4, r0.height + 2.0);
    assert.equal(grown.reason, 'none');
    assert.ok(verifyNoRoomOverlaps(grown.floor.rooms));
    const r1AfterGrow = grown.floor.rooms.find((r) => r.id === r1Initial.id)!;
    const r2AfterGrow = grown.floor.rooms.find((r) => r.id === r2Initial.id)!;
    assert.equal(r1AfterGrow.x, Math.round((grown.room.x + grown.room.width + WALL_GAP_M) * 10) / 10);
    assert.equal(r2AfterGrow.y, Math.round((grown.room.y + grown.room.height + WALL_GAP_M) * 10) / 10);
    assert.ok(grown.floor.canvasWidth > origCanvasW);
    assert.ok(grown.floor.canvasHeight > origCanvasH);

    // Shrink room 0 back -> siblings pull back tightly with zero empty gap and canvas shrinks
    const shrunk = resizeRoomAndReflow(grown.floor, r0.id, MIN_ROOM_M, MIN_ROOM_M);
    assert.equal(shrunk.reason, 'none');
    assert.ok(verifyNoRoomOverlaps(shrunk.floor.rooms));
    const r1AfterShrink = shrunk.floor.rooms.find((r) => r.id === r1Initial.id)!;
    assert.equal(r1AfterShrink.x, Math.round((shrunk.room.x + MIN_ROOM_M + WALL_GAP_M) * 10) / 10);
    assert.ok(shrunk.floor.canvasWidth < grown.floor.canvasWidth);
    assert.ok(shrunk.floor.canvasHeight < grown.floor.canvasHeight);
    assert.ok(shrunk.floor.canvasWidth <= MAX_FLOOR_SPAN_M);
  });

  it('converts an L-shaped custom user sketch into an organized metric plan preserving relative topology and router pin', () => {
    const baseFloor = createFloorPlan(1, 3, 'grid', false);

    // User sketched an asymmetric L-shaped layout with minor AI bounding overlap
    const organized = organizeCustomSketchLayout(
      {
        rooms: [
          { name: 'صالة الاستقبال', category: 'living', xPct: 12, yPct: 10, wPct: 48, hPct: 38 },
          { name: 'المطبخ', category: 'kitchen', xPct: 58, yPct: 11, wPct: 30, hPct: 36 },
          { name: 'غرفة النوم', category: 'bedroom', xPct: 13, yPct: 47, wPct: 36, hPct: 38 }
        ],
        suggestedSpanMeters: { width: 12, height: 10 },
        routerPct: { detected: true, xPct: 35, yPct: 28 }
      },
      baseFloor
    );

    assert.equal(organized.floor.layoutTemplate, 'custom-sketch');
    assert.equal(organized.floor.rooms.length, 3);
    assert.ok(verifyNoRoomOverlaps(organized.floor.rooms), 'Sketch output must never overlap');

    const [living, kitchen, bedroom] = organized.floor.rooms;
    assert.equal(living.name, 'صالة الاستقبال');
    assert.equal(kitchen.name, 'المطبخ');
    assert.equal(bedroom.name, 'غرفة النوم');

    // Preserves relative L-shape spatial layout: Kitchen right of Living, Bedroom below Living & left of Kitchen
    assert.ok(kitchen.x > living.x + living.width - 0.01, 'Kitchen stays to the right of Living');
    assert.equal(living.y, kitchen.y, 'Nearly aligned top edge snaps cleanly');
    assert.ok(bedroom.y > living.y + living.height - 0.01, 'Bedroom stays below Living');
    assert.equal(bedroom.x, living.x, 'Bedroom left wing aligns cleanly under Living');

    assert.ok(organized.routerMeters, 'Router coordinates must be mapped from sketch');
    assert.ok(
      organized.routerMeters!.x >= living.x && organized.routerMeters!.x <= living.x + living.width,
      'Router X placed inside Living Room as sketched'
    );
  });

  it('preserves custom-sketch topology during resize reflow and adding rooms', () => {
    const baseFloor = createFloorPlan(1, 2, 'grid', false);
    const { floor: sketchFloor } = organizeCustomSketchLayout(
      {
        rooms: [
          { name: 'Hall', category: 'living', xPct: 10, yPct: 10, wPct: 40, hPct: 40 },
          { name: 'Study', category: 'office', xPct: 52, yPct: 10, wPct: 35, hPct: 40 },
          { name: 'Suite', category: 'bedroom', xPct: 10, yPct: 54, wPct: 40, hPct: 35 }
        ]
      },
      baseFloor
    );

    const hall = sketchFloor.rooms[0];
    const study = sketchFloor.rooms[1];
    const suite = sketchFloor.rooms[2];

    const resized = resizeRoomAndReflow(sketchFloor, hall.id, hall.width + 2.0, hall.height + 1.4);
    assert.equal(resized.reason, 'none');
    assert.ok(verifyNoRoomOverlaps(resized.floor.rooms));

    const studyAfter = resized.floor.rooms.find((r) => r.id === study.id)!;
    const suiteAfter = resized.floor.rooms.find((r) => r.id === suite.id)!;
    assert.ok(studyAfter.x > study.x, 'Right neighbor Study shifts right to accommodate Hall growth');
    assert.ok(suiteAfter.y > suite.y, 'Lower wing Suite shifts down to accommodate Hall height growth');
    assert.equal(suiteAfter.x, hall.x, 'Suite keeps L-shape left alignment instead of scrambling into grid');

    const added = addRoomToFloor(resized.floor, 'Balcony', 'custom');
    assert.equal(added.floor.rooms.length, 4);
    assert.ok(verifyNoRoomOverlaps(added.floor.rooms));
    assert.ok(packCustomTopologyRooms(added.floor.rooms).length === 4);
  });
});
