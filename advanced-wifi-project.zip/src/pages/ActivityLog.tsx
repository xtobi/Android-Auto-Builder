import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { useI18n } from '../i18n';
import { ActivityActionType } from '../services/firebaseService';

export const ActivityLog: React.FC = () => {
  const { activityLogs } = useApp();
  const { t, language } = useI18n();
  const [filterAction, setFilterAction] = useState<'all' | ActivityActionType>('all');

  const localeStr = language === 'ar' ? 'ar-EG' : language === 'fr' ? 'fr-FR' : 'en-US';
  const filtered =
    filterAction === 'all'
      ? activityLogs
      : activityLogs.filter((entry) => entry.actionType === filterAction);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#102B49] dark:text-[#EAF1F8] tracking-tight">
            {t('activity.title')}
          </h1>
          <p className="text-sm text-[#526A84] dark:text-[#93ACC6] mt-1">{t('activity.description')}</p>
        </div>

        <select
          value={filterAction}
          onChange={(e) => setFilterAction(e.target.value as 'all' | ActivityActionType)}
          aria-label={t('app.filter')}
          className="px-3.5 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#112033] text-xs font-medium text-[#102B49] dark:text-[#EAF1F8] shrink-0"
        >
          <option value="all">{t('activity.filterAll')}</option>
          {(
            [
              'wifi_ssid_change',
              'wifi_password_change',
              'wifi_settings_change',
              'device_block',
              'device_unblock',
              'speed_test',
              'diagnostics_run',
              'router_connect',
              'router_disconnect',
              'router_reboot',
              'guest_wifi_toggle',
              'internet_access_toggle'
            ] as ActivityActionType[]
          ).map((type) => (
            <option key={type} value={type}>
              {t(`activity.actions.${type}`)}
            </option>
          ))}
        </select>
      </div>

      <div className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl overflow-hidden">
        {filtered.length === 0 ? (
          <p className="p-8 text-center text-sm text-[#526A84] dark:text-[#93ACC6]">{t('activity.empty')}</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-[#F4F7FB] dark:bg-[#0B1522] text-xs text-[#526A84] dark:text-[#93ACC6]">
                <tr>
                  <th className="px-5 py-3 text-start font-medium">{t('activity.date')}</th>
                  <th className="px-5 py-3 text-start font-medium">{t('activity.action')}</th>
                  <th className="px-5 py-3 text-start font-medium">{t('activity.target')}</th>
                  <th className="px-5 py-3 text-start font-medium">{t('activity.result')}</th>
                  <th className="px-5 py-3 text-start font-medium">{t('activity.details')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#DCE5F0] dark:divide-[#1F354F]">
                {filtered.map((entry) => (
                  <tr key={entry.id}>
                    <td className="px-5 py-3 font-mono-tabular text-xs text-[#526A84] dark:text-[#93ACC6] whitespace-nowrap">
                      {new Intl.DateTimeFormat(localeStr, {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      }).format(new Date(entry.createdAtIso))}
                    </td>
                    <td className="px-5 py-3 font-medium text-[#102B49] dark:text-[#EAF1F8] whitespace-nowrap">
                      {t(`activity.actions.${entry.actionType}`)}
                    </td>
                    <td className="px-5 py-3 font-mono-tabular text-xs text-[#102B49] dark:text-[#EAF1F8]">
                      {entry.target}
                    </td>
                    <td className="px-5 py-3 text-xs font-medium whitespace-nowrap">
                      <span
                        className={
                          entry.status === 'success'
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : entry.status === 'failure'
                            ? 'text-red-600 dark:text-red-400'
                            : 'text-[#3989C9]'
                        }
                      >
                        {t(`activity.statuses.${entry.status}`)}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-xs text-[#526A84] dark:text-[#93ACC6]">
                      {entry.details}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
