import React, { useEffect, useState } from 'react';
import { LogIn, LogOut, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { LanguageCode, useI18n } from '../i18n';
import { clearSavedRouterCredentials, hasSavedRouterCredentials } from '../utils/cryptoStore';

export const Account: React.FC = () => {
  const {
    user,
    userProfile,
    signOut,
    setPage,
    theme,
    setTheme,
    changeLanguage,
    updateSessionTimeout
  } = useApp();
  const { language, t } = useI18n();

  const [hasSavedCreds, setHasSavedCreds] = useState(false);
  const [deletedMsg, setDeletedMsg] = useState(false);

  useEffect(() => {
    void hasSavedRouterCredentials().then(setHasSavedCreds);
  }, []);

  const handleDeleteCreds = async () => {
    await clearSavedRouterCredentials();
    setHasSavedCreds(false);
    setDeletedMsg(true);
    setTimeout(() => setDeletedMsg(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold text-[#102B49] dark:text-[#EAF1F8] tracking-tight">
          {t('account.title')}
        </h1>
        <p className="text-sm text-[#526A84] dark:text-[#93ACC6] mt-1">{t('account.description')}</p>
      </div>

      {/* Google Profile Section */}
      <section className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-4">
        <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
          {t('account.profileSection')}
        </h2>

        {!user ? (
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <p className="text-sm text-[#526A84] dark:text-[#93ACC6]">{t('account.notSignedIn')}</p>
            <button
              type="button"
              onClick={() => setPage('login')}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-medium whitespace-nowrap shrink-0"
            >
              <LogIn className="w-4 h-4" aria-hidden="true" />
              <span>{t('account.goToLogin')}</span>
            </button>
          </div>
        ) : (
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4 min-w-0">
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.displayName || 'User'}
                  referrerPolicy="no-referrer"
                  className="w-12 h-12 rounded-full object-cover border border-[#DCE5F0] dark:border-[#1F354F] shrink-0"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-[#174C78] text-white flex items-center justify-center text-base font-semibold shrink-0">
                  {(user.displayName || user.email || 'U').slice(0, 1).toUpperCase()}
                </div>
              )}
              <div className="min-w-0">
                <div className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8] truncate">
                  {user.displayName || userProfile?.displayName}
                </div>
                <div className="text-xs text-[#526A84] dark:text-[#93ACC6] truncate">{user.email}</div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => void signOut()}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] text-sm font-medium text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] whitespace-nowrap shrink-0"
            >
              <LogOut className="w-4 h-4" aria-hidden="true" />
              <span>{t('account.signOut')}</span>
            </button>
          </div>
        )}

        <p className="text-xs text-[#526A84] dark:text-[#93ACC6] pt-2 border-t border-[#DCE5F0] dark:border-[#1F354F]">
          {t('account.googleVsRouterNote')}
        </p>
      </section>

      {/* Preferences Section */}
      <section className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-4">
        <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
          {t('account.preferencesSection')}
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label htmlFor="pref-lang" className="block text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
              {t('app.language')}
            </label>
            <select
              id="pref-lang"
              value={language}
              onChange={(e) => changeLanguage(e.target.value as LanguageCode)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm text-[#102B49] dark:text-[#EAF1F8]"
            >
              <option value="ar">العربية (RTL)</option>
              <option value="en">English (LTR)</option>
              <option value="fr">Français (LTR)</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label htmlFor="pref-theme" className="block text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
              {theme === 'dark' ? t('app.darkMode') : t('app.lightMode')}
            </label>
            <select
              id="pref-theme"
              value={theme}
              onChange={(e) => setTheme(e.target.value as 'light' | 'dark')}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm text-[#102B49] dark:text-[#EAF1F8]"
            >
              <option value="light">{t('app.lightMode')}</option>
              <option value="dark">{t('app.darkMode')}</option>
            </select>
          </div>
        </div>
      </section>

      {/* Security & Saved Credentials */}
      <section className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-4">
        <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
          {t('account.securitySection')}
        </h2>

        <div className="space-y-1.5 max-w-xs">
          <label htmlFor="session-timeout" className="block text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
            {t('account.sessionTimeoutLabel')}
          </label>
          <select
            id="session-timeout"
            value={userProfile?.sessionTimeoutMinutes ?? 30}
            onChange={(e) => void updateSessionTimeout(Number(e.target.value))}
            className="w-full px-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm font-mono-tabular text-[#102B49] dark:text-[#EAF1F8]"
          >
            <option value={15}>15</option>
            <option value={30}>30</option>
            <option value={60}>60</option>
            <option value={240}>240</option>
          </select>
        </div>

        <div className="pt-4 border-t border-[#DCE5F0] dark:border-[#1F354F] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="text-sm font-medium text-[#102B49] dark:text-[#EAF1F8]">
              {t('account.savedRouterCreds')}
            </div>
            <div className="text-xs text-[#526A84] dark:text-[#93ACC6]">
              {deletedMsg
                ? t('router.deletedSavedNotice')
                : hasSavedCreds
                ? t('account.savedRouterCredsPresent')
                : t('account.savedRouterCredsNone')}
            </div>
          </div>

          {hasSavedCreds && (
            <button
              type="button"
              onClick={() => void handleDeleteCreds()}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-red-300 dark:border-red-800 text-red-700 dark:text-red-300 text-xs font-medium hover:bg-red-50 dark:hover:bg-red-950/30 whitespace-nowrap shrink-0"
            >
              <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t('account.deleteSavedCreds')}</span>
            </button>
          )}
        </div>
      </section>
    </div>
  );
};
