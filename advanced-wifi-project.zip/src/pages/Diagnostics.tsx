import React, { useState } from 'react';
import { AlertCircle, CheckCircle2, HelpCircle, Info, Play, RefreshCw, Router, XCircle } from 'lucide-react';
import { HUAWEI_DEFAULT_GATEWAY } from '../core/fallbackManager';
import { useApp } from '../context/AppContext';
import { useI18n } from '../i18n';
import { ModemDiagnosticOutcome, RouterAdapterId } from '../router-adapters/types';
import { DiagnosticItem } from '../services/diagnostics';

export const Diagnostics: React.FC = () => {
  const {
    diagnosticsReport,
    runDiagnosticsCheck,
    modemDiagnosticsReport,
    runningModemDiagnostics,
    runModemProtocolCheck,
    routerSession,
    nativeEnv,
    isNativeAndroid,
    simulationMode
  } = useApp();
  const { t, language } = useI18n();
  const localeStr = language === 'ar' ? 'ar-EG' : language === 'fr' ? 'fr-FR' : 'en-US';

  const [probeGateway, setProbeGateway] = useState(
    routerSession?.routerInfo.gatewayIp || nativeEnv?.gatewayIp || HUAWEI_DEFAULT_GATEWAY
  );
  const [probeAdapter, setProbeAdapter] = useState<RouterAdapterId | 'auto'>(
    routerSession?.adapter.id || 'huawei-hg8145x6-10'
  );
  const [probeUsername, setProbeUsername] = useState('admin');
  const [probePassword, setProbePassword] = useState('');

  const handleRunModemProbe = async (e: React.FormEvent) => {
    e.preventDefault();
    await runModemProtocolCheck({
      rawAddress: probeGateway,
      preferredAdapterId: probeAdapter,
      credentials: {
        username: probeUsername,
        password: probePassword || (simulationMode && !isNativeAndroid ? 'admin' : '')
      },
      transportMode:
        simulationMode && !isNativeAndroid
          ? 'simulation'
          : isNativeAndroid
          ? 'native_bridge'
          : routerSession?.transportMode
    });
  };

  const renderOutcomeBadge = (outcome: ModemDiagnosticOutcome) => {
    if (outcome === 'passed' || outcome === 'supported') {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400">
          <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>{t(`diagnostics.outcomes.${outcome}`)}</span>
        </span>
      );
    }
    if (outcome === 'failed' || outcome === 'unsupported') {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-red-600 dark:text-red-400">
          <XCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>{t(`diagnostics.outcomes.${outcome}`)}</span>
        </span>
      );
    }
    if (outcome === 'unknown') {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 dark:text-amber-400">
          <HelpCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>{t(`diagnostics.outcomes.${outcome}`)}</span>
        </span>
      );
    }
    return (
      <span className="text-xs text-[#526A84] dark:text-[#93ACC6]">
        {t(`diagnostics.outcomes.${outcome}`)}
      </span>
    );
  };

  const renderSection = (
    title: string,
    items: DiagnosticItem[],
    emptyText: string | null,
    Icon: React.ComponentType<{ className?: string }>,
    iconClass: string
  ) => (
    <section className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-4">
      <div className="flex items-center gap-2.5">
        <Icon className={`w-5 h-5 ${iconClass}`} aria-hidden="true" />
        <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">{title}</h2>
      </div>

      {items.length === 0 ? (
        emptyText && <p className="text-sm text-[#526A84] dark:text-[#93ACC6]">{emptyText}</p>
      ) : (
        <div className="divide-y divide-[#DCE5F0] dark:divide-[#1F354F]">
          {items.map((item) => (
            <div key={item.id} className="py-4 first:pt-1 last:pb-1 space-y-1.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                  {t(item.titleKey)}
                </h3>
                <span className="text-xs font-mono-tabular text-[#526A84] dark:text-[#93ACC6]">
                  {t('diagnostics.evidenceLabel')}: {item.evidenceText}
                </span>
              </div>
              <p className="text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed">
                <span className="font-medium text-[#174C78] dark:text-[#6BB3EB]">
                  {t('diagnostics.recommendationLabel')}:{' '}
                </span>
                {t(item.recommendationKey)}
              </p>
            </div>
          ))}
        </div>
      )}
    </section>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#102B49] dark:text-[#EAF1F8] tracking-tight">
            {t('diagnostics.title')}
          </h1>
          <p className="text-sm text-[#526A84] dark:text-[#93ACC6] mt-1">{t('diagnostics.description')}</p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <span className="text-xs text-[#526A84] dark:text-[#93ACC6] font-mono-tabular">
            {t('diagnostics.lastChecked')}:{' '}
            {new Intl.DateTimeFormat(localeStr, { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(
              new Date(diagnosticsReport.analyzedAtIso)
            )}
          </span>
          <button
            type="button"
            onClick={() => void runDiagnosticsCheck()}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-medium transition-colors whitespace-nowrap"
          >
            <RefreshCw className="w-4 h-4" aria-hidden="true" />
            <span>{t('diagnostics.runCheck')}</span>
          </button>
        </div>
      </div>

      {/* 10-Stage Modem Protocol Diagnostics (On-Device LAN / APK Verification) */}
      <section className="bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-start gap-3">
            <Router className="w-5 h-5 text-[#174C78] dark:text-[#6BB3EB] mt-0.5 shrink-0" aria-hidden="true" />
            <div>
              <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                {t('diagnostics.modemTitle')}
              </h2>
              <p className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-1">
                {t('diagnostics.modemDesc')}
              </p>
            </div>
          </div>
          <span className="text-xs font-medium text-[#174C78] dark:text-[#6BB3EB] shrink-0">
            {simulationMode && !isNativeAndroid
              ? t('diagnostics.modemModeSimNote')
              : t('diagnostics.modemModeRealNote')}
          </span>
        </div>

        <form onSubmit={(e) => void handleRunModemProbe(e)} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
          <div className="space-y-1">
            <label htmlFor="diag-gw" className="block text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
              {t('router.routerIpLabel')}
            </label>
            <input
              id="diag-gw"
              type="text"
              value={probeGateway}
              onChange={(e) => setProbeGateway(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-xs font-mono-tabular text-[#102B49] dark:text-[#EAF1F8]"
            />
          </div>

          <div className="space-y-1">
            <label htmlFor="diag-adapter" className="block text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
              {t('router.adapterLabel')}
            </label>
            <select
              id="diag-adapter"
              value={probeAdapter}
              onChange={(e) => setProbeAdapter(e.target.value as RouterAdapterId | 'auto')}
              className="w-full px-3 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-xs text-[#102B49] dark:text-[#EAF1F8]"
            >
              <option value="huawei-hg8145x6-10">Huawei OptiXstar HG8145X6-10</option>
              <option value="auto">{t('router.autoDetect')}</option>
              <option value="huawei">Huawei (Generic / HiLink)</option>
            </select>
          </div>

          <div className="space-y-1">
            <label htmlFor="diag-user" className="block text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
              {t('router.usernameLabel')}
            </label>
            <input
              id="diag-user"
              type="text"
              value={probeUsername}
              onChange={(e) => setProbeUsername(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-xs text-[#102B49] dark:text-[#EAF1F8]"
            />
          </div>

          <div className="space-y-1">
            <label htmlFor="diag-pass" className="block text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
              {t('router.passwordLabel')}
            </label>
            <input
              id="diag-pass"
              type="password"
              value={probePassword}
              onChange={(e) => setProbePassword(e.target.value)}
              placeholder={simulationMode && !isNativeAndroid ? 'admin' : t('router.passwordPlaceholder')}
              className="w-full px-3 py-2 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-xs text-[#102B49] dark:text-[#EAF1F8]"
            />
          </div>

          <button
            type="submit"
            disabled={runningModemDiagnostics}
            className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-xs font-medium transition-colors disabled:opacity-60 whitespace-nowrap h-[34px]"
          >
            <Play className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{runningModemDiagnostics ? t('diagnostics.runningModemDiag') : t('diagnostics.runModemDiag')}</span>
          </button>
        </form>

        {modemDiagnosticsReport && (
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#526A84] dark:text-[#93ACC6] font-mono-tabular">
              <span dir="ltr">
                {modemDiagnosticsReport.targetUrl} · {modemDiagnosticsReport.adapterId} · {modemDiagnosticsReport.transportMode}
                {modemDiagnosticsReport.detectedModel ? ` · ${modemDiagnosticsReport.detectedModel}` : ''}
              </span>
              <span>
                {new Intl.DateTimeFormat(localeStr, { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(
                  new Date(modemDiagnosticsReport.checkedAtIso)
                )}
              </span>
            </div>

            <div className="overflow-x-auto border border-[#DCE5F0] dark:border-[#1F354F] rounded-xl">
              <table className="w-full text-start text-xs">
                <thead className="bg-[#F4F7FB] dark:bg-[#0B1522] text-[#526A84] dark:text-[#93ACC6]">
                  <tr>
                    <th className="px-4 py-2.5 text-start font-medium">{t('diagnostics.stageCol')}</th>
                    <th className="px-4 py-2.5 text-start font-medium">{t('diagnostics.outcomeCol')}</th>
                    <th className="px-4 py-2.5 text-start font-medium">{t('diagnostics.httpCol')}</th>
                    <th className="px-4 py-2.5 text-start font-medium">{t('diagnostics.detailCol')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#DCE5F0] dark:divide-[#1F354F]">
                  {modemDiagnosticsReport.stages.map((stage) => (
                    <tr key={stage.id} className="hover:bg-[#F4F7FB]/50 dark:hover:bg-[#172B42]/30">
                      <td className="px-4 py-2.5 font-medium text-[#102B49] dark:text-[#EAF1F8] whitespace-nowrap">
                        {t(`diagnostics.stages.${stage.id}`)}
                      </td>
                      <td className="px-4 py-2.5 whitespace-nowrap">
                        {renderOutcomeBadge(stage.outcome)}
                      </td>
                      <td dir="ltr" className="px-4 py-2.5 font-mono-tabular text-start text-[#526A84] dark:text-[#93ACC6] whitespace-nowrap">
                        {stage.httpStatus ? `HTTP ${stage.httpStatus}` : '—'}
                        {stage.endpoint ? ` · ${stage.endpoint}` : ''}
                        {stage.latencyMs != null ? ` (${stage.latencyMs}ms)` : ''}
                      </td>
                      <td dir="ltr" className="px-4 py-2.5 font-mono-tabular text-start text-[#526A84] dark:text-[#93ACC6]">
                        {stage.technicalDetail || '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </section>

      {renderSection(
        t('diagnostics.confirmedTitle'),
        diagnosticsReport.confirmed,
        t('diagnostics.noConfirmed'),
        AlertCircle,
        'text-red-600 dark:text-red-400'
      )}

      {renderSection(
        t('diagnostics.possibleTitle'),
        diagnosticsReport.possible,
        t('diagnostics.noPossible'),
        HelpCircle,
        'text-amber-600 dark:text-amber-400'
      )}

      {diagnosticsReport.unavailable.length > 0 &&
        renderSection(
          t('diagnostics.unavailableTitle'),
          diagnosticsReport.unavailable,
          null,
          Info,
          'text-[#3989C9]'
        )}
    </div>
  );
};

