import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  Check,
  CheckCircle2,
  Copy,
  Download,
  Eye,
  EyeOff,
  Power,
  RefreshCw,
  Router,
  ShieldCheck,
  Smartphone,
  Terminal
} from 'lucide-react';
import connectorScriptRaw from '../../local-connector/server.mjs?raw';
import { useApp } from '../context/AppContext';
import { useI18n } from '../i18n';
import { CONNECTOR_BASE_URL } from '../services/routerConnection';

type GuidePlatform = 'android' | 'desktop';

export const LocalConnectorSetup: React.FC = () => {
  const {
    connectorToken,
    setConnectorToken,
    connectorHealth,
    connectorChecking,
    refreshConnectorStatus,
    stopConnector,
    setPage
  } = useApp();
  const { t } = useI18n();

  const [guideTab, setGuideTab] = useState<GuidePlatform>(() => {
    if (typeof navigator !== 'undefined' && /android/i.test(navigator.userAgent)) {
      return 'android';
    }
    return 'android';
  });
  const [showToken, setShowToken] = useState(false);
  const [downloadedScript, setDownloadedScript] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [actionMsg, setActionMsg] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [stopping, setStopping] = useState(false);

  useEffect(() => {
    void refreshConnectorStatus();
  }, [refreshConnectorStatus]);

  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : '';

  const copyCommand = async (id: string, cmd: string) => {
    try {
      await navigator.clipboard.writeText(cmd);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1800);
    } catch {
      // Clipboard unavailable
    }
  };

  const handleDownloadScript = () => {
    const blob = new Blob([connectorScriptRaw], { type: 'text/javascript;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'server.mjs';
    a.click();
    URL.revokeObjectURL(url);
    setDownloadedScript(true);
  };

  const handleVerifyConnection = async () => {
    setActionMsg(null);
    const status = await refreshConnectorStatus(connectorToken);
    if (!status.reachable) {
      setActionMsg({ type: 'error', text: t('localConnector.msgServerUnreachable') });
    } else if (status.originBlocked) {
      setActionMsg({ type: 'error', text: t('localConnector.msgOriginBlocked') });
    } else if (!status.authVerified) {
      setActionMsg({ type: 'error', text: t('localConnector.msgTokenNeeded') });
    } else {
      setActionMsg({ type: 'success', text: t('localConnector.msgConnectedSuccess') });
    }
  };

  const handleStopServer = async () => {
    setStopping(true);
    setActionMsg(null);
    try {
      const ok = await stopConnector();
      if (ok) {
        setActionMsg({ type: 'info', text: t('localConnector.msgStoppedSuccess') });
      } else {
        setActionMsg({ type: 'error', text: t('localConnector.msgStopFailed') });
      }
    } finally {
      setStopping(false);
    }
  };

  const renderCmdBox = (id: string, command: string) => (
    <div
      dir="ltr"
      className="w-full max-w-full min-w-0 p-3 rounded-xl bg-[#0B1522] text-[#EAF1F8] font-mono-tabular text-xs flex items-center justify-between gap-2 overflow-hidden"
    >
      <code className="flex-1 min-w-0 overflow-x-auto whitespace-nowrap py-0.5">{command}</code>
      <button
        type="button"
        onClick={() => void copyCommand(id, command)}
        aria-label={t('app.copy')}
        className="p-1.5 rounded-lg hover:bg-white/10 text-white shrink-0"
      >
        {copiedId === id ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
      </button>
    </div>
  );

  const serverStatusText = connectorChecking
    ? t('app.loading')
    : !connectorHealth.reachable
    ? t('localConnector.statusNotRunning')
    : connectorHealth.originBlocked
    ? t('localConnector.statusOriginBlocked')
    : connectorHealth.authVerified
    ? t('localConnector.statusConnectedAuth')
    : t('localConnector.statusNeedsToken');

  const serverStatusClass = connectorHealth.reachable && connectorHealth.authVerified
    ? 'text-emerald-700 dark:text-emerald-400'
    : connectorHealth.reachable
    ? 'text-amber-700 dark:text-amber-400'
    : 'text-red-600 dark:text-red-400';

  const androidInstallCmd = 'pkg update && pkg upgrade -y && pkg install nodejs-lts -y';
  const androidCopyCmd = 'termux-setup-storage && mkdir -p ~/aw-connector && cp ~/storage/downloads/server.mjs ~/aw-connector/server.mjs';
  const androidRunCmd = 'termux-wake-lock && node ~/aw-connector/server.mjs';
  const androidStopCmd = 'pkill -f server.mjs';
  const desktopRunCmd = 'node local-connector/server.mjs';

  return (
    <div className="space-y-6 min-w-0 max-w-full">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 min-w-0">
        <div className="min-w-0">
          <h1 className="text-2xl font-bold text-[#102B49] dark:text-[#EAF1F8] tracking-tight">
            {t('localConnector.title')}
          </h1>
          <p className="text-sm text-[#526A84] dark:text-[#93ACC6] mt-1 max-w-3xl">
            {t('localConnector.subtitle')}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => void handleVerifyConnection()}
            disabled={connectorChecking}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-medium transition-colors disabled:opacity-60 whitespace-nowrap"
          >
            <RefreshCw className={`w-4 h-4 ${connectorChecking ? 'animate-spin' : ''}`} aria-hidden="true" />
            <span>{t('localConnector.verifyButton')}</span>
          </button>

          <button
            type="button"
            onClick={() => setPage('router-connection')}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#112033] text-[#102B49] dark:text-[#EAF1F8] hover:bg-[#F4F7FB] dark:hover:bg-[#182C44] text-sm font-medium transition-colors whitespace-nowrap"
          >
            <Router className="w-4 h-4" aria-hidden="true" />
            <span>{t('nav.routerConnection')}</span>
          </button>
        </div>
      </div>

      {/* Live Status Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 min-w-0">
        <div className="min-w-0 bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-1.5">
          <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
            {t('localConnector.serverStatusLabel')}
          </div>
          <div className={`text-sm font-semibold flex items-center gap-2 ${serverStatusClass}`}>
            {connectorHealth.reachable && connectorHealth.authVerified ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
            )}
            <span>{serverStatusText}</span>
          </div>
          <p className="text-xs text-[#526A84] dark:text-[#93ACC6]">
            {connectorHealth.reachable && connectorHealth.nodeVersion
              ? `Node ${connectorHealth.nodeVersion} · ${connectorHealth.platform}/${connectorHealth.arch}`
              : t('localConnector.zeroDepNote')}
          </p>
        </div>

        <div className="min-w-0 bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-1.5">
          <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
            {t('localConnector.installStatusLabel')}
          </div>
          <div className="text-sm font-semibold text-[#102B49] dark:text-[#EAF1F8]">
            {connectorHealth.reachable
              ? t('localConnector.installedRunning')
              : downloadedScript
              ? t('localConnector.scriptDownloaded')
              : t('localConnector.readyToDownload')}
          </div>
          <button
            type="button"
            onClick={handleDownloadScript}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#3989C9] hover:underline pt-0.5"
          >
            <Download className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{t('localConnector.downloadScriptButton')}</span>
          </button>
        </div>

        <div className="min-w-0 bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-5 space-y-1.5">
          <div className="text-xs font-medium text-[#526A84] dark:text-[#93ACC6]">
            {t('localConnector.localAddressLabel')}
          </div>
          <div className="text-sm font-semibold font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] break-all">
            {CONNECTOR_BASE_URL}
          </div>
          <p className="text-xs text-[#526A84] dark:text-[#93ACC6] truncate" title={currentOrigin}>
            {t('localConnector.originPolicyLabel')}: {currentOrigin || 'localhost'}
          </p>
        </div>
      </div>

      {/* Token Pairing & Controls */}
      <section className="min-w-0 bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#3989C9]" aria-hidden="true" />
              <span>{t('localConnector.pairingTitle')}</span>
            </h2>
            <p className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-1">
              {t('localConnector.pairingSubtitle')}
            </p>
          </div>
        </div>

        {actionMsg && (
          <div
            className={`p-3.5 rounded-xl text-sm border ${
              actionMsg.type === 'success'
                ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                : actionMsg.type === 'error'
                ? 'bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200'
                : 'bg-[#EAF3FB] dark:bg-[#172B42] border-[#3989C9]/40 text-[#102B49] dark:text-[#EAF1F8]'
            }`}
          >
            {actionMsg.text}
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <label htmlFor="connector-token-input" className="sr-only">
              {t('localConnector.tokenLabel')}
            </label>
            <input
              id="connector-token-input"
              type={showToken ? 'text' : 'password'}
              value={connectorToken}
              onChange={(e) => setConnectorToken(e.target.value)}
              placeholder={t('localConnector.tokenPlaceholder')}
              autoComplete="off"
              className="w-full pe-10 ps-3.5 py-2.5 rounded-xl border border-[#DCE5F0] dark:border-[#1F354F] bg-white dark:bg-[#0B1522] text-sm font-mono-tabular text-[#102B49] dark:text-[#EAF1F8] focus:outline-none focus:ring-2 focus:ring-[#3989C9]"
            />
            <button
              type="button"
              onClick={() => setShowToken(!showToken)}
              aria-label={showToken ? t('wifi.hidePassword') : t('wifi.showPassword')}
              className="absolute inset-y-0 end-0 px-3 flex items-center text-[#526A84] hover:text-[#102B49] dark:hover:text-white"
            >
              {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          <button
            type="button"
            onClick={() => void handleVerifyConnection()}
            disabled={connectorChecking}
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-sm font-medium transition-colors disabled:opacity-60 whitespace-nowrap shrink-0"
          >
            <RefreshCw className={`w-4 h-4 ${connectorChecking ? 'animate-spin' : ''}`} aria-hidden="true" />
            <span>{t('localConnector.verifyButton')}</span>
          </button>

          {connectorHealth.reachable && connectorHealth.authVerified && (
            <button
              type="button"
              onClick={() => void handleStopServer()}
              disabled={stopping}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-red-300 dark:border-red-800 text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/30 text-sm font-medium transition-colors whitespace-nowrap shrink-0"
            >
              <Power className="w-4 h-4" aria-hidden="true" />
              <span>{t('localConnector.stopServerButton')}</span>
            </button>
          )}
        </div>

        <p className="text-xs text-[#526A84] dark:text-[#93ACC6]">
          {t('localConnector.securityNote')}
        </p>
      </section>

      {/* Beginner-Friendly Setup Instructions (Android Termux & Desktop) */}
      <section className="min-w-0 bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 min-w-0">
          <div className="min-w-0">
            <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
              {t('localConnector.guideTitle')}
            </h2>
            <p className="text-xs text-[#526A84] dark:text-[#93ACC6] mt-0.5">
              {t('localConnector.guideSubtitle')}
            </p>
          </div>

          <div
            className="inline-flex flex-wrap max-w-full p-1 rounded-xl bg-[#F4F7FB] dark:bg-[#0B1522] border border-[#DCE5F0] dark:border-[#1F354F] self-start gap-1"
            role="group"
            aria-label={t('localConnector.platformLabel')}
          >
            <button
              type="button"
              onClick={() => setGuideTab('android')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                guideTab === 'android'
                  ? 'bg-[#174C78] text-white'
                  : 'text-[#526A84] dark:text-[#93ACC6] hover:text-[#102B49] dark:hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              <span>{t('localConnector.tabAndroid')}</span>
            </button>
            <button
              type="button"
              onClick={() => setGuideTab('desktop')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                guideTab === 'desktop'
                  ? 'bg-[#174C78] text-white'
                  : 'text-[#526A84] dark:text-[#93ACC6] hover:text-[#102B49] dark:hover:text-white'
              }`}
            >
              <Terminal className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              <span>{t('localConnector.tabDesktop')}</span>
            </button>
          </div>
        </div>

        {guideTab === 'android' ? (
          <div className="space-y-4">
            <div className="space-y-2 py-2 border-b border-[#DCE5F0] dark:border-[#1F354F]">
              <h3 className="text-sm font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                {t('localConnector.step1Title')}
              </h3>
              <p className="text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed">
                {t('localConnector.step1Body')}
              </p>
            </div>

            <div className="space-y-2 py-2 border-b border-[#DCE5F0] dark:border-[#1F354F]">
              <h3 className="text-sm font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                {t('localConnector.step2Title')}
              </h3>
              <p className="text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed">
                {t('localConnector.step2Body')}
              </p>
              {renderCmdBox('android-install', androidInstallCmd)}
            </div>

            <div className="space-y-2 py-2 border-b border-[#DCE5F0] dark:border-[#1F354F]">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                  {t('localConnector.step3Title')}
                </h3>
                <button
                  type="button"
                  onClick={handleDownloadScript}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#174C78] hover:bg-[#102B49] text-white text-xs font-medium whitespace-nowrap"
                >
                  <Download className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{t('localConnector.downloadScriptButton')}</span>
                </button>
              </div>
              <p className="text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed">
                {t('localConnector.step3Body')}
              </p>
              {renderCmdBox('android-copy', androidCopyCmd)}
            </div>

            <div className="space-y-2 py-2 border-b border-[#DCE5F0] dark:border-[#1F354F]">
              <h3 className="text-sm font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                {t('localConnector.step4Title')}
              </h3>
              <p className="text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed">
                {t('localConnector.step4Body')}
              </p>
              {renderCmdBox('android-run', androidRunCmd)}
            </div>

            <div className="space-y-2 py-2">
              <h3 className="text-sm font-semibold text-[#102B49] dark:text-[#EAF1F8]">
                {t('localConnector.step5Title')}
              </h3>
              <p className="text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed">
                {t('localConnector.step5Body')}
              </p>
              {renderCmdBox('android-stop', androidStopCmd)}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed">
              {t('localConnector.desktopIntro')}
            </p>
            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={handleDownloadScript}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#174C78] hover:bg-[#102B49] text-white text-xs font-medium whitespace-nowrap"
              >
                <Download className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{t('localConnector.downloadScriptButton')}</span>
              </button>
            </div>
            {renderCmdBox('desktop-run', desktopRunCmd)}
            <p className="text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed">
              {t('localConnector.desktopStopRestart')}
            </p>
          </div>
        )}
      </section>

      {/* Android Stability & Troubleshooting */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6 min-w-0">
        <div className="min-w-0 bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-3">
          <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
            {t('localConnector.stabilityTitle')}
          </h2>
          <ul className="space-y-2 text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed list-disc ps-5">
            <li>{t('localConnector.stabilityBullet1')}</li>
            <li>{t('localConnector.stabilityBullet2')}</li>
            <li>{t('localConnector.stabilityBullet3')}</li>
          </ul>
        </div>

        <div className="min-w-0 bg-white dark:bg-[#112033] border border-[#DCE5F0] dark:border-[#1F354F] rounded-2xl p-6 space-y-3">
          <h2 className="text-base font-semibold text-[#102B49] dark:text-[#EAF1F8]">
            {t('localConnector.troubleshootingTitle')}
          </h2>
          <ul className="space-y-2 text-xs text-[#526A84] dark:text-[#93ACC6] leading-relaxed list-disc ps-5">
            <li>{t('localConnector.trouble1')}</li>
            <li>{t('localConnector.trouble2')}</li>
            <li>{t('localConnector.trouble3')}</li>
          </ul>
        </div>
      </section>
    </div>
  );
};
