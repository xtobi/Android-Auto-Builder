import { asusAdapter } from './asus';
import { dlinkAdapter } from './d-link';
import { fiberhomeAdapter } from './fiberhome';
import { genericAdapter } from './generic';
import { huaweiAdapter } from './huawei';
import { huaweiHg8145x6Adapter } from './huawei-hg8145x6-10';
import { netgearAdapter } from './netgear';
import { nokiaAdapter } from './nokia';
import { tendaAdapter } from './tenda';
import { tpLinkAdapter } from './tp-link';
import { ProbeSnapshot, RouterAdapter, RouterAdapterId } from './types';
import { zteAdapter } from './zte';

export const ROUTER_ADAPTERS: RouterAdapter[] = [
  huaweiHg8145x6Adapter,
  huaweiAdapter,
  tpLinkAdapter,
  zteAdapter,
  nokiaAdapter,
  dlinkAdapter,
  tendaAdapter,
  asusAdapter,
  netgearAdapter,
  fiberhomeAdapter,
  genericAdapter
];

export function getAdapterById(id: RouterAdapterId): RouterAdapter {
  return ROUTER_ADAPTERS.find((a) => a.id === id) ?? genericAdapter;
}

export function detectBestAdapter(probe: ProbeSnapshot): { adapter: RouterAdapter; score: number } {
  let best = genericAdapter;
  let bestScore = -1;
  for (const adapter of ROUTER_ADAPTERS) {
    if (adapter.id === 'generic') continue;
    const score = adapter.detectScore(probe);
    if (score > bestScore) {
      bestScore = score;
      best = adapter;
    }
  }
  if (bestScore < 30) {
    return { adapter: genericAdapter, score: genericAdapter.detectScore(probe) };
  }
  return { adapter: best, score: bestScore };
}
