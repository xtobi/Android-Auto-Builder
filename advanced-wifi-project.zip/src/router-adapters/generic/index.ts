import {
  ProbeSnapshot,
  RouterAdapter,
  RouterConnectionContext,
  RouterError,
  RouterInfo,
  WifiSettings
} from '../types';

/**
 * Generic Gateway Probe Adapter:
 * Strictly honest fallback when a router is reachable on LAN HTTP/HTTPS
 * but does not match a verified vendor control protocol.
 * Never fabricates Wi-Fi settings, connected devices, or control success.
 */
export const genericAdapter: RouterAdapter = {
  id: 'generic',
  vendor: 'Generic / Unrecognized Gateway',
  supportedModels: ['HTTP/HTTPS Gateway Probe Only'],
  firmwareHints: ['Standard Web Interface'],
  authMethod: 'Gateway Detection Only (Control Unsupported)',
  defaultGateways: ['192.168.1.1', '192.168.0.1'],
  capabilities: {
    readRouterInfo: true,
    readWifiSettings: false,
    writeWifiSettings: false,
    readWifiPassword: false,
    dualBand24: false,
    dualBand5: false,
    toggleWifiRadio: false,
    listDevices: false,
    blockMacDevice: false,
    unblockMacDevice: false,
    readSignalStats: false,
    readChannelInfo: false,
    rebootRouter: false,
    guestWifi: false,
    blockAllInternet: false,
    supportedEncryptions: []
  },

  detectScore(probe: ProbeSnapshot): number {
    return probe.rootStatus > 0 && probe.rootStatus < 500 ? 10 : 0;
  },

  async connect(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({ method: 'GET', path: '/' });
    if (res.status === 0 || res.status >= 500) {
      throw new RouterError('ROUTER_OFFLINE');
    }
    throw new RouterError('UNSUPPORTED_MODEL', 'No verified vendor adapter matched this gateway');
  },

  async authenticate(): Promise<void> {
    throw new RouterError('UNSUPPORTED_MODEL');
  },

  async getRouterInfo(ctx: RouterConnectionContext): Promise<RouterInfo> {
    return {
      vendor: 'Generic',
      model: 'Unrecognized Gateway',
      firmwareVersion: null,
      gatewayIp: new URL(ctx.baseUrl).hostname,
      wanConnected: null,
      uptimeSeconds: null,
      signalStrengthDbm: null,
      channelCongestionScore: null
    };
  },

  async getWifiSettings(): Promise<WifiSettings> {
    return { band24: null, band5: null };
  },

  async updateWifiSettings(): Promise<void> {
    throw new RouterError('UNSUPPORTED_MODEL');
  },

  async getConnectedDevices() {
    return { connected: [], blockedMacs: [] };
  },

  async blockDevice(): Promise<void> {
    throw new RouterError('UNSUPPORTED_MODEL');
  },

  async unblockDevice(): Promise<void> {
    throw new RouterError('UNSUPPORTED_MODEL');
  },

  async rebootRouter(): Promise<void> {
    throw new RouterError('UNSUPPORTED_MODEL');
  },

  async setGuestWifiEnabled(): Promise<void> {
    throw new RouterError('UNSUPPORTED_MODEL');
  },

  async setInternetAccessPaused(): Promise<void> {
    throw new RouterError('UNSUPPORTED_MODEL');
  },

  async disconnect(): Promise<void> {
    return;
  }
};
