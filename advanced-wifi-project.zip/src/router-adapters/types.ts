export type RouterAdapterId =
  | 'huawei-hg8145x6-10'
  | 'huawei'
  | 'tp-link'
  | 'zte'
  | 'nokia'
  | 'd-link'
  | 'tenda'
  | 'asus'
  | 'netgear'
  | 'fiberhome'
  | 'generic';

export type ModemDiagnosticStageId =
  | 'gateway_reachable'
  | 'http_response'
  | 'auth_discovery'
  | 'login'
  | 'session_valid'
  | 'read_device_info'
  | 'read_wifi_info'
  | 'read_devices'
  | 'wifi_write_capability'
  | 'reboot_capability';

export type ModemDiagnosticOutcome =
  | 'passed'
  | 'failed'
  | 'unknown'
  | 'supported'
  | 'unsupported'
  | 'not_tested';

export interface ModemDiagnosticStageResult {
  id: ModemDiagnosticStageId;
  outcome: ModemDiagnosticOutcome;
  httpStatus?: number | null;
  endpoint?: string | null;
  latencyMs?: number | null;
  technicalDetail?: string | null;
}

export interface ModemDiagnosticReport {
  checkedAtIso: string;
  targetUrl: string;
  adapterId: RouterAdapterId | 'auto';
  transportMode: string;
  isSimulation: boolean;
  detectedVendor: string | null;
  detectedModel: string | null;
  stages: ModemDiagnosticStageResult[];
}

export type RouterErrorCode =
  | 'ROUTER_OFFLINE'
  | 'INVALID_CREDENTIALS'
  | 'UNSUPPORTED_MODEL'
  | 'SESSION_EXPIRED'
  | 'SETTINGS_APPLY_FAILED'
  | 'BROWSER_BLOCKED_CORS_OR_MIXED_CONTENT'
  | 'MIXED_CONTENT_HTTPS'
  | 'CORS_BLOCKED'
  | 'ROUTER_API_UNSUPPORTED'
  | 'CONNECTOR_UNREACHABLE'
  | 'CONNECTOR_NOT_FOUND'
  | 'CONNECTOR_AUTH_REQUIRED'
  | 'CONNECTOR_ORIGIN_BLOCKED'
  | 'LAN_BRIDGE_UNAVAILABLE'
  | 'CLOUD_ISOLATED_FROM_LAN'
  | 'RELAY_AGENT_OFFLINE'
  | 'ANDROID_COMPANION_REQUIRED'
  | 'NATIVE_BRIDGE_UNAVAILABLE'
  | 'TOKEN_INVALID'
  | 'INTERNET_OFFLINE'
  | 'INVALID_ROUTER_ADDRESS'
  | 'DATA_READ_FAILED';

export type ConnectionMethodId =
  | 'android_native_bridge'
  | 'direct_browser'
  | 'router_api'
  | 'local_connector'
  | 'lan_hosted_connector'
  | 'secure_cloud_relay'
  | 'android_companion'
  | 'simulation';

export type MethodAttemptStatus = 'succeeded' | 'failed' | 'skipped' | 'not_tested';

export interface MethodAttemptResult {
  methodId: ConnectionMethodId;
  status: MethodAttemptStatus;
  latencyMs: number;
  gatewayIp: string;
  errorCode?: RouterErrorCode;
  detailKey?: string;
  technicalSummary?: string;
  checkedAtIso: string;
}

export interface ConnectionAttemptLogEntry {
  id: string;
  timestampIso: string;
  gatewayIp: string;
  methodId: ConnectionMethodId;
  mode: 'probe' | 'connect';
  status: MethodAttemptStatus;
  latencyMs: number;
  errorCode?: RouterErrorCode;
  detail: string;
}

export interface GatewayCandidate {
  ipOrHost: string;
  normalizedUrl: string;
  source: 'user_input' | 'huawei_default' | 'common_gateway' | 'local_hint';
}

export interface CoreTokenSessionInfo {
  sessionId: string;
  expiresAtIso: string;
  expiresAtMs: number;
  refreshAfterMs: number;
  rotationCount: number;
  status: 'active' | 'renewed' | 'revoked' | 'unavailable';
}

export interface ConnectionDiagnosticsState {
  state:
    | 'idle'
    | 'probing'
    | 'connecting'
    | 'modem_reachable'
    | 'login_failed'
    | 'authenticated'
    | 'data_read_failed'
    | 'connected'
    | 'failed'
    | 'disconnected';
  targetGateway: string;
  activeMethod: ConnectionMethodId | null;
  authState: 'unauthenticated' | 'authenticating' | 'authenticated' | 'rejected';
  lastLatencyMs: number | null;
  serverTopology: 'local-lan' | 'cloud-hosted' | 'unknown';
  coreSession: CoreTokenSessionInfo | null;
  methodResults: MethodAttemptResult[];
  discoveredGateways: GatewayCandidate[];
  attemptsLog: ConnectionAttemptLogEntry[];
  lastErrorCode: RouterErrorCode | null;
  offlineLanCapable: boolean;
  checkedAtIso: string | null;
}

export class RouterError extends Error {
  public readonly code: RouterErrorCode;
  public readonly technicalDetail?: string;

  constructor(code: RouterErrorCode, technicalDetail?: string) {
    super(code);
    this.name = 'RouterError';
    this.code = code;
    this.technicalDetail = technicalDetail;
  }
}

export interface HttpResponse {
  status: number;
  headers: Record<string, string>;
  body: string;
}

export interface HttpRequestOptions {
  method: 'GET' | 'POST' | 'PUT';
  path: string;
  headers?: Record<string, string>;
  body?: string;
  timeoutMs?: number;
}

export type TransportRequestFn = (req: HttpRequestOptions) => Promise<HttpResponse>;

export interface RouterCapabilities {
  readRouterInfo: boolean;
  readWifiSettings: boolean;
  writeWifiSettings: boolean;
  readWifiPassword: boolean;
  dualBand24: boolean;
  dualBand5: boolean;
  toggleWifiRadio: boolean;
  listDevices: boolean;
  blockMacDevice: boolean;
  unblockMacDevice: boolean;
  readSignalStats: boolean;
  readChannelInfo: boolean;
  rebootRouter: boolean;
  guestWifi: boolean;
  blockAllInternet: boolean;
  supportedEncryptions: string[];
}

export interface RouterConnectionContext {
  baseUrl: string;
  adapterId: RouterAdapterId;
  transport: TransportRequestFn;
  sessionState: Record<string, string>;
}

export interface RouterCredentials {
  username: string;
  password: string;
}

export interface RouterInfo {
  vendor: string;
  model: string | null;
  firmwareVersion: string | null;
  hardwareVersion?: string | null;
  deviceType?: string | null;
  ispVendor?: string | null;
  gatewayIp: string;
  wanConnected: boolean | null;
  uptimeSeconds: number | null;
  signalStrengthDbm: number | null;
  linkSpeedMbps?: number | null;
  channelCongestionScore: number | null;
}

export interface WifiBandConfig {
  band: '2.4GHz' | '5GHz';
  enabled: boolean;
  ssid: string;
  password: string | null; // null when router refuses to expose current key
  encryption: string;
  channel: string;
}

export interface WifiSettings {
  band24: WifiBandConfig | null;
  band5: WifiBandConfig | null;
}

export interface WifiUpdateInput {
  band: '2.4GHz' | '5GHz';
  enabled?: boolean;
  ssid: string;
  password?: string;
  encryption: string;
  channel?: string;
}

export interface ConnectedDevice {
  id: string;
  hostname: string;
  ipAddress: string;
  macAddress: string;
  vendor: string | null;
  connectionType: 'Wi-Fi 2.4GHz' | 'Wi-Fi 5GHz' | 'Wi-Fi' | 'Ethernet' | 'Unknown';
  lastSeen: string | null;
  status: 'online' | 'offline' | 'blocked';
  signalDbm?: number | null;
}

export interface ProbeSnapshot {
  rootStatus: number;
  rootHeaders: Record<string, string>;
  rootBody: string;
  extraProbeBody?: string;
  ontProbeBody?: string;
  apiProbePath?: string;
}

export interface RouterAdapter {
  readonly id: RouterAdapterId;
  readonly vendor: string;
  readonly supportedModels: string[];
  readonly firmwareHints: string[];
  readonly authMethod: string;
  readonly defaultGateways: string[];
  readonly capabilities: RouterCapabilities;
  detectScore(probe: ProbeSnapshot): number;
  connect(ctx: RouterConnectionContext): Promise<void>;
  authenticate(ctx: RouterConnectionContext, creds: RouterCredentials): Promise<void>;
  getRouterInfo(ctx: RouterConnectionContext): Promise<RouterInfo>;
  getWifiSettings(ctx: RouterConnectionContext): Promise<WifiSettings>;
  updateWifiSettings(ctx: RouterConnectionContext, update: WifiUpdateInput): Promise<void>;
  getConnectedDevices(ctx: RouterConnectionContext): Promise<{
    connected: ConnectedDevice[];
    blockedMacs: string[];
  }>;
  blockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void>;
  unblockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void>;
  rebootRouter?(ctx: RouterConnectionContext): Promise<void>;
  getGuestWifiEnabled?(ctx: RouterConnectionContext): Promise<boolean | null>;
  setGuestWifiEnabled?(ctx: RouterConnectionContext, enabled: boolean): Promise<void>;
  getInternetAccessPaused?(ctx: RouterConnectionContext): Promise<boolean | null>;
  setInternetAccessPaused?(ctx: RouterConnectionContext, paused: boolean): Promise<void>;
  disconnect(ctx: RouterConnectionContext): Promise<void>;
}
