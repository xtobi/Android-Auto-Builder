import { lookupMacVendor, normalizeMac } from '../../utils/networkSecurity';
import {
  ConnectedDevice,
  ProbeSnapshot,
  RouterAdapter,
  RouterConnectionContext,
  RouterCredentials,
  RouterError,
  RouterInfo,
  WifiBandConfig,
  WifiSettings,
  WifiUpdateInput
} from '../types';
import { escapeXml, extractXmlBlocks, extractXmlTag } from '../xmlUtils';

type HuaweiSubprotocol = 'hilink-xml' | 'ont-asp';

async function sha256Hex(text: string): Promise<string> {
  const bytes = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function utf8ToBase64(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let binary = '';
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary);
}

function cleanRandToken(raw: string): string {
  const cleaned = raw.replace(/^\uFEFF/, '').trim().replace(/^["']|["']$/g, '');
  if (!cleaned || cleaned.includes('<html') || cleaned.includes('<HTML') || cleaned.length < 6) {
    return '';
  }
  // Sometimes GetRandCount.asp returns hex or alphanumeric token directly on a single line
  const line = cleaned.split(/\r?\n/)[0]?.trim() || '';
  return /^[A-Za-z0-9_-]{6,128}$/.test(line) ? line : '';
}

function extractOntHiddenToken(html: string): string {
  const match =
    html.match(/(?:hwonttoken|onttoken|X_HW_Token)[^>]*value=["']([A-Za-z0-9_-]{6,128})["']/i) ||
    html.match(/var\s+(?:onttoken|hwToken)\s*=\s*["']([A-Za-z0-9_-]{6,128})["']/i);
  return match?.[1] || '';
}

async function fetchHilinkToken(ctx: RouterConnectionContext): Promise<{ session: string; token: string }> {
  const res = await ctx.transport({ method: 'GET', path: '/api/webserver/SesTokInfo' });
  const session = extractXmlTag(res.body, 'SesInfo') || ctx.sessionState.sesInfo || '';
  const token = extractXmlTag(res.body, 'TokInfo') || '';
  if (session) ctx.sessionState.sesInfo = session;
  if (token) ctx.sessionState.tokInfo = token;
  return { session, token };
}

async function fetchOntRandToken(ctx: RouterConnectionContext): Promise<string> {
  const res = await ctx.transport({ method: 'GET', path: '/asp/GetRandCount.asp' }).catch(() => null);
  if (res && res.status >= 200 && res.status < 400) {
    const token = cleanRandToken(res.body) || extractOntHiddenToken(res.body);
    if (token) {
      ctx.sessionState.hwToken = token;
      return token;
    }
  }
  return ctx.sessionState.hwToken || '';
}

function detectOntAuthRejection(status: number, body: string): boolean {
  if (status === 401 || status === 403) return true;
  const lower = body.toLowerCase();
  return (
    lower.includes('errcode') ||
    lower.includes('login_fail') ||
    lower.includes('failtimes') ||
    lower.includes('password is wrong') ||
    lower.includes('invalid password') ||
    lower.includes('wrong password') ||
    lower.includes('user or password') ||
    (lower.includes('action="/login.cgi"') && !lower.includes('devinfo'))
  );
}

function detectOntSessionExpired(status: number, body: string): boolean {
  if (status === 401 || status === 403) return true;
  const lower = body.toLowerCase();
  return (
    lower.includes('action="/login.cgi"') ||
    lower.includes('top.location.replace') ||
    lower.includes('getrandcount.asp') && lower.includes('submitform')
  );
}

function splitQuotedArgs(rawArgs: string): string[] {
  const out: string[] = [];
  const re = /"((?:\\.|[^"\\])*)"|'((?:\\.|[^'\\])*)'|([^,\s]+)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(rawArgs)) !== null) {
    out.push(m[1] ?? m[2] ?? m[3] ?? '');
  }
  return out;
}

function parseOntWlanEntries(body: string): WifiSettings {
  const configs: WifiBandConfig[] = [];

  // Match Huawei stWlan(...) JS array records commonly rendered in OptiXstar HG8145X6-10 wlaninfo.asp
  const stWlanRe = /new\s+stWlan\s*\(([^)]+)\)/gi;
  let m: RegExpExecArray | null;
  while ((m = stWlanRe.exec(body)) !== null) {
    const args = splitQuotedArgs(m[1]);
    // Common Huawei ONT order: domain, name, enable, ssid, hide, beaconType, encMode, key, ..., rfBand/channel
    const domain = args[0] || '';
    const nameOrIface = (args[1] || '').toLowerCase();
    const enabled = args[2] !== '0' && args[2]?.toLowerCase() !== 'false';
    const ssid = args[3] || args[1] || '';
    const beacon = (args[5] || '').toUpperCase();
    const channelArg = args.find((a) => /^(auto|\d{1,3})$/i.test(a) && (a.toLowerCase() === 'auto' || Number(a) > 0 && Number(a) <= 165));
    const is5 =
      domain.includes('.5') ||
      domain.includes('.2') ||
      nameOrIface.includes('5g') ||
      nameOrIface.includes('wl1') ||
      nameOrIface.includes('ath4') ||
      configs.length === 1;

    const encryption =
      beacon.includes('WPA3') || beacon.includes('SAE')
        ? 'WPA3-SAE'
        : beacon.includes('11I') || beacon.includes('WPA2')
        ? 'WPA2-PSK'
        : beacon.includes('NONE') || beacon === 'BASIC'
        ? 'OPEN'
        : 'WPA/WPA2-PSK';

    // Never fabricate or expose masked placeholder passwords
    const rawKey = args.find((a, idx) => idx >= 6 && idx <= 9 && a.length >= 8 && !/^(WPA|Basic|11i|AES|TKIP)/i.test(a));
    const password = rawKey && !/^\*+$/.test(rawKey) ? rawKey : null;

    if (ssid || domain) {
      configs.push({
        band: is5 ? '5GHz' : '2.4GHz',
        enabled,
        ssid,
        password,
        encryption,
        channel: channelArg || 'Auto'
      });
    }
  }

  // Fallback XML/Key-Value check inside ASP HTML
  if (configs.length === 0) {
    const ssid24 = extractXmlTag(body, 'SSID1') || extractXmlTag(body, 'WifiSsid') || body.match(/var\s+ssid_24\s*=\s*["']([^"']+)["']/i)?.[1];
    const ssid5 = extractXmlTag(body, 'SSID5') || body.match(/var\s+ssid_5\s*=\s*["']([^"']+)["']/i)?.[1];
    if (ssid24) {
      configs.push({
        band: '2.4GHz',
        enabled: true,
        ssid: ssid24,
        password: null,
        encryption: 'WPA2-PSK',
        channel: 'Auto'
      });
    }
    if (ssid5) {
      configs.push({
        band: '5GHz',
        enabled: true,
        ssid: ssid5,
        password: null,
        encryption: 'WPA2-PSK',
        channel: 'Auto'
      });
    }
  }

  const band24 = configs.find((c) => c.band === '2.4GHz') ?? null;
  const band5 = configs.find((c) => c.band === '5GHz') ?? null;
  return { band24, band5 };
}

function parseOntLanDevices(body: string, blockedSet: Set<string>): ConnectedDevice[] {
  const devices: ConnectedDevice[] = [];
  const seenMacs = new Set<string>();

  // Match Huawei GetLanUserDevInfo.asp JS constructor `new USERDev(...)`
  const userDevRe = /new\s+USERDev\s*\(([^)]+)\)/gi;
  let m: RegExpExecArray | null;
  let idx = 0;
  while ((m = userDevRe.exec(body)) !== null) {
    idx += 1;
    const args = splitQuotedArgs(m[1]);
    const macCandidate = args.find((a) => /^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$/.test(a));
    if (!macCandidate) continue;
    const mac = normalizeMac(macCandidate);
    if (seenMacs.has(mac)) continue;
    seenMacs.add(mac);

    const ip = args.find((a) => /^(\d{1,3}\.){3}\d{1,3}$/.test(a)) || '';
    const portArg = args.find((a) => /^(SSID|LAN|Wi-Fi|ETH)/i.test(a)) || '';
    const stateArg = args.find((a) => /^(Online|Offline)$/i.test(a)) || 'Online';
    const hostnameCandidate = args.find(
      (a) =>
        a &&
        a !== macCandidate &&
        a !== ip &&
        a !== portArg &&
        a !== stateArg &&
        !/^InternetGatewayDevice\./i.test(a) &&
        !/^\d+$/.test(a)
    );

    const lowerPort = portArg.toLowerCase();
    const connectionType: ConnectedDevice['connectionType'] = lowerPort.includes('lan') || lowerPort.includes('eth')
      ? 'Ethernet'
      : lowerPort.includes('5') || lowerPort.includes('ssid5') || lowerPort.includes('ssid6')
      ? 'Wi-Fi 5GHz'
      : lowerPort.includes('ssid') || lowerPort.includes('wi')
      ? 'Wi-Fi 2.4GHz'
      : 'Wi-Fi';

    const status: ConnectedDevice['status'] = blockedSet.has(mac)
      ? 'blocked'
      : stateArg.toLowerCase() === 'offline'
      ? 'offline'
      : 'online';

    devices.push({
      id: mac,
      hostname: hostnameCandidate || `Client-${idx}`,
      ipAddress: ip,
      macAddress: mac,
      vendor: lookupMacVendor(mac),
      connectionType,
      lastSeen: stateArg,
      status
    });
  }

  return devices;
}

export const huaweiAdapter: RouterAdapter = {
  id: 'huawei',
  vendor: 'Huawei',
  supportedModels: [
    'OptiXstar HG8145X6-10 (Wi-Fi 6 ONT)',
    'EchoLife HG8245H / HG8245Q2',
    'B315 / B525 / B535 / B818 (HiLink)',
    'AX3 / WS5200'
  ],
  firmwareHints: ['OptiXstar / EchoLife ONT ASP+CGI (V5/V6)', 'HiLink V3/V5 XML API', 'HarmonyOS / EMUI Router'],
  authMethod: 'Auto-negotiated: ONT X_HW_Token (login.cgi) or HiLink SesTokInfo + SHA-256 Base64',
  defaultGateways: ['192.168.100.1', '192.168.1.1', '192.168.8.1'],
  capabilities: {
    readRouterInfo: true,
    readWifiSettings: true,
    writeWifiSettings: true,
    readWifiPassword: true,
    dualBand24: true,
    dualBand5: true,
    toggleWifiRadio: true,
    listDevices: true,
    blockMacDevice: true,
    unblockMacDevice: true,
    readSignalStats: true,
    readChannelInfo: true,
    rebootRouter: true,
    guestWifi: true,
    blockAllInternet: true,
    supportedEncryptions: ['WPA2-PSK', 'WPA/WPA2-PSK', 'WPA3-SAE', 'OPEN']
  },

  detectScore(probe: ProbeSnapshot): number {
    const body = probe.rootBody.toLowerCase();
    const extra = (probe.extraProbeBody || '').toLowerCase();
    const ont = (probe.ontProbeBody || '').trim();
    let score = 0;
    if (body.includes('huawei') || body.includes('hilink')) score += 50;
    if (
      body.includes('optixstar') ||
      body.includes('hg8145') ||
      body.includes('hg8245') ||
      body.includes('echolife') ||
      body.includes('getrandcount.asp') ||
      body.includes('x_hw_token') ||
      body.includes('hwonttoken')
    ) {
      score += 65;
    }
    if (extra.includes('<sesinfo>') && extra.includes('<tokinfo>')) score += 60;
    if (cleanRandToken(ont)) score += 65;
    return score;
  },

  async connect(ctx: RouterConnectionContext): Promise<void> {
    // 1. Probe HiLink XML endpoint
    const hilink = await fetchHilinkToken(ctx).catch(() => ({ session: '', token: '' }));
    if (hilink.token) {
      ctx.sessionState.subprotocol = 'hilink-xml';
      return;
    }

    // 2. Probe Huawei GPON ONT ASP/CGI portal (OptiXstar HG8145X6-10, HG8245H, etc.)
    const ontToken = await fetchOntRandToken(ctx);
    if (ontToken) {
      ctx.sessionState.subprotocol = 'ont-asp';
      return;
    }

    // 3. Check root page signatures for ONT portal that uses hidden onttoken instead of GetRandCount
    const rootRes = await ctx.transport({ method: 'GET', path: '/' }).catch(() => null);
    if (rootRes && rootRes.status >= 200 && rootRes.status < 400) {
      const lower = rootRes.body.toLowerCase();
      if (
        lower.includes('optixstar') ||
        lower.includes('hg8145') ||
        lower.includes('echolife') ||
        lower.includes('login.cgi') ||
        lower.includes('x_hw_token')
      ) {
        ctx.sessionState.subprotocol = 'ont-asp';
        const hidden = extractOntHiddenToken(rootRes.body);
        if (hidden) ctx.sessionState.hwToken = hidden;
        return;
      }
    }

    throw new RouterError(
      'UNSUPPORTED_MODEL',
      'Neither Huawei HiLink XML nor Huawei ONT ASP/CGI endpoints responded'
    );
  },

  async authenticate(ctx: RouterConnectionContext, creds: RouterCredentials): Promise<void> {
    const subprotocol = (ctx.sessionState.subprotocol as HuaweiSubprotocol | undefined) || 'hilink-xml';
    const username = creds.username.trim() || 'admin';

    if (subprotocol === 'ont-asp') {
      const randToken = await fetchOntRandToken(ctx);
      const encodedPass = utf8ToBase64(creds.password);
      const formBody = new URLSearchParams({
        UserName: username,
        PassWord: encodedPass,
        Language: 'english',
        'x.X_HW_Token': randToken
      }).toString();

      const loginRes = await ctx.transport({
        method: 'POST',
        path: '/login.cgi',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formBody
      });

      if (detectOntAuthRejection(loginRes.status, loginRes.body)) {
        throw new RouterError('INVALID_CREDENTIALS', 'Huawei ONT /login.cgi rejected credentials');
      }

      const nextHidden = extractOntHiddenToken(loginRes.body);
      if (nextHidden) {
        ctx.sessionState.hwToken = nextHidden;
      } else {
        await fetchOntRandToken(ctx).catch(() => '');
      }
      return;
    }

    // HiLink XML auth flow
    const { session, token } = await fetchHilinkToken(ctx);
    const passSha = utf8ToBase64(await sha256Hex(creds.password));
    const combined = utf8ToBase64(await sha256Hex(`${username}${passSha}${token}`));

    const xml = `<?xml version="1.0" encoding="UTF-8"?><request><Username>${escapeXml(username)}</Username><Password>${combined}</Password><password_type>4</password_type></request>`;
    const res = await ctx.transport({
      method: 'POST',
      path: '/api/user/login',
      headers: {
        'Content-Type': 'application/xml',
        '__RequestVerificationToken': token,
        ...(session ? { Cookie: session } : {})
      },
      body: xml
    });

    if (res.body.includes('<error>') || res.status === 401 || res.status === 403) {
      throw new RouterError('INVALID_CREDENTIALS', 'Huawei HiLink login returned error');
    }
    const nextToken = res.headers['__requestverificationtokenone'] || res.headers['__requestverificationtoken'];
    if (nextToken) ctx.sessionState.tokInfo = nextToken;
  },

  async getRouterInfo(ctx: RouterConnectionContext): Promise<RouterInfo> {
    const subprotocol = (ctx.sessionState.subprotocol as HuaweiSubprotocol | undefined) || 'hilink-xml';

    if (subprotocol === 'ont-asp') {
      const [devRes, wanRes] = await Promise.all([
        ctx.transport({ method: 'GET', path: '/html/ssmp/devinfo/devinfo.asp' }),
        ctx.transport({ method: 'GET', path: '/html/bbsp/waninfo/waninfo.asp' }).catch(() => null)
      ]);

      if (detectOntSessionExpired(devRes.status, devRes.body)) {
        throw new RouterError('SESSION_EXPIRED');
      }

      const modelMatch =
        devRes.body.match(/(?:ModelName|DeviceType|ProductName)\s*[:=]\s*["']([^"']+)["']/i) ||
        devRes.body.match(/new\s+stDevInfo\s*\([^)]*"([^"]*HG\d+[^"]*)"/i);
      const swMatch = devRes.body.match(/(?:SoftwareVersion|SoftVer)\s*[:=]\s*["']([^"']+)["']/i);
      const rxPowerMatch = devRes.body.match(/(?:RxPower|OpticalPower|RSSI)\s*[:=]\s*["']?(-?\d+(?:\.\d+)?)\s*(?:dBm)?/i);

      const wanBody = (wanRes?.body || '').toLowerCase();
      const wanConnected = wanRes
        ? wanBody.includes('connected') && !wanBody.includes('disconnected')
          ? true
          : wanBody.includes('disconnected')
          ? false
          : null
        : null;

      const parsedRssi = rxPowerMatch ? Math.round(Number(rxPowerMatch[1])) : null;

      return {
        vendor: 'Huawei',
        model: modelMatch?.[1]?.trim() || null,
        firmwareVersion: swMatch?.[1]?.trim() || null,
        gatewayIp: new URL(ctx.baseUrl).hostname,
        wanConnected,
        uptimeSeconds: null,
        signalStrengthDbm: parsedRssi !== null && Number.isFinite(parsedRssi) ? parsedRssi : null,
        channelCongestionScore: null
      };
    }

    const [devRes, monRes, sigRes] = await Promise.all([
      ctx.transport({ method: 'GET', path: '/api/device/information' }),
      ctx.transport({ method: 'GET', path: '/api/monitoring/status' }).catch(() => null),
      ctx.transport({ method: 'GET', path: '/api/device/signal' }).catch(() => null)
    ]);

    if (devRes.body.includes('100003') || devRes.status === 401) {
      throw new RouterError('SESSION_EXPIRED');
    }

    const model = extractXmlTag(devRes.body, 'DeviceName') || 'Huawei Router';
    const firmwareVersion = extractXmlTag(devRes.body, 'SoftwareVersion');
    const connStatus = monRes ? extractXmlTag(monRes.body, 'ConnectionStatus') : null;
    const rssiRaw = sigRes ? extractXmlTag(sigRes.body, 'rssi') : null;
    const rssi = rssiRaw ? parseInt(rssiRaw.replace(/[^\d-]/g, ''), 10) : null;

    return {
      vendor: 'Huawei',
      model,
      firmwareVersion,
      gatewayIp: new URL(ctx.baseUrl).hostname,
      wanConnected: connStatus ? connStatus === '901' : null,
      uptimeSeconds: null,
      signalStrengthDbm: Number.isFinite(rssi) ? rssi : null,
      channelCongestionScore: null
    };
  },

  async getWifiSettings(ctx: RouterConnectionContext): Promise<WifiSettings> {
    const subprotocol = (ctx.sessionState.subprotocol as HuaweiSubprotocol | undefined) || 'hilink-xml';

    if (subprotocol === 'ont-asp') {
      const wlanRes = await ctx.transport({ method: 'GET', path: '/html/amp/wlaninfo/wlaninfo.asp' });
      if (detectOntSessionExpired(wlanRes.status, wlanRes.body)) {
        throw new RouterError('SESSION_EXPIRED');
      }
      const parsed = parseOntWlanEntries(wlanRes.body);
      if (parsed.band24 || parsed.band5) return parsed;

      const basicRes = await ctx.transport({ method: 'GET', path: '/html/amp/wlanbasic/WlanBasic.asp' }).catch(() => null);
      if (basicRes && detectOntSessionExpired(basicRes.status, basicRes.body)) {
        throw new RouterError('SESSION_EXPIRED');
      }
      if (basicRes && basicRes.status < 400) {
        return parseOntWlanEntries(basicRes.body);
      }
      return { band24: null, band5: null };
    }

    const multi = await ctx.transport({ method: 'GET', path: '/api/wlan/multi-basic-settings' }).catch(() => null);
    if (multi && multi.body.includes('<Ssid>')) {
      const blocks = extractXmlBlocks(multi.body, 'Ssid');
      const b24 = blocks[0];
      const b5 = blocks[1];
      return {
        band24: b24
          ? {
              band: '2.4GHz',
              enabled: extractXmlTag(b24, 'WifiEnable') !== '0',
              ssid: extractXmlTag(b24, 'WifiSsid') || '',
              password: extractXmlTag(b24, 'WifiWpaPreSharedKey'),
              encryption: extractXmlTag(b24, 'WifiAuthmode') || 'WPA2-PSK',
              channel: extractXmlTag(b24, 'WifiChannel') || '0'
            }
          : null,
        band5: b5
          ? {
              band: '5GHz',
              enabled: extractXmlTag(b5, 'WifiEnable') !== '0',
              ssid: extractXmlTag(b5, 'WifiSsid') || '',
              password: extractXmlTag(b5, 'WifiWpaPreSharedKey'),
              encryption: extractXmlTag(b5, 'WifiAuthmode') || 'WPA2-PSK',
              channel: extractXmlTag(b5, 'WifiChannel') || '0'
            }
          : null
      };
    }

    const basic = await ctx.transport({ method: 'GET', path: '/api/wlan/basic-settings' });
    if (basic.body.includes('100003') || basic.status === 401) {
      throw new RouterError('SESSION_EXPIRED');
    }
    return {
      band24: {
        band: '2.4GHz',
        enabled: extractXmlTag(basic.body, 'WifiEnable') !== '0',
        ssid: extractXmlTag(basic.body, 'WifiSsid') || '',
        password: extractXmlTag(basic.body, 'WifiWpaPreSharedKey'),
        encryption: extractXmlTag(basic.body, 'WifiAuthmode') || 'WPA2-PSK',
        channel: extractXmlTag(basic.body, 'WifiChannel') || '0'
      },
      band5: null
    };
  },

  async updateWifiSettings(ctx: RouterConnectionContext, update: WifiUpdateInput): Promise<void> {
    const subprotocol = (ctx.sessionState.subprotocol as HuaweiSubprotocol | undefined) || 'hilink-xml';

    if (subprotocol === 'ont-asp') {
      const token = await fetchOntRandToken(ctx);
      const wlanInst = update.band === '5GHz' ? 'InternetGatewayDevice.LANDevice.1.WLANConfiguration.5' : 'InternetGatewayDevice.LANDevice.1.WLANConfiguration.1';
      const form = new URLSearchParams({
        'x.Enable': update.enabled === false ? '0' : '1',
        'x.SSID': update.ssid,
        'x.BeaconType': update.encryption === 'OPEN' ? 'Basic' : '11i',
        'x.X_HW_Token': token
      });
      if (update.password !== undefined) {
        form.set('y.PreSharedKey', update.password);
      }
      if (update.channel && update.channel !== 'Auto') {
        form.set('x.Channel', update.channel);
      }
      const res = await ctx.transport({
        method: 'POST',
        path: `/html/amp/wlanbasic/set.cgi?x=${encodeURIComponent(wlanInst)}&y=${encodeURIComponent(`${wlanInst}.PreSharedKey.1`)}`,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: form.toString()
      });
      if (detectOntSessionExpired(res.status, res.body)) {
        throw new RouterError('SESSION_EXPIRED');
      }
      if (res.status >= 400 || detectOntAuthRejection(res.status, res.body)) {
        throw new RouterError('SETTINGS_APPLY_FAILED', 'Huawei ONT rejected Wi-Fi configuration payload');
      }
      return;
    }

    const { token } = await fetchHilinkToken(ctx);
    const index = update.band === '5GHz' ? '1' : '0';
    const xml = `<?xml version="1.0" encoding="UTF-8"?><request><Ssid><Index>${index}</Index><WifiEnable>${update.enabled === false ? '0' : '1'}</WifiEnable><WifiSsid>${escapeXml(update.ssid)}</WifiSsid>${update.password !== undefined ? `<WifiWpaPreSharedKey>${escapeXml(update.password)}</WifiWpaPreSharedKey>` : ''}<WifiAuthmode>${escapeXml(update.encryption)}</WifiAuthmode>${update.channel ? `<WifiChannel>${escapeXml(update.channel)}</WifiChannel>` : ''}</Ssid></request>`;

    const res = await ctx.transport({
      method: 'POST',
      path: '/api/wlan/multi-basic-settings',
      headers: {
        'Content-Type': 'application/xml',
        '__RequestVerificationToken': token
      },
      body: xml
    });

    if (res.body.includes('<error>') || res.status >= 400) {
      throw new RouterError('SETTINGS_APPLY_FAILED', 'Huawei rejected Wi-Fi configuration payload');
    }
  },

  async getConnectedDevices(ctx: RouterConnectionContext) {
    const subprotocol = (ctx.sessionState.subprotocol as HuaweiSubprotocol | undefined) || 'hilink-xml';

    if (subprotocol === 'ont-asp') {
      const [lanRes, macRes] = await Promise.all([
        ctx.transport({ method: 'GET', path: '/html/bbsp/common/GetLanUserDevInfo.asp' }),
        ctx.transport({ method: 'GET', path: '/html/bbsp/macfilter/macfilter.asp' }).catch(() => null)
      ]);
      if (detectOntSessionExpired(lanRes.status, lanRes.body)) {
        throw new RouterError('SESSION_EXPIRED');
      }
      const blockedSet = new Set<string>();
      if (macRes && macRes.status < 400) {
        const matches = macRes.body.match(/([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}/g) || [];
        matches.forEach((m) => blockedSet.add(normalizeMac(m)));
      }
      const connected = parseOntLanDevices(lanRes.body, blockedSet);
      return { connected, blockedMacs: Array.from(blockedSet) };
    }

    const [hostRes, macRes] = await Promise.all([
      ctx.transport({ method: 'GET', path: '/api/wlan/host-list' }),
      ctx.transport({ method: 'GET', path: '/api/wlan/mac-filter' }).catch(() => null)
    ]);

    if (hostRes.body.includes('100003') || hostRes.status === 401) {
      throw new RouterError('SESSION_EXPIRED');
    }

    const blockedSet = new Set<string>();
    if (macRes) {
      const macMatches = macRes.body.match(/([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}/g) || [];
      macMatches.forEach((m) => blockedSet.add(normalizeMac(m)));
    }

    const hostBlocks = extractXmlBlocks(hostRes.body, 'Host');
    const connected: ConnectedDevice[] = hostBlocks
      .map((block, idx) => {
        const rawMac = extractXmlTag(block, 'MacAddress') || '';
        const mac = normalizeMac(rawMac);
        if (!mac) return null;
        const ip = extractXmlTag(block, 'IpAddress') || '';
        const name = extractXmlTag(block, 'HostName') || `Device-${idx + 1}`;
        const iface = extractXmlTag(block, 'InterfaceType') || '';
        const connType: ConnectedDevice['connectionType'] =
          iface.includes('5G') ? 'Wi-Fi 5GHz' : iface.includes('2.4') ? 'Wi-Fi 2.4GHz' : iface.toLowerCase().includes('eth') ? 'Ethernet' : 'Wi-Fi';
        const assocTime = extractXmlTag(block, 'AssociatedTime');
        const activeTag = extractXmlTag(block, 'Active');
        const status: ConnectedDevice['status'] = blockedSet.has(mac)
          ? 'blocked'
          : activeTag === '0'
          ? 'offline'
          : 'online';
        return {
          id: mac,
          hostname: name,
          ipAddress: ip,
          macAddress: mac,
          vendor: lookupMacVendor(mac),
          connectionType: connType,
          lastSeen: assocTime ? `${assocTime}s` : null,
          status
        } as ConnectedDevice;
      })
      .filter((d): d is ConnectedDevice => d !== null);

    return { connected, blockedMacs: Array.from(blockedSet) };
  },

  async blockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const subprotocol = (ctx.sessionState.subprotocol as HuaweiSubprotocol | undefined) || 'hilink-xml';
    const mac = normalizeMac(macAddress);

    if (subprotocol === 'ont-asp') {
      const token = await fetchOntRandToken(ctx);
      const res = await ctx.transport({
        method: 'POST',
        path: '/html/bbsp/macfilter/add.cgi?x=InternetGatewayDevice.X_HW_Security.MacFilter',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          'x.SourceMACAddress': mac,
          'x.X_HW_Token': token
        }).toString()
      });
      if (detectOntSessionExpired(res.status, res.body)) {
        throw new RouterError('SESSION_EXPIRED');
      }
      if (res.status >= 400 || detectOntAuthRejection(res.status, res.body)) {
        throw new RouterError('SETTINGS_APPLY_FAILED', 'Huawei ONT MAC filter rule rejected');
      }
      return;
    }

    const { token } = await fetchHilinkToken(ctx);
    const current = await this.getConnectedDevices(ctx);
    const nextBlocked = Array.from(new Set([...current.blockedMacs, mac])).slice(0, 16);
    const macFields = nextBlocked.map((m, i) => `<WifiMacFilterMac${i}>${escapeXml(m)}</WifiMacFilterMac${i}>`).join('');
    const xml = `<?xml version="1.0" encoding="UTF-8"?><request><WifiMacFilterStatus>2</WifiMacFilterStatus>${macFields}</request>`;
    const res = await ctx.transport({
      method: 'POST',
      path: '/api/wlan/mac-filter',
      headers: {
        'Content-Type': 'application/xml',
        '__RequestVerificationToken': token
      },
      body: xml
    });
    if (res.body.includes('<error>') || res.status >= 400) {
      throw new RouterError('SETTINGS_APPLY_FAILED', 'Huawei MAC ACL block failed');
    }
  },

  async unblockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const subprotocol = (ctx.sessionState.subprotocol as HuaweiSubprotocol | undefined) || 'hilink-xml';
    const mac = normalizeMac(macAddress);

    if (subprotocol === 'ont-asp') {
      const token = await fetchOntRandToken(ctx);
      const res = await ctx.transport({
        method: 'POST',
        path: '/html/bbsp/macfilter/del.cgi',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          'x.SourceMACAddress': mac,
          'x.X_HW_Token': token
        }).toString()
      });
      if (detectOntSessionExpired(res.status, res.body)) {
        throw new RouterError('SESSION_EXPIRED');
      }
      if (res.status >= 400 || detectOntAuthRejection(res.status, res.body)) {
        throw new RouterError('SETTINGS_APPLY_FAILED', 'Huawei ONT MAC filter removal rejected');
      }
      return;
    }

    const { token } = await fetchHilinkToken(ctx);
    const current = await this.getConnectedDevices(ctx);
    const nextBlocked = current.blockedMacs.filter((m) => m !== mac);
    const macFields = nextBlocked.map((m, i) => `<WifiMacFilterMac${i}>${escapeXml(m)}</WifiMacFilterMac${i}>`).join('');
    const xml = `<?xml version="1.0" encoding="UTF-8"?><request><WifiMacFilterStatus>${nextBlocked.length > 0 ? '2' : '0'}</WifiMacFilterStatus>${macFields}</request>`;
    const res = await ctx.transport({
      method: 'POST',
      path: '/api/wlan/mac-filter',
      headers: {
        'Content-Type': 'application/xml',
        '__RequestVerificationToken': token
      },
      body: xml
    });
    if (res.body.includes('<error>') || res.status >= 400) {
      throw new RouterError('SETTINGS_APPLY_FAILED', 'Huawei MAC ACL unblock failed');
    }
  },

  async rebootRouter(ctx: RouterConnectionContext): Promise<void> {
    const subprotocol = (ctx.sessionState.subprotocol as HuaweiSubprotocol | undefined) || 'hilink-xml';

    if (subprotocol === 'ont-asp') {
      const token = await fetchOntRandToken(ctx);
      const res = await ctx.transport({
        method: 'POST',
        path: '/html/ssmp/reset/set.cgi?x=InternetGatewayDevice.X_HW_DEBUG.SMP.DM.ResetBoard',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ 'x.X_HW_Token': token }).toString()
      });
      if (detectOntSessionExpired(res.status, res.body)) {
        throw new RouterError('SESSION_EXPIRED');
      }
      if (res.status >= 400 || detectOntAuthRejection(res.status, res.body)) {
        throw new RouterError('SETTINGS_APPLY_FAILED', 'Huawei ONT reboot rejected');
      }
      return;
    }

    const { token } = await fetchHilinkToken(ctx);
    const res = await ctx.transport({
      method: 'POST',
      path: '/api/device/control',
      headers: {
        'Content-Type': 'application/xml',
        '__RequestVerificationToken': token
      },
      body: '<?xml version="1.0" encoding="UTF-8"?><request><Control>1</Control></request>'
    });
    if (res.body.includes('<error>') || res.status >= 400) {
      throw new RouterError('SETTINGS_APPLY_FAILED', 'Huawei reboot command rejected');
    }
  },

  async getGuestWifiEnabled(ctx: RouterConnectionContext): Promise<boolean | null> {
    const subprotocol = (ctx.sessionState.subprotocol as HuaweiSubprotocol | undefined) || 'hilink-xml';
    if (subprotocol === 'ont-asp') {
      const res = await ctx.transport({ method: 'GET', path: '/html/amp/wlanbasic/WlanGuest.asp' }).catch(() => null);
      if (!res || res.status >= 400 || detectOntSessionExpired(res.status, res.body)) return null;
      const m = res.body.match(/guestWifiEnable\s*[:=]\s*["']?([01])/i);
      return m ? m[1] === '1' : null;
    }

    const res = await ctx.transport({ method: 'GET', path: '/api/wlan/guest-settings' }).catch(() => null);
    if (!res || res.status >= 400 || res.body.includes('<error>')) return null;
    const enabled = extractXmlTag(res.body, 'WifiEnable');
    if (enabled === null) return null;
    return enabled !== '0';
  },

  async setGuestWifiEnabled(ctx: RouterConnectionContext, enabled: boolean): Promise<void> {
    const subprotocol = (ctx.sessionState.subprotocol as HuaweiSubprotocol | undefined) || 'hilink-xml';
    if (subprotocol === 'ont-asp') {
      const probe = await ctx.transport({ method: 'GET', path: '/html/amp/wlanbasic/WlanGuest.asp' }).catch(() => null);
      if (!probe) {
        throw new RouterError('UNSUPPORTED_MODEL', 'Guest Wi-Fi endpoint is not exposed on this ONT firmware');
      }
      if (detectOntSessionExpired(probe.status, probe.body)) {
        throw new RouterError('SESSION_EXPIRED');
      }
      if (probe.status === 404 || !probe.body.toLowerCase().includes('guest')) {
        throw new RouterError('UNSUPPORTED_MODEL', 'Guest Wi-Fi endpoint is not exposed on this ONT firmware');
      }
      const token = await fetchOntRandToken(ctx);
      const res = await ctx.transport({
        method: 'POST',
        path: '/html/amp/wlanbasic/set.cgi?x=InternetGatewayDevice.LANDevice.1.WLANConfiguration.2',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          'x.Enable': enabled ? '1' : '0',
          'x.X_HW_Token': token
        }).toString()
      });
      if (detectOntSessionExpired(res.status, res.body)) {
        throw new RouterError('SESSION_EXPIRED');
      }
      if (res.status >= 400) {
        throw new RouterError('SETTINGS_APPLY_FAILED', 'Huawei ONT guest Wi-Fi toggle rejected');
      }
      return;
    }

    const { token } = await fetchHilinkToken(ctx);
    const res = await ctx.transport({
      method: 'POST',
      path: '/api/wlan/guest-settings',
      headers: {
        'Content-Type': 'application/xml',
        '__RequestVerificationToken': token
      },
      body: `<?xml version="1.0" encoding="UTF-8"?><request><WifiEnable>${enabled ? '1' : '0'}</WifiEnable></request>`
    });
    if (res.body.includes('<error>') || res.status >= 400) {
      throw new RouterError('SETTINGS_APPLY_FAILED', 'Huawei guest Wi-Fi toggle rejected');
    }
  },

  async getInternetAccessPaused(ctx: RouterConnectionContext): Promise<boolean | null> {
    const subprotocol = (ctx.sessionState.subprotocol as HuaweiSubprotocol | undefined) || 'hilink-xml';
    if (subprotocol === 'ont-asp') {
      return null;
    }

    const res = await ctx.transport({ method: 'GET', path: '/api/dialup/mobile-dataswitch' }).catch(() => null);
    if (!res || res.status >= 400 || res.body.includes('<error>')) return null;
    const sw = extractXmlTag(res.body, 'dataswitch');
    if (sw === null) return null;
    return sw === '0';
  },

  async setInternetAccessPaused(ctx: RouterConnectionContext, paused: boolean): Promise<void> {
    const subprotocol = (ctx.sessionState.subprotocol as HuaweiSubprotocol | undefined) || 'hilink-xml';
    if (subprotocol === 'ont-asp') {
      throw new RouterError('UNSUPPORTED_MODEL', 'WAN internet pause is not exposed via ONT ASP portal');
    }

    const { token } = await fetchHilinkToken(ctx);
    const res = await ctx.transport({
      method: 'POST',
      path: '/api/dialup/mobile-dataswitch',
      headers: {
        'Content-Type': 'application/xml',
        '__RequestVerificationToken': token
      },
      body: `<?xml version="1.0" encoding="UTF-8"?><request><dataswitch>${paused ? '0' : '1'}</dataswitch></request>`
    });
    if (res.body.includes('<error>') || res.status >= 400) {
      throw new RouterError('SETTINGS_APPLY_FAILED', 'Huawei WAN/data toggle rejected');
    }
  },

  async disconnect(ctx: RouterConnectionContext): Promise<void> {
    const subprotocol = (ctx.sessionState.subprotocol as HuaweiSubprotocol | undefined) || 'hilink-xml';
    if (subprotocol === 'ont-asp') {
      const token = ctx.sessionState.hwToken || '';
      await ctx.transport({
        method: 'POST',
        path: '/logout.cgi',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: token ? new URLSearchParams({ 'x.X_HW_Token': token }).toString() : ''
      }).catch(() => undefined);
      return;
    }

    const token = ctx.sessionState.tokInfo || '';
    await ctx.transport({
      method: 'POST',
      path: '/api/user/logout',
      headers: {
        'Content-Type': 'application/xml',
        ...(token ? { '__RequestVerificationToken': token } : {})
      },
      body: '<?xml version="1.0" encoding="UTF-8"?><request><Logout>1</Logout></request>'
    }).catch(() => undefined);
  }
};
