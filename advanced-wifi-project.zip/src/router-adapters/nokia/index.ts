import { lookupMacVendor, normalizeMac } from '../../utils/networkSecurity';
import {
  ConnectedDevice,
  ProbeSnapshot,
  RouterAdapter,
  RouterConnectionContext,
  RouterCredentials,
  RouterError,
  RouterInfo,
  WifiSettings,
  WifiUpdateInput
} from '../types';
import { tryParseJson } from '../xmlUtils';

export const nokiaAdapter: RouterAdapter = {
  id: 'nokia',
  vendor: 'Nokia',
  supportedModels: ['G-240W-C / G-240W-F', 'G-140W-C / G-2425G-A', 'Beacon 1 / 2 / 6'],
  firmwareHints: ['Nokia ONT Web CGI', 'Alcatel-Lucent ONT'],
  authMethod: 'ONT CGI Form Session Cookie',
  defaultGateways: ['192.168.1.254', '192.168.1.1'],
  capabilities: {
    readRouterInfo: true,
    readWifiSettings: true,
    writeWifiSettings: true,
    readWifiPassword: false, // Many Nokia ONT firmwares mask keys on read
    dualBand24: true,
    dualBand5: true,
    toggleWifiRadio: true,
    listDevices: true,
    blockMacDevice: true,
    unblockMacDevice: true,
    readSignalStats: false,
    readChannelInfo: true,
    rebootRouter: true,
    guestWifi: false,
    blockAllInternet: false,
    supportedEncryptions: ['WPA2-PSK', 'WPA/WPA2-PSK', 'OPEN']
  },

  detectScore(probe: ProbeSnapshot): number {
    const body = probe.rootBody.toLowerCase();
    let score = 0;
    if (body.includes('nokia') || body.includes('alcatel-lucent') || body.includes('g-240w') || body.includes('g-2425')) {
      score += 75;
    }
    return score;
  },

  async connect(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({ method: 'GET', path: '/login.cgi' }).catch(() =>
      ctx.transport({ method: 'GET', path: '/' })
    );
    if (res.status >= 500) throw new RouterError('ROUTER_OFFLINE');
  },

  async authenticate(ctx: RouterConnectionContext, creds: RouterCredentials): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/login.cgi',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        name: creds.username.trim() || 'AdminGPON',
        pswd: creds.password
      }).toString()
    });
    if (res.status === 401 || res.body.toLowerCase().includes('invalid password')) {
      throw new RouterError('INVALID_CREDENTIALS');
    }
  },

  async getRouterInfo(ctx: RouterConnectionContext): Promise<RouterInfo> {
    const res = await ctx.transport({ method: 'GET', path: '/status.cgi' });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const json = tryParseJson<Record<string, unknown>>(res.body) || {};
    return {
      vendor: 'Nokia',
      model: String(json.model || 'Nokia ONT'),
      firmwareVersion: json.softwareVersion ? String(json.softwareVersion) : null,
      gatewayIp: new URL(ctx.baseUrl).hostname,
      wanConnected: typeof json.wanUp === 'boolean' ? json.wanUp : null,
      uptimeSeconds: typeof json.uptime === 'number' ? json.uptime : null,
      signalStrengthDbm: null,
      channelCongestionScore: null
    };
  },

  async getWifiSettings(ctx: RouterConnectionContext): Promise<WifiSettings> {
    const res = await ctx.transport({ method: 'GET', path: '/wlan_basic.cgi' });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const json = tryParseJson<{ band24?: Record<string, unknown>; band5?: Record<string, unknown> }>(res.body) || {};
    return {
      band24: json.band24
        ? {
            band: '2.4GHz',
            enabled: Boolean(json.band24.enabled ?? true),
            ssid: String(json.band24.ssid || ''),
            password: null,
            encryption: String(json.band24.encryption || 'WPA2-PSK'),
            channel: String(json.band24.channel || 'auto')
          }
        : null,
      band5: json.band5
        ? {
            band: '5GHz',
            enabled: Boolean(json.band5.enabled ?? true),
            ssid: String(json.band5.ssid || ''),
            password: null,
            encryption: String(json.band5.encryption || 'WPA2-PSK'),
            channel: String(json.band5.channel || 'auto')
          }
        : null
    };
  },

  async updateWifiSettings(ctx: RouterConnectionContext, update: WifiUpdateInput): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/wlan_basic.cgi',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        band: update.band === '5GHz' ? '5g' : '24g',
        enabled: update.enabled === false ? '0' : '1',
        ssid: update.ssid,
        encryption: update.encryption,
        ...(update.password !== undefined ? { psk: update.password } : {}),
        ...(update.channel ? { channel: update.channel } : {})
      }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async getConnectedDevices(ctx: RouterConnectionContext) {
    const res = await ctx.transport({ method: 'GET', path: '/lan_dhcp.cgi' });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const json = tryParseJson<{ hosts?: Array<{ name?: string; ip?: string; mac?: string; blocked?: boolean }> }>(res.body);
    const hosts = json?.hosts || [];
    const blockedMacs: string[] = [];
    const connected: ConnectedDevice[] = hosts
      .filter((h) => Boolean(h.mac))
      .map((h, idx) => {
        const mac = normalizeMac(h.mac!);
        if (h.blocked) blockedMacs.push(mac);
        return {
          id: mac,
          hostname: h.name || `Host-${idx + 1}`,
          ipAddress: h.ip || '',
          macAddress: mac,
          vendor: lookupMacVendor(mac),
          connectionType: 'Unknown',
          lastSeen: null,
          status: h.blocked ? 'blocked' : 'online'
        };
      });
    return { connected, blockedMacs };
  },

  async blockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/mac_filter.cgi',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ action: 'block', mac: normalizeMac(macAddress) }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async unblockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/mac_filter.cgi',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ action: 'unblock', mac: normalizeMac(macAddress) }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async rebootRouter(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/reboot.cgi',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ action: 'reboot' }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async disconnect(ctx: RouterConnectionContext): Promise<void> {
    await ctx.transport({ method: 'GET', path: '/logout.cgi' }).catch(() => undefined);
  }
};
