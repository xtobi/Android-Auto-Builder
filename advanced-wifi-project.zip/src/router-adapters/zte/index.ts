import { lookupMacVendor, normalizeMac } from '../../utils/networkSecurity';
import {
  ConnectedDevice,
  ProbeSnapshot,
  RouterAdapter,
  RouterConnectionContext,
  RouterCredentials,
  RouterError,
  RouterInfo,
  WifiSettings,
  WifiUpdateInput
} from '../types';
import { extractXmlBlocks, extractXmlTag } from '../xmlUtils';

export const zteAdapter: RouterAdapter = {
  id: 'zte',
  vendor: 'ZTE',
  supportedModels: ['ZXHN F660 / F670L / F680', 'ZXHN H108N / H267A', 'MF286 / MC801A'],
  firmwareHints: ['ZTE Lua Web Engine', 'ZXHN XML Config'],
  authMethod: 'ZTE Lua Session Token + Form Auth',
  defaultGateways: ['192.168.1.1', '192.168.0.1'],
  capabilities: {
    readRouterInfo: true,
    readWifiSettings: true,
    writeWifiSettings: true,
    readWifiPassword: true,
    dualBand24: true,
    dualBand5: true,
    toggleWifiRadio: true,
    listDevices: true,
    blockMacDevice: true,
    unblockMacDevice: true,
    readSignalStats: false,
    readChannelInfo: true,
    rebootRouter: true,
    guestWifi: true,
    blockAllInternet: true,
    supportedEncryptions: ['WPA2-PSK', 'WPA/WPA2-PSK', 'OPEN']
  },

  detectScore(probe: ProbeSnapshot): number {
    const body = probe.rootBody.toLowerCase();
    let score = 0;
    if (body.includes('zte') || body.includes('zxhn') || body.includes('getpage.lua')) score += 65;
    if (body.includes('_sessiontoken')) score += 25;
    return score;
  },

  async connect(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({ method: 'GET', path: '/common_page/login.lua' }).catch(() =>
      ctx.transport({ method: 'GET', path: '/' })
    );
    const tokenMatch = res.body.match(/_sessionToken\s*=\s*"([^"]+)"/);
    if (tokenMatch) ctx.sessionState.sessionToken = tokenMatch[1];
  },

  async authenticate(ctx: RouterConnectionContext, creds: RouterCredentials): Promise<void> {
    const body = new URLSearchParams({
      action: 'login',
      Username: creds.username.trim() || 'user',
      Password: creds.password,
      _sessionToken: ctx.sessionState.sessionToken || ''
    }).toString();

    const res = await ctx.transport({
      method: 'POST',
      path: '/common_page/login.lua',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body
    });

    if (res.status === 401 || res.body.includes('login_err') || res.body.includes('LoginErrMsg')) {
      throw new RouterError('INVALID_CREDENTIALS');
    }
  },

  async getRouterInfo(ctx: RouterConnectionContext): Promise<RouterInfo> {
    const res = await ctx.transport({ method: 'GET', path: '/getpage.lua?pid=1002&nextpage=Status_DeviceInfo_t.lp' });
    if (res.status === 401 || res.body.includes('login.lua')) throw new RouterError('SESSION_EXPIRED');
    return {
      vendor: 'ZTE',
      model: extractXmlTag(res.body, 'ModelName') || 'ZTE ZXHN Router',
      firmwareVersion: extractXmlTag(res.body, 'SoftwareVer'),
      gatewayIp: new URL(ctx.baseUrl).hostname,
      wanConnected: res.body.includes('Connected') ? true : null,
      uptimeSeconds: null,
      signalStrengthDbm: null,
      channelCongestionScore: null
    };
  },

  async getWifiSettings(ctx: RouterConnectionContext): Promise<WifiSettings> {
    const res = await ctx.transport({ method: 'GET', path: '/getpage.lua?pid=1002&nextpage=Net_WlanBasic_t.lp' });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const instances = extractXmlBlocks(res.body, 'Instance');
    const inst24 = instances[0] || res.body;
    const inst5 = instances[1] || null;
    return {
      band24: {
        band: '2.4GHz',
        enabled: extractXmlTag(inst24, 'Enable') !== '0',
        ssid: extractXmlTag(inst24, 'ESSID') || extractXmlTag(inst24, 'SSID') || '',
        password: extractXmlTag(inst24, 'KeyPassphrase'),
        encryption: extractXmlTag(inst24, 'BeaconType') || 'WPA2-PSK',
        channel: extractXmlTag(inst24, 'Channel') || '0'
      },
      band5: inst5
        ? {
            band: '5GHz',
            enabled: extractXmlTag(inst5, 'Enable') !== '0',
            ssid: extractXmlTag(inst5, 'ESSID') || extractXmlTag(inst5, 'SSID') || '',
            password: extractXmlTag(inst5, 'KeyPassphrase'),
            encryption: extractXmlTag(inst5, 'BeaconType') || 'WPA2-PSK',
            channel: extractXmlTag(inst5, 'Channel') || '0'
          }
        : null
    };
  },

  async updateWifiSettings(ctx: RouterConnectionContext, update: WifiUpdateInput): Promise<void> {
    const body = new URLSearchParams({
      IF_ACTION: 'apply',
      IF_OBJNAME: 'OBJ_WLANCONFIG_ID',
      IF_INDEX: update.band === '5GHz' ? '1' : '0',
      Enable: update.enabled === false ? '0' : '1',
      ESSID: update.ssid,
      BeaconType: update.encryption,
      ...(update.password !== undefined ? { KeyPassphrase: update.password } : {}),
      ...(update.channel ? { Channel: update.channel } : {})
    }).toString();

    const res = await ctx.transport({
      method: 'POST',
      path: '/getpage.lua?pid=1002&nextpage=Net_WlanBasic_t.lp',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body
    });
    if (res.status >= 400 || res.body.includes('IF_ERRORSTR')) {
      throw new RouterError('SETTINGS_APPLY_FAILED');
    }
  },

  async getConnectedDevices(ctx: RouterConnectionContext) {
    const res = await ctx.transport({ method: 'GET', path: '/getpage.lua?pid=1002&nextpage=Status_LanUsers_t.lp' });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const blocks = extractXmlBlocks(res.body, 'Instance');
    const connected: ConnectedDevice[] = blocks
      .map((block, idx) => {
        const rawMac = extractXmlTag(block, 'MACAddress') || '';
        const mac = normalizeMac(rawMac);
        if (!mac) return null;
        return {
          id: mac,
          hostname: extractXmlTag(block, 'HostName') || `Device-${idx + 1}`,
          ipAddress: extractXmlTag(block, 'IPAddress') || '',
          macAddress: mac,
          vendor: lookupMacVendor(mac),
          connectionType: (extractXmlTag(block, 'InterfaceType') || '').includes('802.11') ? 'Wi-Fi' : 'Ethernet',
          lastSeen: extractXmlTag(block, 'LeaseTimeRemaining'),
          status: 'online'
        } as ConnectedDevice;
      })
      .filter((d): d is ConnectedDevice => d !== null);
    return { connected, blockedMacs: [] };
  },

  async blockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const body = new URLSearchParams({
      IF_ACTION: 'apply',
      IF_OBJNAME: 'OBJ_MACFILTER_ID',
      MACAddress: normalizeMac(macAddress),
      Enable: '1'
    }).toString();
    const res = await ctx.transport({
      method: 'POST',
      path: '/getpage.lua?pid=1002&nextpage=Sec_MacFilter_t.lp',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async unblockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const body = new URLSearchParams({
      IF_ACTION: 'delete',
      IF_OBJNAME: 'OBJ_MACFILTER_ID',
      MACAddress: normalizeMac(macAddress)
    }).toString();
    const res = await ctx.transport({
      method: 'POST',
      path: '/getpage.lua?pid=1002&nextpage=Sec_MacFilter_t.lp',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async rebootRouter(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/getpage.lua?pid=1002&nextpage=Mgr_Dev_Reboot_t.lp',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ IF_ACTION: 'Restart', _sessionToken: ctx.sessionState.sessionToken || '' }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async setGuestWifiEnabled(ctx: RouterConnectionContext, enabled: boolean): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/getpage.lua?pid=1002&nextpage=Net_WlanBasic_t.lp',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        IF_ACTION: 'apply',
        IF_OBJNAME: 'OBJ_WLANCONFIG_ID',
        IF_INDEX: '4',
        Enable: enabled ? '1' : '0'
      }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async setInternetAccessPaused(ctx: RouterConnectionContext, paused: boolean): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/getpage.lua?pid=1002&nextpage=Net_WAN_t.lp',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        IF_ACTION: 'apply',
        IF_OBJNAME: 'OBJ_WANIP_ID',
        Enable: paused ? '0' : '1'
      }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async disconnect(ctx: RouterConnectionContext): Promise<void> {
    await ctx.transport({ method: 'POST', path: '/common_page/login.lua?action=logout' }).catch(() => undefined);
  }
};
