import { lookupMacVendor, normalizeMac } from '../../utils/networkSecurity';
import {
  ConnectedDevice,
  ProbeSnapshot,
  RouterAdapter,
  RouterConnectionContext,
  RouterCredentials,
  RouterError,
  RouterInfo,
  WifiSettings,
  WifiUpdateInput
} from '../types';
import { escapeXml, extractXmlTag } from '../xmlUtils';

function buildNetgearSoap(service: string, action: string, bodyXml: string): string {
  return `<?xml version="1.0" encoding="utf-8"?><v:Envelope xmlns:v="http://schemas.xmlsoap.org/soap/envelope/"><v:Body><M:${action} xmlns:M="urn:NETGEAR-ROUTER:service:${service}:1">${bodyXml}</M:${action}></v:Body></v:Envelope>`;
}

export const netgearAdapter: RouterAdapter = {
  id: 'netgear',
  vendor: 'Netgear',
  supportedModels: ['Nighthawk R7000 / RAX50 / RAX80', 'Orbi RBK Series', 'DGN2200'],
  firmwareHints: ['Netgear SOAP /soap/server_sa/'],
  authMethod: 'Netgear SOAP DeviceConfig:Authenticate',
  defaultGateways: ['192.168.1.1', '192.168.0.1', 'routerlogin.net'],
  capabilities: {
    readRouterInfo: true,
    readWifiSettings: true,
    writeWifiSettings: true,
    readWifiPassword: true,
    dualBand24: true,
    dualBand5: true,
    toggleWifiRadio: false,
    listDevices: true,
    blockMacDevice: true,
    unblockMacDevice: true,
    readSignalStats: false,
    readChannelInfo: true,
    rebootRouter: true,
    guestWifi: true,
    blockAllInternet: false,
    supportedEncryptions: ['WPA2-PSK', 'WPA/WPA2-PSK', 'OPEN']
  },

  detectScore(probe: ProbeSnapshot): number {
    const body = probe.rootBody.toLowerCase();
    return body.includes('netgear') || body.includes('nighthawk') || body.includes('routerlogin') ? 75 : 0;
  },

  async connect(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({ method: 'GET', path: '/currentsetting.htm' }).catch(() =>
      ctx.transport({ method: 'GET', path: '/' })
    );
    if (res.status === 0 || res.status >= 500) throw new RouterError('ROUTER_OFFLINE');
  },

  async authenticate(ctx: RouterConnectionContext, creds: RouterCredentials): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/soap/server_sa/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': 'urn:NETGEAR-ROUTER:service:ParentalControl:1#Authenticate'
      },
      body: buildNetgearSoap(
        'ParentalControl',
        'Authenticate',
        `<NewUsername>${escapeXml(creds.username.trim() || 'admin')}</NewUsername><NewPassword>${escapeXml(creds.password)}</NewPassword>`
      )
    });
    if (res.status === 401 || res.body.includes('401') || res.body.includes('Unauthorized')) {
      throw new RouterError('INVALID_CREDENTIALS');
    }
  },

  async getRouterInfo(ctx: RouterConnectionContext): Promise<RouterInfo> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/soap/server_sa/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': 'urn:NETGEAR-ROUTER:service:DeviceInfo:1#GetInfo'
      },
      body: buildNetgearSoap('DeviceInfo', 'GetInfo', '')
    });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    return {
      vendor: 'Netgear',
      model: extractXmlTag(res.body, 'ModelName') || 'Netgear Router',
      firmwareVersion: extractXmlTag(res.body, 'Firmwareversion'),
      gatewayIp: new URL(ctx.baseUrl).hostname,
      wanConnected: null,
      uptimeSeconds: null,
      signalStrengthDbm: null,
      channelCongestionScore: null
    };
  },

  async getWifiSettings(ctx: RouterConnectionContext): Promise<WifiSettings> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/soap/server_sa/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': 'urn:NETGEAR-ROUTER:service:WLANConfiguration:1#GetInfo'
      },
      body: buildNetgearSoap('WLANConfiguration', 'GetInfo', '')
    });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    return {
      band24: {
        band: '2.4GHz',
        enabled: extractXmlTag(res.body, 'NewEnable') !== '0',
        ssid: extractXmlTag(res.body, 'NewSSID') || '',
        password: extractXmlTag(res.body, 'NewWPAPassphrase'),
        encryption: extractXmlTag(res.body, 'NewBasicEncryptionModes') || 'WPA2-PSK',
        channel: extractXmlTag(res.body, 'NewChannel') || 'Auto'
      },
      band5: null
    };
  },

  async updateWifiSettings(ctx: RouterConnectionContext, update: WifiUpdateInput): Promise<void> {
    const action = update.band === '5GHz' ? 'Set5GInfo' : 'SetInfo';
    const res = await ctx.transport({
      method: 'POST',
      path: '/soap/server_sa/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': `urn:NETGEAR-ROUTER:service:WLANConfiguration:1#${action}`
      },
      body: buildNetgearSoap(
        'WLANConfiguration',
        action,
        `<NewSSID>${escapeXml(update.ssid)}</NewSSID><NewBasicEncryptionModes>${escapeXml(update.encryption)}</NewBasicEncryptionModes>${update.password !== undefined ? `<NewWPAPassphrase>${escapeXml(update.password)}</NewWPAPassphrase>` : ''}`
      )
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async getConnectedDevices(ctx: RouterConnectionContext) {
    const res = await ctx.transport({
      method: 'POST',
      path: '/soap/server_sa/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': 'urn:NETGEAR-ROUTER:service:DeviceInfo:1#GetAttachDevice2'
      },
      body: buildNetgearSoap('DeviceInfo', 'GetAttachDevice2', '')
    });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const listText = extractXmlTag(res.body, 'NewAttachDevice') || '';
    const connected: ConnectedDevice[] = listText
      .split('@')
      .slice(1)
      .map((row, idx) => {
        const cols = row.split(';');
        const ip = cols[1] || '';
        const name = cols[2] || `Device-${idx + 1}`;
        const rawMac = cols[3] || '';
        const mac = normalizeMac(rawMac);
        if (!mac) return null;
        return {
          id: mac,
          hostname: name,
          ipAddress: ip,
          macAddress: mac,
          vendor: lookupMacVendor(mac),
          connectionType: (cols[4] || '').includes('5G') ? 'Wi-Fi 5GHz' : 'Wi-Fi',
          lastSeen: null,
          status: 'online'
        } as ConnectedDevice;
      })
      .filter((d): d is ConnectedDevice => d !== null);
    return { connected, blockedMacs: [] };
  },

  async blockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/soap/server_sa/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': 'urn:NETGEAR-ROUTER:service:DeviceConfig:1#SetBlockDeviceByMAC'
      },
      body: buildNetgearSoap(
        'DeviceConfig',
        'SetBlockDeviceByMAC',
        `<NewAllowOrBlock>Block</NewAllowOrBlock><NewMACAddress>${escapeXml(normalizeMac(macAddress))}</NewMACAddress>`
      )
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async unblockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/soap/server_sa/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': 'urn:NETGEAR-ROUTER:service:DeviceConfig:1#SetBlockDeviceByMAC'
      },
      body: buildNetgearSoap(
        'DeviceConfig',
        'SetBlockDeviceByMAC',
        `<NewAllowOrBlock>Allow</NewAllowOrBlock><NewMACAddress>${escapeXml(normalizeMac(macAddress))}</NewMACAddress>`
      )
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async rebootRouter(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/soap/server_sa/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': 'urn:NETGEAR-ROUTER:service:DeviceConfig:1#Reboot'
      },
      body: buildNetgearSoap('DeviceConfig', 'Reboot', '')
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async setGuestWifiEnabled(ctx: RouterConnectionContext, enabled: boolean): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/soap/server_sa/',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': 'urn:NETGEAR-ROUTER:service:WLANConfiguration:1#SetGuestAccessEnabled2'
      },
      body: buildNetgearSoap(
        'WLANConfiguration',
        'SetGuestAccessEnabled2',
        `<NewGuestAccessEnabled>${enabled ? '1' : '0'}</NewGuestAccessEnabled>`
      )
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async disconnect(): Promise<void> {
    return;
  }
};
