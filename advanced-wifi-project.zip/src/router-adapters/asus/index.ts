import { lookupMacVendor, normalizeMac } from '../../utils/networkSecurity';
import {
  ConnectedDevice,
  ProbeSnapshot,
  RouterAdapter,
  RouterConnectionContext,
  RouterCredentials,
  RouterError,
  RouterInfo,
  WifiSettings,
  WifiUpdateInput
} from '../types';
import { tryParseJson } from '../xmlUtils';

export const asusAdapter: RouterAdapter = {
  id: 'asus',
  vendor: 'ASUS',
  supportedModels: ['RT-AX55 / RT-AX58U / RT-AX86U', 'RT-AC68U / RT-AC86U', 'ZenWiFi'],
  firmwareHints: ['AsusWRT / AsusWRT-Merlin HTTP API'],
  authMethod: 'AsusWRT /login.cgi asus_token',
  defaultGateways: ['192.168.50.1', '192.168.1.1', 'router.asus.com'],
  capabilities: {
    readRouterInfo: true,
    readWifiSettings: true,
    writeWifiSettings: true,
    readWifiPassword: true,
    dualBand24: true,
    dualBand5: true,
    toggleWifiRadio: true,
    listDevices: true,
    blockMacDevice: true,
    unblockMacDevice: true,
    readSignalStats: true,
    readChannelInfo: true,
    rebootRouter: true,
    guestWifi: true,
    blockAllInternet: true,
    supportedEncryptions: ['WPA2-PSK', 'WPA/WPA2-PSK', 'WPA3-SAE', 'OPEN']
  },

  detectScore(probe: ProbeSnapshot): number {
    const body = probe.rootBody.toLowerCase();
    return body.includes('asuswrt') || body.includes('asus_token') || body.includes('rt-ax') || body.includes('rt-ac')
      ? 75
      : 0;
  },

  async connect(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({ method: 'GET', path: '/Main_Login.asp' }).catch(() =>
      ctx.transport({ method: 'GET', path: '/' })
    );
    if (res.status === 0 || res.status >= 500) throw new RouterError('ROUTER_OFFLINE');
  },

  async authenticate(ctx: RouterConnectionContext, creds: RouterCredentials): Promise<void> {
    const authToken = btoa(`${creds.username.trim() || 'admin'}:${creds.password}`);
    const res = await ctx.transport({
      method: 'POST',
      path: '/login.cgi',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ login_authorization: authToken }).toString()
    });
    const json = tryParseJson<{ asus_token?: string; error_status?: string }>(res.body);
    if (res.status === 401 || json?.error_status || !json?.asus_token) {
      throw new RouterError('INVALID_CREDENTIALS');
    }
    ctx.sessionState.asusToken = json.asus_token;
  },

  async getRouterInfo(ctx: RouterConnectionContext): Promise<RouterInfo> {
    const res = await ctx.transport({
      method: 'GET',
      path: '/appGet.cgi?hook=nvram_get(productid);nvram_get(firmver);nvram_get(wan0_state_t)'
    });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const json = tryParseJson<Record<string, string>>(res.body) || {};
    return {
      vendor: 'ASUS',
      model: json.productid || 'ASUS Router',
      firmwareVersion: json.firmver || null,
      gatewayIp: new URL(ctx.baseUrl).hostname,
      wanConnected: json.wan0_state_t ? json.wan0_state_t === '2' : null,
      uptimeSeconds: null,
      signalStrengthDbm: null,
      channelCongestionScore: null
    };
  },

  async getWifiSettings(ctx: RouterConnectionContext): Promise<WifiSettings> {
    const res = await ctx.transport({
      method: 'GET',
      path: '/appGet.cgi?hook=nvram_get(wl0_ssid);nvram_get(wl0_wpa_psk);nvram_get(wl0_auth_mode_x);nvram_get(wl0_radio);nvram_get(wl0_channel);nvram_get(wl1_ssid);nvram_get(wl1_wpa_psk);nvram_get(wl1_auth_mode_x);nvram_get(wl1_radio);nvram_get(wl1_channel)'
    });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const json = tryParseJson<Record<string, string>>(res.body) || {};
    return {
      band24: {
        band: '2.4GHz',
        enabled: json.wl0_radio !== '0',
        ssid: json.wl0_ssid || '',
        password: json.wl0_wpa_psk ?? null,
        encryption: json.wl0_auth_mode_x || 'WPA2-PSK',
        channel: json.wl0_channel || '0'
      },
      band5: json.wl1_ssid
        ? {
            band: '5GHz',
            enabled: json.wl1_radio !== '0',
            ssid: json.wl1_ssid || '',
            password: json.wl1_wpa_psk ?? null,
            encryption: json.wl1_auth_mode_x || 'WPA2-PSK',
            channel: json.wl1_channel || '0'
          }
        : null
    };
  },

  async updateWifiSettings(ctx: RouterConnectionContext, update: WifiUpdateInput): Promise<void> {
    const prefix = update.band === '5GHz' ? 'wl1' : 'wl0';
    const payload: Record<string, string> = {
      action_mode: 'apply',
      rc_service: 'restart_wireless',
      [`${prefix}_ssid`]: update.ssid,
      [`${prefix}_radio`]: update.enabled === false ? '0' : '1',
      [`${prefix}_auth_mode_x`]: update.encryption
    };
    if (update.password !== undefined) payload[`${prefix}_wpa_psk`] = update.password;
    if (update.channel) payload[`${prefix}_channel`] = update.channel;

    const res = await ctx.transport({
      method: 'POST',
      path: '/applyapp.cgi',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(payload).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async getConnectedDevices(ctx: RouterConnectionContext) {
    const res = await ctx.transport({ method: 'GET', path: '/appGet.cgi?hook=get_clientlist()' });
    if (res.status === 401) throw new RouterError('SESSION_EXPIRED');
    const json = tryParseJson<{ get_clientlist?: Record<string, { name?: string; ip?: string; isWL?: string; rssi?: string }> }>(res.body);
    const map = json?.get_clientlist || {};
    const connected: ConnectedDevice[] = [];
    for (const [rawMac, entry] of Object.entries(map)) {
      if (!rawMac.includes(':')) continue;
      const mac = normalizeMac(rawMac);
      connected.push({
        id: mac,
        hostname: entry.name || mac,
        ipAddress: entry.ip || '',
        macAddress: mac,
        vendor: lookupMacVendor(mac),
        connectionType: entry.isWL === '2' ? 'Wi-Fi 5GHz' : entry.isWL === '1' ? 'Wi-Fi 2.4GHz' : 'Ethernet',
        lastSeen: null,
        status: 'online',
        signalDbm: entry.rssi ? Number(entry.rssi) : null
      });
    }
    return { connected, blockedMacs: [] };
  },

  async blockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/applyapp.cgi',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        action_mode: 'apply',
        rc_service: 'restart_firewall',
        wl_macmode: 'deny',
        wl_maclist_x: `<${normalizeMac(macAddress)}`
      }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async unblockDevice(ctx: RouterConnectionContext, macAddress: string): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/applyapp.cgi',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        action_mode: 'apply',
        rc_service: 'restart_firewall',
        wl_macmode: 'disabled',
        remove_mac: normalizeMac(macAddress)
      }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async rebootRouter(ctx: RouterConnectionContext): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/applyapp.cgi',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ action_mode: 'reboot' }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async getGuestWifiEnabled(ctx: RouterConnectionContext): Promise<boolean | null> {
    const res = await ctx.transport({ method: 'GET', path: '/appGet.cgi?hook=nvram_get(wl0.1_bss_enabled)' }).catch(() => null);
    if (!res || res.status >= 400) return null;
    const json = tryParseJson<Record<string, string>>(res.body);
    if (!json || json['wl0.1_bss_enabled'] === undefined) return null;
    return json['wl0.1_bss_enabled'] === '1';
  },

  async setGuestWifiEnabled(ctx: RouterConnectionContext, enabled: boolean): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/applyapp.cgi',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        action_mode: 'apply',
        rc_service: 'restart_wireless',
        'wl0.1_bss_enabled': enabled ? '1' : '0'
      }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async setInternetAccessPaused(ctx: RouterConnectionContext, paused: boolean): Promise<void> {
    const res = await ctx.transport({
      method: 'POST',
      path: '/applyapp.cgi',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        action_mode: 'apply',
        rc_service: 'restart_wan',
        wan0_enable: paused ? '0' : '1'
      }).toString()
    });
    if (res.status >= 400) throw new RouterError('SETTINGS_APPLY_FAILED');
  },

  async disconnect(ctx: RouterConnectionContext): Promise<void> {
    await ctx.transport({ method: 'GET', path: '/Logout.asp' }).catch(() => undefined);
  }
};
