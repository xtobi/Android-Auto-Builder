#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const distDir = path.join(rootDir, 'dist');
const androidAssetsWww = path.join(rootDir, 'android', 'app', 'src', 'main', 'assets', 'www');

if (!fs.existsSync(distDir)) {
  console.error('[android:sync] dist/ directory not found. Run `npm run build` first.');
  process.exit(1);
}

fs.rmSync(androidAssetsWww, { recursive: true, force: true });
fs.mkdirSync(androidAssetsWww, { recursive: true });
fs.cpSync(distDir, androidAssetsWww, { recursive: true, force: true });

const copiedFiles = fs.readdirSync(androidAssetsWww);
console.log(`[android:sync] Synced ${copiedFiles.length} root entries from dist/ -> android/app/src/main/assets/www`);
