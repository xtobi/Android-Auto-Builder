import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const rulesContent = fs.readFileSync(path.resolve(process.cwd(), 'firestore.rules'), 'utf8');
const blueprint = JSON.parse(fs.readFileSync(path.resolve(process.cwd(), 'firebase-blueprint.json'), 'utf8'));

test('firestore.rules includes default-deny global safety net and rules_version 2', () => {
  assert.match(rulesContent, /rules_version\s*=\s*'2';/);
  assert.match(rulesContent, /match \/\{document=\*\*\}\s*\{\s*allow read, write: if false;\s*\}/);
});

test('firestore.rules enforces verified email and strict owner PII isolation on /users/{userId}', () => {
  assert.match(rulesContent, /request\.auth\.token\.email_verified == true/);
  assert.match(rulesContent, /match \/users\/\{userId\}\s*\{[\s\S]*allow get: if isValidId\(userId\) && isOwner\(userId\);/);
  assert.match(rulesContent, /allow list: if false;/);
});

test('firestore.rules covers every collection defined in firebase-blueprint.json', () => {
  const collections = Object.keys(blueprint.firestore);
  assert.ok(collections.includes('/users/{userId}'));
  assert.ok(collections.includes('/users/{userId}/activity_logs/{logId}'));
  assert.ok(collections.includes('/users/{userId}/speed_tests/{testId}'));
  assert.ok(collections.includes('/users/{userId}/device_aliases/{macKey}'));
  assert.ok(collections.includes('/router_definitions/{adapterId}'));

  assert.match(rulesContent, /match \/activity_logs\/\{logId\}/);
  assert.match(rulesContent, /match \/speed_tests\/\{testId\}/);
  assert.match(rulesContent, /match \/device_aliases\/\{macKey\}/);
  assert.match(rulesContent, /match \/router_definitions\/\{adapterId\}/);
});

test('firestore.rules never allows storing routerPassword or secrets in UserProfile or ActivityLog', () => {
  assert.equal(rulesContent.includes('routerPassword'), false);
  assert.equal('routerPassword' in blueprint.entities.UserProfile.properties, false);
  assert.equal('routerPassword' in blueprint.entities.ActivityLogEntry.properties, false);
});

test('firestore.rules enforces request.time temporal integrity and Master Gate exists()', () => {
  assert.match(rulesContent, /incoming\(\)\.createdAt == request\.time/);
  assert.match(rulesContent, /incoming\(\)\.updatedAt == request\.time/);
  assert.match(rulesContent, /exists\(\/databases\/\$\(database\)\/documents\/users\/\$\(userId\)\)/);
});

test('firestore.rules allows owner-scoped subcollection list queries without unindexed resource.data.userId filter', () => {
  assert.match(rulesContent, /match \/activity_logs\/\{logId\}[\s\S]*allow list: if isValidId\(userId\) && isOwner\(userId\);/);
  assert.match(rulesContent, /match \/speed_tests\/\{testId\}[\s\S]*allow list: if isValidId\(userId\) && isOwner\(userId\);/);
  assert.match(rulesContent, /match \/device_aliases\/\{macKey\}[\s\S]*allow list: if isValidId\(userId\) && isOwner\(userId\);/);
});

