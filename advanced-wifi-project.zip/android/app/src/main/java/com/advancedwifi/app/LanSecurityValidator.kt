package com.advancedwifi.app

import java.net.Inet4Address
import java.net.InetAddress
import java.net.URI
import java.util.Locale

internal object LanSecurityValidator {

    private val KNOWN_ROUTER_HOSTNAMES = setOf(
        "tplinkwifi.net",
        "tplinklogin.net",
        "mwlogin.net",
        "router.asus.com",
        "www.routerlogin.net",
        "routerlogin.net",
        "tendawifi.com",
        "dlinkrouter.local",
        "fritz.box",
        "myrouter.local",
        "huawei.local"
    )

    data class ValidationResult(
        val valid: Boolean,
        val normalizedUrl: String = "",
        val hostname: String = "",
        val reason: String = ""
    )

    fun isPrivateLanIpv4(host: String): Boolean {
        val parts = host.split('.')
        if (parts.size != 4) return false
        val nums = IntArray(4)
        for (i in 0 until 4) {
            val part = parts[i]
            if (part.isEmpty() || part.length > 3 || !part.all { it.isDigit() }) return false
            val n = part.toIntOrNull() ?: return false
            if (n < 0 || n > 255) return false
            nums[i] = n
        }

        val a = nums[0]
        val b = nums[1]
        if (a == 10) return true
        if (a == 172 && b in 16..31) return true
        if (a == 192 && b == 168) return true
        return false
    }

    fun validateLanTargetUrl(rawUrl: String?): ValidationResult {
        val trimmed = rawUrl?.trim().orEmpty()
        if (trimmed.isEmpty()) {
            return ValidationResult(valid = false, reason = "empty_url")
        }

        val uri = try {
            URI(trimmed)
        } catch (_: Exception) {
            return ValidationResult(valid = false, reason = "malformed_url")
        }

        val scheme = uri.scheme?.lowercase(Locale.US).orEmpty()
        if (scheme != "http" && scheme != "https") {
            return ValidationResult(valid = false, reason = "invalid_scheme")
        }

        if (!uri.rawUserInfo.isNullOrEmpty()) {
            return ValidationResult(valid = false, reason = "embedded_credentials")
        }

        val port = uri.port
        if (port != -1 && (port < 1 || port > 65535)) {
            return ValidationResult(valid = false, reason = "invalid_port")
        }

        val rawHost = uri.host?.lowercase(Locale.US)?.trim().orEmpty()
        if (rawHost.isEmpty()) {
            return ValidationResult(valid = false, reason = "missing_host")
        }

        if (
            rawHost.startsWith("169.254.") ||
            rawHost == "0.0.0.0" ||
            rawHost.startsWith("fe80:") ||
            rawHost.startsWith("[fe80:")
        ) {
            return ValidationResult(valid = false, hostname = rawHost, reason = "blocked_internal_target")
        }

        if (
            rawHost == "localhost" ||
            rawHost.startsWith("127.") ||
            rawHost == "::1" ||
            rawHost == "[::1]"
        ) {
            return ValidationResult(valid = false, hostname = rawHost, reason = "blocked_loopback")
        }

        val allowedHost = isPrivateLanIpv4(rawHost) ||
            KNOWN_ROUTER_HOSTNAMES.contains(rawHost) ||
            rawHost.endsWith(".local")

        if (!allowedHost) {
            return ValidationResult(valid = false, hostname = rawHost, reason = "non_lan_target")
        }

        return ValidationResult(
            valid = true,
            normalizedUrl = uri.toString(),
            hostname = rawHost
        )
    }

    fun isResolvedAddressSafe(addr: InetAddress): Boolean {
        if (addr.isAnyLocalAddress || addr.isLoopbackAddress || addr.isLinkLocalAddress || addr.isMulticastAddress) {
            return false
        }
        return addr is Inet4Address && addr.isSiteLocalAddress
    }

    fun redactSecrets(input: String?): String {
        if (input.isNullOrBlank()) return ""
        return input
            .replace(Regex("""(password|passwd|psw|token|cookie|sid)=[^&\s;]+""", RegexOption.IGNORE_CASE), "$1=[REDACTED]")
            .take(300)
    }
}
