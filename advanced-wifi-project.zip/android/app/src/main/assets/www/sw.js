const CACHE_NAME = 'advanced-wifi-lan-v1';
const SHELL_URLS = ['/', '/index.html', '/favicon.svg', '/manifest.webmanifest'];

function isNetworkOnlyRequest(url) {
  const host = url.hostname.toLowerCase();
  if (url.pathname.startsWith('/api/')) return true;
  if (
    host === '127.0.0.1' ||
    host === 'localhost' ||
    host.startsWith('192.168.') ||
    host.startsWith('10.') ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(host) ||
    host.endsWith('.local')
  ) {
    return true;
  }
  if (url.pathname.endsWith('.cgi') || url.pathname.endsWith('.asp')) {
    return true;
  }
  return false;
}

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(SHELL_URLS).catch(() => undefined))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  let url;
  try {
    url = new URL(event.request.url);
  } catch {
    return;
  }

  // Strictly bypass API routes and local router/connector HTTP calls so real telemetry is never stale
  if (url.origin !== self.location.origin || isNetworkOnlyRequest(url)) {
    return;
  }

  // Network-first with cached shell fallback for offline local Wi-Fi operation
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        if (response && response.ok && response.type === 'basic') {
          const clone = response.clone();
          void caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
        }
        return response;
      })
      .catch(async () => {
        const cached = await caches.match(event.request);
        if (cached) return cached;
        if (event.request.mode === 'navigate') {
          const shell = await caches.match('/index.html');
          if (shell) return shell;
        }
        return new Response('Offline LAN shell unavailable', { status: 503 });
      })
  );
});
