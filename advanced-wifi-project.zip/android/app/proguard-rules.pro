# Preserve @JavascriptInterface methods exposed to the Advanced Wi-Fi WebView
-keepclassmembers class com.advancedwifi.app.NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
-keepattributes *Annotation*
