import 'dotenv/config';
import express, { type Request, type Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import { AdvancedWifiCoreEngine } from './server/coreEngine.ts';
import { createCoreApiRouter } from './server/coreRouter.ts';

interface ConvertSketchRequestBody {
  imageDataUrl?: unknown;
  userNote?: unknown;
  language?: unknown;
  targetWidthMeters?: unknown;
  targetHeightMeters?: unknown;
}

interface ParsedSketchRoom {
  name: string;
  category: string;
  xPct: number;
  yPct: number;
  wPct: number;
  hPct: number;
}

interface ParsedSketchResponse {
  rooms: ParsedSketchRoom[];
  suggestedSpanMeters?: {
    width?: number;
    height?: number;
  };
  routerPct?: {
    detected?: boolean;
    xPct?: number;
    yPct?: number;
  };
  summary?: string;
}

const DATA_URL_RE = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/;
const MAX_DATA_URL_LENGTH = 6_000_000;
const ALLOWED_LANGUAGES = new Set(['ar', 'en', 'fr']);
const ALLOWED_CATEGORIES = new Set([
  'living',
  'bedroom',
  'kitchen',
  'bathroom',
  'corridor',
  'office',
  'custom',
]);

function clampNumber(val: unknown, min: number, max: number, fallback: number): number {
  const num = typeof val === 'number' ? val : Number(val);
  if (!Number.isFinite(num)) return fallback;
  return Math.max(min, Math.min(max, num));
}

function getSystemInstruction(language: string): string {
  const langLabel =
    language === 'ar' ? 'Arabic' : language === 'fr' ? 'French' : 'English';

  return `You are an expert architectural floor plan parser for a Wi-Fi home survey application.
Your task is to analyze the user's hand-drawn or rough initial home floor plan sketch and convert every sketched room/zone into clean normalized rectangular bounding boxes that STRICTLY PRESERVE THE USER'S EXACT SPATIAL LAYOUT (same relative left/right/top/bottom positions, L-shape wings, central corridors, and proportional room sizes).

Strict Rules:
1. Do NOT invent extra rooms or rearrange rooms into a generic grid if the user drew an L-shape, corridor, wing, or asymmetric layout. Keep the exact spatial topology from the sketch.
2. Express coordinates xPct, yPct, wPct, hPct on a 0..100 scale relative to the full image canvas (xPct=left edge, yPct=top edge, wPct=width, hPct=height).
3. If two adjacent rooms share a wall in the sketch, align their neighboring edges closely so they form neat aligned rows/columns without awkward diagonal offsets.
4. Read any room labels written inside or next to drawn boxes (in Arabic, English, or French) and preserve them verbatim as the room "name". If a drawn room has no readable label, assign a concise architectural name in ${langLabel}.
5. Set "category" to one of: living, bedroom, kitchen, bathroom, corridor, office, custom.
6. If the sketch marks a router symbol (such as "R", "Router", "Wi-Fi", antenna icon, or "مودام"), set routerPct.detected=true and return its xPct, yPct (0..100). Otherwise set routerPct.detected=false.
7. Estimate realistic residential span meters in suggestedSpanMeters (typically 8..20m width/height depending on room count and proportions).
8. Provide a concise one-sentence "summary" in ${langLabel} describing what was extracted from the sketch.
9. Extract between 1 and 16 rooms.`;
}

function isRetryableGeminiError(err: unknown): boolean {
  const errStatus =
    typeof err === 'object' && err !== null && 'status' in err
      ? Number((err as { status?: unknown }).status)
      : NaN;
  if (errStatus === 429 || errStatus === 500 || errStatus === 502 || errStatus === 503 || errStatus === 504) {
    return true;
  }
  const raw = (err instanceof Error ? err.message : String(err)).toLowerCase();
  return (
    raw.includes('unavailable') ||
    raw.includes('overloaded') ||
    raw.includes('internal') ||
    raw.includes('resource_exhausted') ||
    raw.includes('timeout') ||
    raw.includes('etimedout') ||
    raw.includes('econnreset') ||
    raw.includes('fetch failed')
  );
}

async function waitMs(ms: number): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

function mapGeminiError(err: unknown): {
  status: number;
  code: string;
  message: string;
  upstreamStatus?: number;
} {
  const raw = err instanceof Error ? err.message : String(err);
  const errStatus =
    typeof err === 'object' && err !== null && 'status' in err
      ? Number((err as { status?: unknown }).status)
      : NaN;
  console.error('[convert-sketch] Gemini SDK error:', errStatus || '', raw.slice(0, 400));
  const lower = raw.toLowerCase();
  const upstreamStatus = Number.isFinite(errStatus) ? errStatus : undefined;

  if (
    errStatus === 401 ||
    errStatus === 403 ||
    lower.includes('api_key_invalid') ||
    lower.includes('api key not valid') ||
    lower.includes('api key') ||
    lower.includes('permission_denied') ||
    lower.includes('unauthenticated')
  ) {
    return {
      status: 403,
      code: 'GEMINI_AUTH_FAILED',
      message: 'Server Gemini API key was rejected or invalid. Check GEMINI_API_KEY in Settings > Secrets.',
      upstreamStatus,
    };
  }
  if (
    errStatus === 429 ||
    lower.includes('resource_exhausted') ||
    lower.includes('429') ||
    lower.includes('quota') ||
    lower.includes('rate limit')
  ) {
    return {
      status: 429,
      code: 'GEMINI_RATE_LIMITED',
      message: 'AI service rate limit or quota exceeded. Please wait briefly and try again.',
      upstreamStatus,
    };
  }
  if (errStatus === 404 || lower.includes('not_found') || lower.includes('404')) {
    return {
      status: 502,
      code: 'GEMINI_MODEL_UNAVAILABLE',
      message: 'Configured AI vision model is temporarily unavailable.',
      upstreamStatus,
    };
  }
  if (errStatus === 400 || lower.includes('invalid_argument')) {
    return {
      status: 400,
      code: 'GEMINI_BAD_REQUEST',
      message: 'The sketch image or parameters could not be processed. Try drawing clearer room boxes.',
      upstreamStatus,
    };
  }
  if (
    errStatus === 500 ||
    errStatus === 502 ||
    errStatus === 503 ||
    errStatus === 504 ||
    lower.includes('unavailable') ||
    lower.includes('overloaded')
  ) {
    return {
      status: 503,
      code: 'GEMINI_SERVICE_UNAVAILABLE',
      message: 'The Gemini AI service is temporarily busy. Please try again in a few seconds.',
      upstreamStatus,
    };
  }
  if (
    lower.includes('fetch failed') ||
    lower.includes('enotfound') ||
    lower.includes('econnrefused') ||
    lower.includes('etimedout') ||
    lower.includes('timeout') ||
    lower.includes('network')
  ) {
    return {
      status: 503,
      code: 'GEMINI_NETWORK_UNREACHABLE',
      message: 'Could not reach the Gemini AI service from the server right now. Please try again.',
      upstreamStatus,
    };
  }
  return {
    status: 502,
    code: 'GEMINI_UPSTREAM_ERROR',
    message: 'Could not interpret the sketch via AI service. Please refine the drawing and retry.',
    upstreamStatus,
  };
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '8mb' }));

  const coreEngine = new AdvancedWifiCoreEngine();
  app.use('/api/core', createCoreApiRouter(coreEngine));

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ ok: true });
  });

  app.post('/api/floor-plan/convert-sketch', async (req: Request, res: Response) => {
    const body = (req.body ?? {}) as ConvertSketchRequestBody;

    if (typeof body.imageDataUrl !== 'string' || body.imageDataUrl.length > MAX_DATA_URL_LENGTH) {
      res.status(400).json({
        error: 'INVALID_IMAGE',
        message: 'A valid PNG, JPEG, or WebP sketch image (under 6MB) is required.',
      });
      return;
    }

    const match = DATA_URL_RE.exec(body.imageDataUrl);
    if (!match) {
      res.status(400).json({
        error: 'INVALID_IMAGE_FORMAT',
        message: 'Sketch image must be a base64 PNG, JPEG, or WebP data URL.',
      });
      return;
    }

    const mimeType = `image/${match[1]}`;
    const base64Data = match[2];

    const language =
      typeof body.language === 'string' && ALLOWED_LANGUAGES.has(body.language)
        ? body.language
        : 'en';
    const userNote =
      typeof body.userNote === 'string' ? body.userNote.trim().slice(0, 300) : '';
    const hasTargetW =
      body.targetWidthMeters !== undefined &&
      body.targetWidthMeters !== null &&
      body.targetWidthMeters !== '';
    const hasTargetH =
      body.targetHeightMeters !== undefined &&
      body.targetHeightMeters !== null &&
      body.targetHeightMeters !== '';
    const targetW = hasTargetW ? clampNumber(body.targetWidthMeters, 5, 26, 12) : null;
    const targetH = hasTargetH ? clampNumber(body.targetHeightMeters, 5, 26, 9) : null;

    const apiKey = (process.env.GEMINI_API_KEY ?? '').trim();
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      res.status(503).json({
        error: 'GEMINI_API_KEY_MISSING',
        message: 'GEMINI_API_KEY is not configured on the server. Add GEMINI_API_KEY in Settings > Secrets to enable AI sketch conversion.',
      });
      return;
    }

    const userPromptParts: string[] = [
      'Convert this hand-drawn home floor plan sketch into structured rectangular room coordinates while preserving the exact spatial arrangement, wings, and relative sizes drawn.',
    ];
    if (userNote) {
      userPromptParts.push(`User layout notes: "${userNote}".`);
    }
    if (targetW !== null || targetH !== null) {
      userPromptParts.push(
        `Approximate outer dimensions requested by user: ${targetW ?? 'auto'}m width x ${targetH ?? 'auto'}m length.`
      );
    }

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
      });

      let response = null;
      let lastError: unknown = null;
      const modelCandidates = [
        { model: 'gemini-4-hydrogen', attempts: 2, timeoutMs: 35000 },
        { model: 'gemini-3.1-flash-lite', attempts: 1, timeoutMs: 35000 },
      ];

      outerLoop: for (const candidate of modelCandidates) {
        for (let attempt = 1; attempt <= candidate.attempts; attempt++) {
          let timer: ReturnType<typeof setTimeout> | undefined;
          try {
            const timeoutPromise = new Promise<never>((_resolve, reject) => {
              timer = setTimeout(
                () => reject(new Error(`Gemini upstream timeout after ${candidate.timeoutMs}ms`)),
                candidate.timeoutMs
              );
            });
            response = await Promise.race([
              ai.models.generateContent({
                model: candidate.model,
                contents: {
                  parts: [
                    { inlineData: { mimeType, data: base64Data } },
                    { text: userPromptParts.join(' ') },
                  ],
                },
                config: {
                  systemInstruction: getSystemInstruction(language),
                  thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
                  responseMimeType: 'application/json',
                  responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                      rooms: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            name: { type: Type.STRING },
                            category: { type: Type.STRING },
                            xPct: { type: Type.NUMBER },
                            yPct: { type: Type.NUMBER },
                            wPct: { type: Type.NUMBER },
                            hPct: { type: Type.NUMBER },
                          },
                          required: ['name', 'category', 'xPct', 'yPct', 'wPct', 'hPct'],
                        },
                      },
                      suggestedSpanMeters: {
                        type: Type.OBJECT,
                        properties: {
                          width: { type: Type.NUMBER },
                          height: { type: Type.NUMBER },
                        },
                        required: ['width', 'height'],
                      },
                      routerPct: {
                        type: Type.OBJECT,
                        properties: {
                          detected: { type: Type.BOOLEAN },
                          xPct: { type: Type.NUMBER },
                          yPct: { type: Type.NUMBER },
                        },
                        required: ['detected', 'xPct', 'yPct'],
                      },
                      summary: { type: Type.STRING },
                    },
                    required: ['rooms', 'suggestedSpanMeters', 'routerPct', 'summary'],
                  },
                },
              }),
              timeoutPromise,
            ]);
            lastError = null;
            break outerLoop;
          } catch (err) {
            lastError = err;
            if (isRetryableGeminiError(err)) {
              if (attempt < candidate.attempts) {
                await waitMs(600 * Math.pow(2, attempt - 1));
                continue;
              }
              continue outerLoop;
            }
            throw err;
          } finally {
            if (timer !== undefined) clearTimeout(timer);
          }
        }
      }

      if (!response && lastError) {
        throw lastError;
      }

      const rawText = (response?.text ?? '').trim();
      if (!rawText) {
        res.status(502).json({
          error: 'EMPTY_AI_RESPONSE',
          message: 'AI did not detect any rooms from the sketch. Draw closed room boxes or clear lines and retry.',
        });
        return;
      }

      let parsed: ParsedSketchResponse;
      try {
        parsed = JSON.parse(rawText) as ParsedSketchResponse;
      } catch {
        res.status(502).json({
          error: 'MALFORMED_AI_JSON',
          message: 'AI returned an unreadable layout format. Please retry.',
        });
        return;
      }

      if (!Array.isArray(parsed.rooms) || parsed.rooms.length === 0) {
        res.status(422).json({
          error: 'NO_ROOMS_DETECTED',
          message: 'No rooms could be detected in the sketch. Please draw at least one room boundary or add a short note.',
        });
        return;
      }

      const sanitizedRooms = parsed.rooms.slice(0, 16).map((room, idx) => ({
        name:
          typeof room.name === 'string' && room.name.trim()
            ? room.name.trim().slice(0, 48)
            : `Room ${idx + 1}`,
        category:
          typeof room.category === 'string' && ALLOWED_CATEGORIES.has(room.category)
            ? room.category
            : 'custom',
        xPct: clampNumber(room.xPct, 0, 95, 10),
        yPct: clampNumber(room.yPct, 0, 95, 10),
        wPct: clampNumber(room.wPct, 6, 100, 28),
        hPct: clampNumber(room.hPct, 6, 100, 28),
      }));

      const spanW = targetW ?? clampNumber(parsed.suggestedSpanMeters?.width, 6, 24, 12);
      const spanH = targetH ?? clampNumber(parsed.suggestedSpanMeters?.height, 6, 24, 9);

      const routerPct = parsed.routerPct?.detected
        ? {
            detected: true,
            xPct: clampNumber(parsed.routerPct.xPct, 2, 98, 50),
            yPct: clampNumber(parsed.routerPct.yPct, 2, 98, 50),
          }
        : { detected: false, xPct: 50, yPct: 50 };

      res.json({
        rooms: sanitizedRooms,
        suggestedSpanMeters: { width: spanW, height: spanH },
        routerPct,
        summary: typeof parsed.summary === 'string' ? parsed.summary.trim().slice(0, 240) : '',
      });
    } catch (err) {
      const mapped = mapGeminiError(err);
      res.status(mapped.status).json({
        error: mapped.code,
        message: mapped.message,
        ...(mapped.upstreamStatus !== undefined ? { upstreamStatus: mapped.upstreamStatus } : {}),
      });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('/{*path}', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const port = Number(process.env.PORT) || 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`Advanced Wi-Fi server listening on http://0.0.0.0:${port}`);
  });
}

void startServer();
