# Security Specification — Advanced Wi-Fi Firestore Rules

## 1. Data Invariants
1. No router passwords, admin credentials, or session tokens may ever be stored in Firestore (`UserProfile`, `ActivityLogEntry`, `SpeedTestRecord`, `DeviceAlias`, or `RouterDefinition`).
2. Every user document `/users/{userId}` contains PII (`email`) and may only be read (`get`) or written by the verified authenticated owner (`request.auth.uid == userId && request.auth.token.email_verified == true`). Blanket `list` on `/users` is forbidden.
3. Every subcollection under `/users/{userId}/...` must enforce the Master Gate (`exists(/databases/$(database)/documents/users/$(userId))`), strict owner identity (`userId == request.auth.uid`), verified email, and `isValidId()` path validation.
4. `ActivityLogEntry` and `SpeedTestRecord` are append-only user history records (create + read + delete by owner; immutable after creation, no arbitrary updates) with server-enforced `createdAt == request.time`.
5. `UserProfile` enforces `createdAt == request.time` on create, `createdAt` immutability on update, and `updatedAt == request.time` on update, with explicit `affectedKeys().hasOnly(...)` action branches.
6. `DeviceAlias` enforces valid MAC address regex, bounded string sizes, and `updatedAt == request.time`.

## 2. The "Dirty Dozen" Payloads (Expected: PERMISSION_DENIED)
1. Unauthenticated read/write to `/users/userA`.
2. Unverified email (`email_verified: false`) creating `/users/userA`.
3. Cross-user read or list on `/users/userB` or `/users/userB/activity_logs`.
4. Identity spoofing: `userA` creating `/users/userA/activity_logs/log1` with `userId: "userB"`.
5. Shadow field injection: `userA` creating `/users/userA` with extra field `isAdmin: true` or `routerPassword: "secret"`.
6. Ghost field update: `userA` updating `/users/userA` with `affectedKeys` including `uid` or `email` or `createdAt`.
7. Timestamp spoofing: `userA` creating `/users/userA/speed_tests/t1` with client-forged `createdAt` not equal to `request.time`.
8. Path ID poisoning: `userA` writing `/users/userA/activity_logs/invalid$id!` with disallowed characters or >128 chars.
9. Oversized payload DoW: `userA` writing `details` string > 400 characters in `activity_logs`.
10. Invalid enum value: `userA` setting `language: "de"` or `theme: "neon"` in `/users/userA`.
11. Orphaned subcollection write: creating `/users/userA/device_aliases/aa_bb_cc_dd_ee_ff` when parent `/users/userA` does not exist.
12. Unauthorized write to `/router_definitions/huawei` by a non-admin user.
