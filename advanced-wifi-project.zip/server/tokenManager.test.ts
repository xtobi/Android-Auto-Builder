import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import express from 'express';
import {
  AutomaticTokenManager,
  redactSecrets,
  sanitizeRecord
} from './tokenManager.ts';
import {
  AdvancedWifiCoreEngine,
  detectServerLanTopology,
  validateLanTargetUrl
} from './coreEngine.ts';
import { createCoreApiRouter } from './coreRouter.ts';

test('AutomaticTokenManager issues, validates, rotates cleanly, and prevents replay attacks', () => {
  let clock = 1_700_000_000_000;
  const mgr = new AutomaticTokenManager({
    ttlMs: 60_000,
    renewThresholdRatio: 0.5,
    now: () => clock
  });

  const issued = mgr.issueSession({ clientLabel: 'huawei-test' });
  assert.ok(issued.token.startsWith('awt1.'));
  assert.equal(issued.rotationCount, 0);

  const v1 = mgr.verifyToken(issued.token, 'core-session');
  assert.equal(v1.valid, true);
  assert.equal(v1.shouldRotate, false);

  // Tampered token rejected
  const tampered = `${issued.token.slice(0, -4)}AAAA`;
  assert.equal(mgr.verifyToken(tampered).errorCode, 'TOKEN_INVALID');

  // Advance past renewal threshold -> shouldRotate becomes true
  clock += 35_000;
  const v2 = mgr.verifyToken(issued.token);
  assert.equal(v2.valid, true);
  assert.equal(v2.shouldRotate, true);

  // Rotate token -> old token immediately blocked as TOKEN_REPLAYED
  const renewed = mgr.renewToken(issued.token);
  assert.equal(renewed.ok, true);
  if (renewed.ok) {
    assert.equal(renewed.session.rotationCount, 1);
    assert.notEqual(renewed.session.token, issued.token);
    assert.equal(mgr.verifyToken(issued.token).errorCode, 'TOKEN_REPLAYED');
    assert.equal(mgr.verifyToken(renewed.session.token).valid, true);

    // Revoke active token -> subsequent use fails
    assert.equal(mgr.revokeToken(renewed.session.token), true);
    assert.equal(mgr.verifyToken(renewed.session.token).valid, false);
  }
});

test('AutomaticTokenManager enforces token expiration accurately', () => {
  let clock = 1_700_000_000_000;
  const mgr = new AutomaticTokenManager({ ttlMs: 15_000, now: () => clock });
  const s = mgr.issueSession();
  clock += 20_000;
  const res = mgr.verifyToken(s.token);
  assert.equal(res.valid, false);
  // After purgeExpired marks tombstone or expired check catches timestamp
  assert.ok(res.errorCode === 'TOKEN_EXPIRED' || res.errorCode === 'TOKEN_REPLAYED');
});

test('redactSecrets and sanitizeRecord mask all router passwords, tokens, and cookies', () => {
  const dirtyText = 'Authorization: Bearer secretTok123 Cookie: SessionID=abc999 password=MyRouterPass!99';
  const cleaned = redactSecrets(dirtyText, ['MyRouterPass!99']);
  assert.equal(cleaned.includes('MyRouterPass!99'), false);
  assert.equal(cleaned.includes('secretTok123'), false);
  assert.equal(cleaned.includes('abc999'), false);

  const dirtyObj = sanitizeRecord({
    gateway: '192.168.100.1',
    password: 'TopSecretPassword',
    x_hw_token: 'abc123token',
    nested: { cookie: 'SID=1', ok: true }
  });
  assert.equal(JSON.stringify(dirtyObj).includes('TopSecretPassword'), false);
  assert.equal(JSON.stringify(dirtyObj).includes('abc123token'), false);
});

test('Core Engine SSRF validator allows only RFC1918 LAN targets and blocks metadata/public IPs', () => {
  assert.equal(validateLanTargetUrl('http://192.168.100.1/asp/GetRandCount.asp').valid, true);
  assert.equal(validateLanTargetUrl('http://192.168.1.1/').valid, true);
  assert.equal(validateLanTargetUrl('http://10.0.0.1/').valid, true);
  assert.equal(validateLanTargetUrl('http://172.16.5.1/').valid, true);

  assert.equal(validateLanTargetUrl('http://169.254.169.254/latest/meta-data').valid, false);
  assert.equal(validateLanTargetUrl('http://127.0.0.1:3000/').valid, false);
  assert.equal(validateLanTargetUrl('http://8.8.8.8/').valid, false);
  assert.equal(validateLanTargetUrl('http://admin:pass@192.168.100.1/').valid, false);
});

test('detectServerLanTopology distinguishes local-lan from cloud-hosted without false positives', () => {
  assert.equal(detectServerLanTopology('localhost:3000', {}).topology, 'local-lan');
  assert.equal(detectServerLanTopology('192.168.100.20:3000', {}).topology, 'local-lan');
  assert.equal(detectServerLanTopology('ais-dev-demo-123.us-west2.run.app', {}).topology, 'cloud-hosted');
  assert.equal(detectServerLanTopology('localhost:3000', { K_SERVICE: 'aw-cloud' }).topology, 'cloud-hosted');
});

test('Live Core HTTP endpoints execute local router proxy with server-side cookie jar and Secure Cloud Relay', async () => {
  // Spin up an isolated local test HTTP server mimicking Huawei HG8145X6-10 ONT ASP endpoints
  const mockRouterServer = http.createServer((req, res) => {
    if (req.url === '/asp/GetRandCount.asp') {
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end('hw_rand_99887766');
      return;
    }
    if (req.url === '/login.cgi' && req.method === 'POST') {
      res.writeHead(200, {
        'Content-Type': 'text/html',
        'Set-Cookie': 'Cookie=hw_sid_secret_42; Path=/; HttpOnly'
      });
      res.end('<script>top.location="/index.asp"</script>');
      return;
    }
    if (req.url === '/html/ssmp/devinfo/devinfo.asp') {
      // Must receive Cookie automatically attached by Core RAM cookie jar without leaking to client
      const hasCookie = (req.headers.cookie || '').includes('hw_sid_secret_42');
      if (!hasCookie) {
        res.writeHead(401, { 'Content-Type': 'text/html' });
        res.end('<form action="/login.cgi"></form>');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end('<script>var ModelName = "OptiXstar HG8145X6-10"; var SoftwareVersion = "V5R021C00S130";</script>');
      return;
    }
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end('<html>OptiXstar HG8145X6-10</html>');
  });

  await new Promise<void>((resolve) => mockRouterServer.listen(0, '127.0.0.1', resolve));
  const routerPort = (mockRouterServer.address() as { port: number }).port;

  const core = new AdvancedWifiCoreEngine({ allowLoopbackForTests: true });
  const app = express();
  app.use(express.json());
  app.use('/api/core', createCoreApiRouter(core));
  const coreServer = http.createServer(app);
  await new Promise<void>((resolve) => coreServer.listen(0, '127.0.0.1', resolve));
  const corePort = (coreServer.address() as { port: number }).port;
  const coreBase = `http://127.0.0.1:${corePort}/api/core`;

  try {
    // 1. Issue token
    const issueRes = await fetch(`${coreBase}/tokens/issue`, { method: 'POST' });
    assert.equal(issueRes.status, 201);
    const issued = (await issueRes.json()) as { token: string; sessionId: string };
    assert.ok(issued.token);

    // 2. Login via Core proxy -> Set-Cookie is absorbed by Core RAM jar and scrubbed from response
    const loginRes = await fetch(`${coreBase}/router/request`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${issued.token}`
      },
      body: JSON.stringify({
        url: `http://127.0.0.1:${routerPort}/login.cgi`,
        method: 'POST',
        body: 'UserName=admin&PassWord=cGFzcw==&x.X_HW_Token=hw_rand_99887766'
      })
    });
    const loginJson = (await loginRes.json()) as { ok: boolean; headers: Record<string, string> };
    assert.equal(loginJson.ok, true);
    assert.equal(loginJson.headers['set-cookie'], undefined);

    // 3. Read devinfo -> succeeds cleanly because Core attaches Cookie server-side
    const devRes = await fetch(`${coreBase}/router/request`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${issued.token}`
      },
      body: JSON.stringify({
        url: `http://127.0.0.1:${routerPort}/html/ssmp/devinfo/devinfo.asp`,
        method: 'GET'
      })
    });
    const devJson = (await devRes.json()) as { ok: boolean; body: string };
    assert.equal(devJson.ok, true);
    assert.ok(devJson.body.includes('OptiXstar HG8145X6-10'));

    // 4. Relay without online agent returns RELAY_AGENT_OFFLINE honestly
    const relayOfflineRes = await fetch(`${coreBase}/relay/request`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${issued.token}`
      },
      body: JSON.stringify({
        url: `http://127.0.0.1:${routerPort}/`,
        method: 'GET',
        timeoutMs: 1500
      })
    });
    assert.equal(relayOfflineRes.status, 503);
    const relayOfflineJson = (await relayOfflineRes.json()) as { error: string };
    assert.equal(relayOfflineJson.error, 'RELAY_AGENT_OFFLINE');
  } finally {
    await new Promise<void>((resolve) => coreServer.close(() => resolve()));
    await new Promise<void>((resolve) => mockRouterServer.close(() => resolve()));
  }
});
