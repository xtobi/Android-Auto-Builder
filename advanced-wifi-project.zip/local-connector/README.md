# Advanced Wi-Fi Local Connector Companion (v2.0.0)

Runs locally on **Android (via Termux + Node.js)** or Desktop (macOS / Linux / Windows) with **zero external npm dependencies**, allowing the Advanced Wi-Fi web app to communicate securely with your local router (`192.168.1.1`, etc.) over your home Wi-Fi without weakening browser security.

## Security Guarantees
- Listens **strictly** on `127.0.0.1:4890` (loopback only, never exposed on LAN or internet).
- Enforces an explicit **Origin Allowlist** (rejects requests from unauthorized domains with `403`).
- Requires a cryptographic **Local Auth Token** (`X-Connector-Token` / `Authorization: Bearer`) on all `/proxy`, `/session/clear`, and `/shutdown` calls.
- Validates every router URL strictly against RFC1918 private LAN ranges (`192.168.0.0/16`, `10.0.0.0/8`, `172.16.0.0/12`, or `.local` router hostnames) and blocks SSRF targets (`169.254.x.x`, `127.x.x.x`, public URLs).
- Stores router cookies strictly in RAM during the active session.

---

## Android Setup (Termux — No PC Required)

1. Install **Termux** from F-Droid or official GitHub Releases (recommended over outdated Play Store builds).
2. Open Termux and install Node.js LTS (requires Node.js 18+):
   ```bash
   pkg update && pkg upgrade -y && pkg install nodejs-lts -y
   node -v
   ```
3. Download `server.mjs` inside the **Local Connector Setup** page in Advanced Wi-Fi, then grant Termux storage permission and copy it:
   ```bash
   termux-setup-storage
   mkdir -p ~/aw-connector
   cp ~/storage/downloads/server.mjs ~/aw-connector/server.mjs
   ```
4. Keep Termux awake while managing your router:
   ```bash
   termux-wake-lock
   ```
   *(Also disable Battery Optimization for Termux in Android Settings → Apps → Termux → Battery → Unrestricted.)*
5. Start the Local Connector:
   ```bash
   node ~/aw-connector/server.mjs
   ```
6. Copy the **Token** printed in Termux, open **Local Connector Setup** in Advanced Wi-Fi on your Android browser, paste the token, and tap **Verify Connection & Auth**.

### Stopping & Restarting
- **Stop**: Press `Ctrl + C` in Termux (or run `pkill -f server.mjs`, or click **Stop Local Server** inside Local Connector Setup).
- **Restart**: Run `node ~/aw-connector/server.mjs` again (a fresh security token is printed each run unless you pass `CONNECTOR_TOKEN=...`).
- **Custom Origin**: If accessing from a custom URL, start with:
  ```bash
  CONNECTOR_ALLOWED_ORIGINS="https://your-app-origin.example" node ~/aw-connector/server.mjs
  ```
