import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {
  buildAllowedOriginsSet,
  createConnectorServer,
  isOriginAllowed,
  validateLanTarget,
  verifyToken
} from './server.mjs';

test('validateLanTarget allows RFC1918 LAN targets and blocks loopback/metadata/public URLs', () => {
  assert.ok(validateLanTarget('http://192.168.1.1/api'));
  assert.ok(validateLanTarget('http://10.0.0.1/'));
  assert.ok(validateLanTarget('http://172.16.0.1/'));
  assert.ok(validateLanTarget('http://tplinkwifi.net/'));
  assert.equal(validateLanTarget('http://127.0.0.1:4890/'), null);
  assert.equal(validateLanTarget('http://localhost:3000/'), null);
  assert.equal(validateLanTarget('http://169.254.169.254/latest/meta-data'), null);
  assert.equal(validateLanTarget('https://example.com/'), null);
  assert.equal(validateLanTarget('http://admin:pass@192.168.1.1/'), null);
});

test('isOriginAllowed restricts CORS strictly to allowed origins', () => {
  const allowed = buildAllowedOriginsSet();
  assert.equal(isOriginAllowed('http://localhost:3000', allowed), true);
  assert.equal(
    isOriginAllowed('https://ais-dev-ghnmuzpj6abkrq44vr6qnx-751624632205.europe-west1.run.app', allowed),
    true
  );
  assert.equal(isOriginAllowed('https://malicious-site.example', allowed), false);
});

test('verifyToken uses constant-time comparison', () => {
  assert.equal(verifyToken('secret-token-1234', 'secret-token-1234'), true);
  assert.equal(verifyToken('secret-token-1235', 'secret-token-1234'), false);
  assert.equal(verifyToken('', 'secret-token-1234'), false);
});

test('createConnectorServer enforces origin allowlist, token auth, SSRF guard, and clean shutdown', async () => {
  const { server, token } = createConnectorServer({
    token: 'test-token-value-123456',
    keepProcessAlive: true,
    fetchImpl: async (url: string) => {
      if (url.includes('/redirect-escape')) {
        return new Response('', {
          status: 302,
          headers: { location: 'https://evil.example.com/' }
        });
      }
      return new Response('{"ok":true,"router":"mock"}', {
        status: 200,
        headers: { 'content-type': 'application/json' }
      });
    }
  });

  await new Promise<void>((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve());
  });

  try {
    const address = server.address() as { port: number };
    const baseUrl = `http://127.0.0.1:${address.port}`;

    // 1. Disallowed Origin is blocked with 403 and no ACAO header
    const badOriginRes = await fetch(`${baseUrl}/health`, {
      headers: { Origin: 'https://untrusted.example.com' }
    });
    assert.equal(badOriginRes.status, 403);
    assert.equal(badOriginRes.headers.get('access-control-allow-origin'), null);

    // 2. Allowed Origin /health reports authVerified: false when token is missing
    const unauthHealthRes = await fetch(`${baseUrl}/health`, {
      headers: { Origin: 'http://localhost:3000' }
    });
    assert.equal(unauthHealthRes.status, 200);
    assert.equal(unauthHealthRes.headers.get('access-control-allow-origin'), 'http://localhost:3000');
    assert.equal(unauthHealthRes.headers.get('access-control-allow-private-network'), 'true');
    const unauthHealth = (await unauthHealthRes.json()) as { ok: boolean; authVerified: boolean };
    assert.equal(unauthHealth.ok, true);
    assert.equal(unauthHealth.authVerified, false);

    // 3. /proxy without token returns 401 AUTH_REQUIRED
    const unauthProxyRes = await fetch(`${baseUrl}/proxy`, {
      method: 'POST',
      headers: { Origin: 'http://localhost:3000', 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: 'http://192.168.1.1/', method: 'GET' })
    });
    assert.equal(unauthProxyRes.status, 401);

    // 4. /health with valid token reports authVerified: true
    const authHealthRes = await fetch(`${baseUrl}/health`, {
      headers: { Origin: 'http://localhost:3000', 'X-Connector-Token': token }
    });
    const authHealth = (await authHealthRes.json()) as { ok: boolean; authVerified: boolean };
    assert.equal(authHealth.authVerified, true);

    // 5. /proxy with valid token blocks SSRF metadata IP
    const ssrfRes = await fetch(`${baseUrl}/proxy`, {
      method: 'POST',
      headers: {
        Origin: 'http://localhost:3000',
        'Content-Type': 'application/json',
        'X-Connector-Token': token
      },
      body: JSON.stringify({ url: 'http://169.254.169.254/latest/meta-data', method: 'GET' })
    });
    assert.equal(ssrfRes.status, 400);

    // 6. /proxy blocks redirect escaping to public host
    const redirectRes = await fetch(`${baseUrl}/proxy`, {
      method: 'POST',
      headers: {
        Origin: 'http://localhost:3000',
        'Content-Type': 'application/json',
        'X-Connector-Token': token
      },
      body: JSON.stringify({ url: 'http://192.168.1.1/redirect-escape', method: 'GET' })
    });
    assert.equal(redirectRes.status, 400);

    // 7. /proxy succeeds for private LAN target with valid token & origin
    const okProxyRes = await fetch(`${baseUrl}/proxy`, {
      method: 'POST',
      headers: {
        Origin: 'http://localhost:3000',
        'Content-Type': 'application/json',
        'X-Connector-Token': token
      },
      body: JSON.stringify({ url: 'http://192.168.1.1/status', method: 'GET' })
    });
    assert.equal(okProxyRes.status, 200);
    const okBody = (await okProxyRes.json()) as { status: number; body: string };
    assert.equal(okBody.status, 200);
    assert.match(okBody.body, /"router":"mock"/);

    // 8. Authenticated /shutdown responds cleanly
    const stopRes = await fetch(`${baseUrl}/shutdown`, {
      method: 'POST',
      headers: {
        Origin: 'http://localhost:3000',
        'X-Connector-Token': token
      }
    });
    assert.equal(stopRes.status, 200);
    const stopBody = (await stopRes.json()) as { stopping: boolean };
    assert.equal(stopBody.stopping, true);
  } finally {
    await new Promise<void>((resolve) => {
      if ((server as http.Server).listening) {
        server.close(() => resolve());
      } else {
        resolve();
      }
    });
  }
});
